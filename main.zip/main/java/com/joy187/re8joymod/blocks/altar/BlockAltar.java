package com.joy187.re8joymod.blocks.altar;

import com.joy187.re8joymod.init.ItemInit;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class BlockAltar extends Block implements EntityBlock {
    protected static final VoxelShape SHAPE = Block.box(1.0D, 0.0D, 1.0D, 15.0D, 15.0D, 15.0D);

    public BlockAltar() {
        super(Properties.copy(Blocks.STONE)
                .sound(SoundType.STONE)
                .requiresCorrectToolForDrops()
                .strength(40.0F, 600.0F)
                .noOcclusion());
    }

    private static final Predicate<Entity> ALTAR_AREA = (entity) -> entity.isAlive();

    // 【修复】使用 Supplier 延迟求值，避免在类静态初始化阶段调用 RegistryObject.get()
    private static final Set<Supplier<Item>> DURABILITY_ITEMS = Set.of(
            ItemInit.SALAZARCROWN,
            ItemInit.PUPPET,
            ItemInit.TOTEMDOWN
    );

    private static boolean isDurabilityItem(ItemStack stack) {
        for (Supplier<Item> supplier : DURABILITY_ITEMS) {
            if (stack.is(supplier.get())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onProjectileHit(Level level, BlockState state, BlockHitResult hitResult, Projectile projectile) {
        int i = 1;
        Entity entity = projectile.getOwner();
        if (entity instanceof ServerPlayer serverplayer) {
            serverplayer.awardStat(Stats.TARGET_HIT);
            CriteriaTriggers.TARGET_BLOCK_HIT.trigger(serverplayer, projectile, hitResult.getLocation(), i);
        }
        BlockPos pos = hitResult.getBlockPos();
        AABB aabb = (new AABB(pos)).inflate(2D);
        for (LivingEntity lvt : level.getEntitiesOfClass(LivingEntity.class, aabb, ALTAR_AREA)) {
            lvt.hurt(lvt.damageSources().explosion(lvt, lvt), lvt.getMaxHealth() * 0.3f);
        }
        level.removeBlock(pos, false);
        level.setBlock(pos, Blocks.FIRE.defaultBlockState(), 2);
        level.explode(null, pos.getX(), pos.getY(), pos.getZ(), 2.0F, Level.ExplosionInteraction.NONE);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter getter, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack stack = player.getItemInHand(hand);
        BlockEntity be = level.getBlockEntity(pos);

        if (be instanceof BlockAltarEntity altarEntity) {
            // 冷却期间禁止任何交互
            if (altarEntity.isOnCooldown()) {
                if (!level.isClientSide) {
                    level.playSound(null, pos, SoundEvents.NOTE_BLOCK_BASS.value(), SoundSource.BLOCKS, 1.0F, 0.5F);
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }

            // 1. 取回物品
            if (!altarEntity.getStoredItem().isEmpty() && stack.isEmpty()) {
                if (!level.isClientSide) {
                    player.setItemInHand(hand, altarEntity.getStoredItem());
                    altarEntity.setStoredItem(ItemStack.EMPTY);
                    altarEntity.stopRitual();
                    level.playSound(null, pos, SoundEvents.ITEM_PICKUP, SoundSource.BLOCKS, 1.0F, 1.0F);

                    level.sendBlockUpdated(pos, state, state, 3);
                    if (player instanceof ServerPlayer serverPlayer) {
                        serverPlayer.inventoryMenu.broadcastChanges();
                    }
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }

            // 2. 放置物品
            if (altarEntity.getStoredItem().isEmpty() && !stack.isEmpty()) {
                if (!level.isClientSide) {
                    // 如果是书，消耗 3 级经验并随机给一本附魔书
                    if (stack.is(Items.BOOK)) {
                        if (player.experienceLevel >= 3 || player.isCreative()) {
                            if (!player.isCreative()) {
                                player.giveExperienceLevels(-3);
                            }

                            ItemStack enchantedBook = getRandomEnchantedBook(level.random);

                            if (!player.getInventory().add(enchantedBook)) {
                                player.drop(enchantedBook, false);
                            }

                            level.playSound(null, pos, SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);

                            if (!player.isCreative()) {
                                stack.shrink(1);
                                if (stack.isEmpty() && player instanceof ServerPlayer serverPlayer) {
                                    serverPlayer.inventoryMenu.broadcastChanges();
                                }
                            }

                            altarEntity.startCooldown();
                            return InteractionResult.sidedSuccess(level.isClientSide);
                        } else {
                            level.playSound(null, pos, SoundEvents.NOTE_BLOCK_BASS.value(), SoundSource.BLOCKS, 1.0F, 1.0F);
                            return InteractionResult.sidedSuccess(level.isClientSide);
                        }
                    }

                    // 特定物品判断（运行时调用 .get() 是安全的，此时注册已完成）
                    boolean isSpecial = stack.is(ItemInit.MOREAUHEAD.get()) || stack.is(ItemInit.SALAZARCROWN.get())
                            || stack.is(ItemInit.PUPPET.get());

                    // 使用 altarItem 作为最终放置的物品
                    ItemStack altarItem = stack.copyWithCount(1);

                    // 【修复】用 isDurabilityItem 延迟匹配，避免静态初始化期 NPE
                    if (isDurabilityItem(stack) && stack.isDamageableItem()) {
                        // 让耐久 -1
                        altarItem.setDamageValue(stack.getDamageValue() + 1);

                        // 如果耐久耗尽
                        if (altarItem.getDamageValue() >= altarItem.getMaxDamage()) {
                            altarItem = ItemStack.EMPTY; // 祭坛上变空
                            level.playSound(null, pos, SoundEvents.ITEM_BREAK, SoundSource.BLOCKS, 1.0F, 1.0F);

                            // 调用金粒散落特效
                            spawnGoldParticles(level, pos);
                        }
                    }

                    altarEntity.setStoredItem(altarItem);

                    if (!player.isCreative()) {
                        stack.shrink(1);
                        if (stack.isEmpty() && player instanceof ServerPlayer serverPlayer) {
                            serverPlayer.inventoryMenu.broadcastChanges();
                        }
                    }

                    level.playSound(null, pos, SoundEvents.ITEM_FRAME_ADD_ITEM, SoundSource.BLOCKS, 1.0F, 1.0F);

                    if (!altarItem.isEmpty()) { // 只有物品成功放上去了才触发仪式
                        altarEntity.startRitual();
                    }
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return super.use(state, level, pos, player, hand, hit);
    }

    // 金粒散落粒子效果函数
    public static void spawnGoldParticles(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            // 使用 DustParticleOptions 自定义金黄色粒子
            // 颜色参数为 RGB (1.0F 红色, 0.8F 绿色, 0.0F 蓝色)，大小为 1.5F
            DustParticleOptions goldDust = new DustParticleOptions(new Vector3f(1.0F, 0.8F, 0.0F), 1.5F);

            serverLevel.sendParticles(
                    goldDust,
                    pos.getX() + 0.5D, // 中心 X
                    pos.getY() + 1.0D, // 中心 Y (祭坛上方)
                    pos.getZ() + 0.5D, // 中心 Z
                    40,                // 粒子数量
                    0.4D, 0.4D, 0.4D,  // 扩散范围
                    0.1D               // 速度
            );

            // 再补一点原版的 END_ROD 粒子
            serverLevel.sendParticles(
                    net.minecraft.core.particles.ParticleTypes.END_ROD,
                    pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D,
                    10, 0.2D, 0.2D, 0.2D, 0.05D
            );
        }
    }

    private static ItemStack getRandomEnchantedBook(RandomSource random) {
        List<Enchantment> enchantments = new ArrayList<>();
        enchantments.add(Enchantments.SHARPNESS);
        enchantments.add(Enchantments.ALL_DAMAGE_PROTECTION);
        enchantments.add(Enchantments.BLOCK_EFFICIENCY);
        enchantments.add(Enchantments.UNBREAKING);
        enchantments.add(Enchantments.BLOCK_FORTUNE);
        enchantments.add(Enchantments.FISHING_LUCK);
        enchantments.add(Enchantments.POWER_ARROWS);
        enchantments.add(Enchantments.INFINITY_ARROWS);
        enchantments.add(Enchantments.BINDING_CURSE);
        enchantments.add(Enchantments.VANISHING_CURSE);
        enchantments.add(Enchantments.MENDING);
        enchantments.add(Enchantments.SILK_TOUCH);
        enchantments.add(Enchantments.RIPTIDE);

        Enchantment enchantment = enchantments.get(random.nextInt(enchantments.size()));
        int level = random.nextInt(enchantment.getMaxLevel()) + 1;

        ItemStack book = new ItemStack(Items.ENCHANTED_BOOK);
        EnchantedBookItem.addEnchantment(book, new EnchantmentInstance(enchantment, level));

        return book;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new BlockAltarEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return (lvl, pos, st, be) -> {
            if (be instanceof BlockAltarEntity altarEntity) {
                BlockAltarEntity.tick(lvl, pos, st, altarEntity);
            }
        };
    }
}