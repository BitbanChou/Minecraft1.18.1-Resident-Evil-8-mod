package com.joy187.re8joymod.blocks.altar;

import com.joy187.re8joymod.blocks.altar.BlockAltarEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class AltarRenderer implements BlockEntityRenderer<BlockAltarEntity> {

    private final ItemRenderer itemRenderer;

    public AltarRenderer(BlockEntityRendererProvider.Context context) {
        this.itemRenderer = context.getItemRenderer();
    }

    @Override
    public void render(BlockAltarEntity blockEntity, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int packedLight, int packedOverlay) {
        ItemStack stack = blockEntity.getStoredItem();

        // 防止 itemRenderer 报空指针
        if (stack.isEmpty()) return;

        poseStack.pushPose();

        // 位置调整：X/Z 居中，Y 调到 1.5 确保悬浮在祭坛上方
        poseStack.translate(0.5D, 1.2D, 0.5D);

        // 旋转逻辑
        float rotation = (blockEntity.getLevel().getGameTime() + partialTick) * 2.0F;
        poseStack.mulPose(Axis.YP.rotationDegrees(rotation));

        // 仪式激活时的浮动动画
        if (blockEntity.isActivated()) {
            float bob = (float) Math.sin((blockEntity.getLevel().getGameTime() + partialTick) * 0.1D) * 0.1F;
            poseStack.translate(0.0D, bob, 0.0D);
        }

        poseStack.scale(1.0F, 1.0F, 1.0F);

        this.itemRenderer.renderStatic(
                stack,
                ItemDisplayContext.FIXED,
                packedLight,
                packedOverlay,
                poseStack,
                buffer,
                blockEntity.getLevel(),
                0
        );

        poseStack.popPose();
    }
}