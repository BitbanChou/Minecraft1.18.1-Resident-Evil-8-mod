package com.joy187.re8joymod.blocks.altar;

import com.joy187.re8joymod.entity.*;
import com.joy187.re8joymod.init.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class BlockAltarEntity extends BlockEntity {

    private ItemStack storedItem = ItemStack.EMPTY;
    private boolean isActivated = false;
    private int tickCount = 0;
    private static final int MAX_TICKS = 100; // 5秒

    private int cooldown = 0;
    private static final int MAX_COOLDOWN = 200;

    public BlockAltarEntity(BlockPos pos, BlockState state) {
        super(BlockEntityInit.ALTAR_ENTITY.get(), pos, state);
    }

    public ItemStack getStoredItem() { return storedItem; }

    public void setStoredItem(ItemStack stack) {
        this.storedItem = stack;
        this.setChanged();
        if (level != null && !level.isClientSide) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    public void startRitual() {
        this.isActivated = true;
        this.tickCount = 0;
        this.setChanged();
        if (level != null && !level.isClientSide) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    public void stopRitual() {
        this.isActivated = false;
        this.tickCount = 0;
        this.setChanged();
        if (level != null && !level.isClientSide) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    public void startCooldown() {
        this.cooldown = MAX_COOLDOWN;
        this.setChanged();
        if (level != null && !level.isClientSide) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    public boolean isOnCooldown() {
        return this.cooldown > 0;
    }

    public static void tick(Level level, BlockPos pos, BlockState state, BlockAltarEntity be) {
        if (be.cooldown > 0) {
            be.cooldown--;
            if (level.isClientSide && level.random.nextInt(3) == 0) {
                double x = pos.getX() + 0.2D + level.random.nextDouble() * 0.6D;
                double y = pos.getY() + 0.1D + level.random.nextDouble() * 0.8D;
                double z = pos.getZ() + 0.2D + level.random.nextDouble() * 0.6D;
                level.addParticle(ParticleTypes.SMOKE, x, y, z, 0.0D, 0.02D, 0.0D);
            }
            return;
        }

        if (!be.isActivated) return;

        be.tickCount++;

        if (level.isClientSide) {
            double radius = 0.8D;
            double centerX = pos.getX() + 0.5D;
            double centerY = pos.getY() + 1.2D;
            double centerZ = pos.getZ() + 0.5D;
            double angle = be.tickCount * 0.2D;

            for (int i = 0; i < 3; i++) {
                double currentAngle = angle + (i * Math.PI * 2 / 3);
                double x = centerX + Math.cos(currentAngle) * radius;
                double z = centerZ + Math.sin(currentAngle) * radius;
                level.addParticle(ParticleTypes.SMOKE, x, centerY, z, 0.0D, 0.05D, 0.0D);
            }
        }

        if (!level.isClientSide) {
            if (be.tickCount >= MAX_TICKS) {
                ItemStack stored = be.getStoredItem();

                // 【核心修改】判断祭坛上的物品
                if (!stored.isEmpty() && stored.is(ItemInit.SALAZARCROWN.get())) {
                    // 如果是王冠：不打雷，直接走随机事件
                    handleCrownRitual(level, pos);
                } if (!stored.isEmpty() && stored.getItem() instanceof net.minecraft.world.item.BlockItem blockItem && blockItem.getBlock() == BlockInit.PINK_ROSE.get()) {
                    // 注意这里是 == 比较对象，而不是 instanceof
                    handlePanicRose(level, pos);
                    be.setStoredItem(ItemStack.EMPTY);
                }
                else if (!stored.isEmpty() && stored.getItem() instanceof net.minecraft.world.item.BlockItem blockItem && blockItem.getBlock() instanceof net.minecraft.world.level.block.FlowerBlock) {
                    spawnFlowersAround(level, pos, blockItem.getBlock());
                    be.setStoredItem(ItemStack.EMPTY);
                } else if (stored.getItem() instanceof net.minecraft.world.item.BlockItem) {
                    spawnWaterPrison(level, pos);
                    be.setStoredItem(ItemStack.EMPTY);
                }
                else if(!stored.isEmpty() && stored.is(ItemInit.MOREAUHEAD.get())) {
                    // 如果是 MOREAUHEAD
                    handleMoreauhead(level, pos);
                } else if(!stored.isEmpty() && stored.is(ItemInit.PUPPET.get())) {
                    handlePuppet(level, pos);
                } else if(!stored.isEmpty() && stored.is(ItemInit.TOTEMDOWN.get())) {
                    handleTotemdown(level, pos);
                }

                be.stopRitual();
                be.startCooldown();
            }
        }
    }

    private static void handleCrownRitual(Level level, BlockPos pos) {
        int rand = level.random.nextInt(10); // 0-9

        if (rand == 0) {
            // 10% 概率：弹出 2 个绿宝石
            dropItemFromAltar(level, pos, new ItemStack(Items.EMERALD, 2));
        } else if (rand <= 2) {
            // 20% 概率：弹出 2 个金块
            dropItemFromAltar(level, pos, new ItemStack(Items.GOLD_BLOCK, 2));
        } else if (rand == 3) {
            // 10% 概率：弹出 2 个钻石块
            dropItemFromAltar(level, pos, new ItemStack(Items.DIAMOND_BLOCK, 2));
        } else {
            // 60% 概率：召唤小队
            spawnEnemySquad(level, pos);
        }
    }

    private static void handleMoreauhead(Level level, BlockPos pos) {
        int rand = level.random.nextInt(20); // 0-9

        if (rand == 0) {
            dropItemFromAltar(level, pos, new ItemStack(ItemInit.MCHEESE.get(), 1));
        } else if (rand == 1) {
            dropItemFromAltar(level, pos, new ItemStack(ItemInit.HERBFISH.get(), 1));
        } else if (rand == 2) {
            dropItemFromAltar(level, pos, new ItemStack(ItemInit.BIRDANDPILAF.get(), 1));
        } else if (rand == 3) {
            dropItemFromAltar(level, pos, new ItemStack(ItemInit.THREEFLAVOR.get(), 1));
        } else if (rand == 4) {
            dropItemFromAltar(level, pos, new ItemStack(ItemInit.TOCH.get(), 1));
        } else if (rand == 5) {
            dropItemFromAltar(level, pos, new ItemStack(ItemInit.CIOR.get(), 1));
        } else if (rand == 6) {
            dropItemFromAltar(level, pos, new ItemStack(ItemInit.SARMAL.get(), 1));
        } else {
            // 60% 概率：雷电
            triggerLightning(level, pos);
        }
    }


    private static void handlePuppet(Level level, BlockPos pos) {
        int rand = level.random.nextInt(6); // 0-9

        if (rand == 0) {
            dropItemFromAltar(level, pos, new ItemStack(ItemInit.LEI2.get(), 1));
        } else if (rand == 1) {
            dropItemFromAltar(level, pos, new ItemStack(ItemInit.ROSEGENE.get(), 1));
        } else if (rand == 2) {
            spawnMary(level, pos);
        } else {
            //生产人偶
            spawnMannequin(level, pos);
        }
    }

    private static void handleTotemdown(Level level, BlockPos pos) {
        int rand = level.random.nextInt(6); // 0-9

        if (rand == 0) {
            dropItemFromAltar(level, pos, new ItemStack(ItemInit.LEI2.get(), 1));
//        } else if (rand == 1) {
//            dropItemFromAltar(level, pos, new ItemStack(ItemInit.ROSEGENE.get(), 1));
//        } else if (rand == 2) {
//            spawnMary(level, pos);
        } else {
            //生产鱼
            triggerLiveFishFountain(level, pos);
        }
    }


    private static void handlePanicRose(Level level, BlockPos pos) {
        int rand = level.random.nextInt(6); // 0-9

        if (rand == 0) {
            triggerPotionSplash(level, pos);
        } else if (rand == 1) {
            dropItemFromAltar(level, pos, new ItemStack(ItemInit.ROSEGENE.get(), 1));
        } else if (rand == 2) {
            spawnPlagas(level, pos);
        } else if(rand > 5){
            //生产太阳花
            spawnSunFlowersAround(level, pos);
        } else {
            spawnWitherRoseAround(level, pos);
        }
    }

    private static void dropItemFromAltar(Level level, BlockPos pos, ItemStack stack) {
        if (level instanceof ServerLevel serverLevel) {
            ItemEntity itemEntity = new ItemEntity(level,
                    pos.getX() + 0.5D,
                    pos.getY() + 1.2D,
                    pos.getZ() + 0.5D,
                    stack);

            itemEntity.setDeltaMovement(
                    (level.random.nextDouble() - 0.5) * 0.2D,
                    0.3D,
                    (level.random.nextDouble() - 0.5) * 0.2D
            );
            itemEntity.setPickUpDelay(20);
            serverLevel.addFreshEntity(itemEntity);
        }
    }

    // 在祭坛周围随机生成小队
    public static void spawnEnemySquad(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            // 生成 3 只 Zealot
            for (int i = 0; i < 3; i++) {
                double offsetX = (level.random.nextDouble() - 0.5) * 6.0D;
                double offsetZ = (level.random.nextDouble() - 0.5) * 6.0D;
                BlockPos spawnPos = pos.offset((int) offsetX, 1, (int) offsetZ);
                // 防止生成在方块里
                while (serverLevel.getBlockState(spawnPos).isSolidRender(serverLevel, spawnPos) && spawnPos.getY() < pos.getY() + 10) {
                    spawnPos = spawnPos.above();
                }

                EntityZealot mannequin = new EntityZealot(EntityInit.ZEALOT.get(), serverLevel);
                mannequin.moveTo(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, level.random.nextFloat() * 360F, 0.0F);
                serverLevel.addFreshEntity(mannequin);
            }
            double offsetX = (level.random.nextDouble() - 0.5) * 6.0D;
            double offsetZ = (level.random.nextDouble() - 0.5) * 6.0D;
            BlockPos spawnPos = pos.offset((int) offsetX, 1, (int) offsetZ);
            EntityStuff stuff = new EntityStuff(EntityInit.STUFF.get(), serverLevel);
            stuff.moveTo(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, level.random.nextFloat() * 360F, 0.0F);
            serverLevel.addFreshEntity(stuff);
            serverLevel.playSound(null, pos, net.minecraft.sounds.SoundEvents.RAID_HORN.get(), net.minecraft.sounds.SoundSource.HOSTILE, 1.0F, 1.0F);
        }
    }

    // 在祭坛周围随机生成人偶
    public static void spawnMannequin(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            // 生成 3 只 Zealot
            for (int i = 0; i < 5; i++) {
                double offsetX = (level.random.nextDouble() - 0.5) * 6.0D;
                double offsetZ = (level.random.nextDouble() - 0.5) * 6.0D;
                BlockPos spawnPos = pos.offset((int) offsetX, 1, (int) offsetZ);
                // 防止生成在方块里
                while (serverLevel.getBlockState(spawnPos).isSolidRender(serverLevel, spawnPos) && spawnPos.getY() < pos.getY() + 10) {
                    spawnPos = spawnPos.above();
                }

                EntityMannequin mannequin = new EntityMannequin(EntityInit.MANNEQUIN.get(), serverLevel);
                mannequin.moveTo(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, level.random.nextFloat() * 360F, 0.0F);
                serverLevel.addFreshEntity(mannequin);
            }

            if(level.random.nextInt(3)==0) {
                double offsetX = (level.random.nextDouble() - 0.5) * 6.0D;
                double offsetZ = (level.random.nextDouble() - 0.5) * 6.0D;
                BlockPos spawnPos = pos.offset((int) offsetX, 1, (int) offsetZ);
                EntityBeibaby stuff = new EntityBeibaby(EntityInit.BEIBABY.get(), serverLevel);
                stuff.moveTo(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, level.random.nextFloat() * 360F, 0.0F);
                serverLevel.addFreshEntity(stuff);
            }


            serverLevel.playSound(null, pos, SoundEvents.WOOD_BREAK, net.minecraft.sounds.SoundSource.HOSTILE, 1.0F, 1.0F);
        }
    }

    // 在祭坛周围随机生成玛丽
    public static void spawnMary(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            // 生成 3 只 Zealot
            for (int i = 0; i < 1; i++) {
                double offsetX = (level.random.nextDouble() - 0.5) * 6.0D;
                double offsetZ = (level.random.nextDouble() - 0.5) * 6.0D;
                BlockPos spawnPos = pos.offset((int) offsetX, 1, (int) offsetZ);
                // 防止生成在方块里
                while (serverLevel.getBlockState(spawnPos).isSolidRender(serverLevel, spawnPos) && spawnPos.getY() < pos.getY() + 10) {
                    spawnPos = spawnPos.above();
                }

                EntityRosemary mannequin = new EntityRosemary(EntityInit.ROSEMARY.get(), serverLevel);
                mannequin.moveTo(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, level.random.nextFloat() * 360F, 0.0F);
                serverLevel.addFreshEntity(mannequin);
            }

            if(level.random.nextInt(2)==0) {
                double offsetX = (level.random.nextDouble() - 0.5) * 6.0D;
                double offsetZ = (level.random.nextDouble() - 0.5) * 6.0D;
                BlockPos spawnPos = pos.offset((int) offsetX, 1, (int) offsetZ);
                EntityMia stuff = new EntityMia(EntityInit.MIA.get(), serverLevel);
                stuff.moveTo(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, level.random.nextFloat() * 360F, 0.0F);
                serverLevel.addFreshEntity(stuff);
            }


            serverLevel.playSound(null, pos, SoundEvents.WOOD_BREAK, net.minecraft.sounds.SoundSource.HOSTILE, 1.0F, 1.0F);
        }
    }

    //生成寄生虫
    public static void spawnPlagas(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            // 生成 3 只 Zealot
            for (int i = 0; i < 6; i++) {
                double offsetX = (level.random.nextDouble() - 0.5) * 6.0D;
                double offsetZ = (level.random.nextDouble() - 0.5) * 6.0D;
                BlockPos spawnPos = pos.offset((int) offsetX, 1, (int) offsetZ);
                // 防止生成在方块里
                while (serverLevel.getBlockState(spawnPos).isSolidRender(serverLevel, spawnPos) && spawnPos.getY() < pos.getY() + 10) {
                    spawnPos = spawnPos.above();
                }

                EntityPlagas mannequin = new EntityPlagas(EntityInit.PLAGAS.get(), serverLevel);
                mannequin.moveTo(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, level.random.nextFloat() * 360F, 0.0F);
                serverLevel.addFreshEntity(mannequin);
            }

            if(level.random.nextInt(2)==0) {
                double offsetX = (level.random.nextDouble() - 0.5) * 6.0D;
                double offsetZ = (level.random.nextDouble() - 0.5) * 6.0D;
                BlockPos spawnPos = pos.offset((int) offsetX, 1, (int) offsetZ);
                EntityPlagasm stuff = new EntityPlagasm(EntityInit.PLAGASM.get(), serverLevel);
                stuff.moveTo(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, level.random.nextFloat() * 360F, 0.0F);
                serverLevel.addFreshEntity(stuff);
            }


            serverLevel.playSound(null, pos, SoundEvents.SILVERFISH_STEP, net.minecraft.sounds.SoundSource.HOSTILE, 1.0F, 1.0F);
        }
    }


    private static void triggerLightning(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            // 1. 寻找祭坛周围 16 格内的玩家
            AABB area = new AABB(pos).inflate(16.0D);
            List<ServerPlayer> players = serverLevel.getEntitiesOfClass(ServerPlayer.class, area);

            for (int i = 0; i < 3; i++) {
                LightningBolt lightning = EntityType.LIGHTNING_BOLT.create(serverLevel);
                if (lightning != null) {
                    Vec3 spawnPos;

                    if (!players.isEmpty()) {
                        // 如果有玩家，随机选一个玩家，劈在他脚下
                        ServerPlayer target = players.get(level.random.nextInt(players.size()));
                        spawnPos = target.position();
                    } else {
                        // 如果周围没玩家，就劈在祭坛周围随机位置
                        double offsetX = (level.random.nextDouble() - 0.5) * 4.0D;
                        double offsetZ = (level.random.nextDouble() - 0.5) * 4.0D;
                        spawnPos = Vec3.atBottomCenterOf(pos.offset((int)offsetX, 0, (int)offsetZ));
                    }

                    lightning.moveTo(spawnPos);
                    serverLevel.addFreshEntity(lightning);
                }
            }
        }
    }

    // 【新增】在周围的草地上生成花朵
    public static void spawnFlowersAround(Level level, BlockPos pos, net.minecraft.world.level.block.Block flowerBlock) {
        if (level instanceof ServerLevel serverLevel) {
            int flowerCount = 4 + level.random.nextInt(5); // 随机生成 4~8 朵花

            for (int i = 0; i < flowerCount; i++) {
                // 在祭坛周围 3~6 格范围内随机寻找位置
                double offsetX = (level.random.nextDouble() - 0.5) * 12.0D;
                double offsetZ = (level.random.nextDouble() - 0.5) * 12.0D;
                BlockPos targetPos = pos.offset((int) offsetX, 0, (int) offsetZ);

                // 检测这个位置的地面是否是草地/泥土，且上方是空气
                for (int y = 1; y >= -2; y--) {
                    BlockPos groundPos = targetPos.offset(0, y, 0);
                    BlockState groundState = serverLevel.getBlockState(groundPos);
                    BlockPos flowerPos = groundPos.above();

                    // 如果地面是草方块或泥土，且上面一格是空气
                    if ((groundState.is(net.minecraft.world.level.block.Blocks.GRASS_BLOCK) ||
                            groundState.is(net.minecraft.world.level.block.Blocks.DIRT)) &&
                            serverLevel.isEmptyBlock(flowerPos)) {

                        // 【核心修改】决定生成什么花
                        net.minecraft.world.level.block.Block blockToPlace = flowerBlock;

                        // 如果想让原版花池也有概率出现，可以保留这个判断，否则删掉只留你定义的花
                        if (level.random.nextBoolean()) {
                            blockToPlace = getRandomCustomFlower(level.random);
                        }

                        serverLevel.setBlockAndUpdate(flowerPos, blockToPlace.defaultBlockState());
                        break; // 放置成功后就不再往下找了
                    }
                }
            }
            // 播放一点自然生长的音效
            serverLevel.playSound(null, pos, SoundEvents.BONE_MEAL_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
    }

    // 【辅助方法】根据权重随机返回你定义的花朵方块
    private static net.minecraft.world.level.block.Block getRandomCustomFlower(RandomSource random) {
        float number = random.nextFloat();

        // 这里根据你提供的花，分配了 10 种花，每种大约 10% 的概率
        if (number < 0.10F) {
            return Blocks.TORCHFLOWER; // 火把花
        } else if (number < 0.20F) {
            return Blocks.POPPY; // 虞美人
        } else if (number < 0.30F) {
            return Blocks.BLUE_ORCHID; // 兰花
        } else if (number < 0.40F) {
            return Blocks.ALLIUM; // 绒球葱
        } else if (number < 0.50F) {
            return Blocks.AZURE_BLUET; // 蓝花美耳草
        } else if (number < 0.60F) {
            return Blocks.RED_TULIP; // 红色郁金香
        } else if (number < 0.70F) {
            return Blocks.ORANGE_TULIP; // 橙色郁金香
        } else if (number < 0.80F) {
            return Blocks.WHITE_TULIP; // 白色郁金香
        } else if (number < 0.90F) {
            return Blocks.PINK_TULIP; // 粉色郁金香
        } else {
            return Blocks.OXEYE_DAISY; // 滨菊
        }
    }

    public static void spawnSunFlowersAround(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            int flowerCount = level.random.nextInt(5); // 随机生成 4~8 朵花

            for (int i = 0; i < flowerCount; i++) {
                // 在祭坛周围 3~6 格范围内随机寻找位置
                double offsetX = (level.random.nextDouble() - 0.5) * 12.0D;
                double offsetZ = (level.random.nextDouble() - 0.5) * 12.0D;
                BlockPos targetPos = pos.offset((int) offsetX, 0, (int) offsetZ);

                // 检测这个位置的地面是否是草地/泥土，且上方是空气
                // 我们循环往下找一下地面，防止由于高低落差导致生成失败
                for (int y = 1; y >= -2; y--) {
                    BlockPos groundPos = targetPos.offset(0, y, 0);
                    BlockState groundState = serverLevel.getBlockState(groundPos);
                    BlockPos flowerPos = groundPos.above();

                    // 如果地面是草方块或泥土，且上面一格是空气
                    if ((groundState.is(net.minecraft.world.level.block.Blocks.GRASS_BLOCK) ||
                            groundState.is(net.minecraft.world.level.block.Blocks.DIRT)) &&
                            serverLevel.isEmptyBlock(flowerPos)) {

                        // 随机决定是不是放玩家给的那种花，或者随机放一朵别的
                        net.minecraft.world.level.block.Block blockToPlace = BlockInit.PINK_ROSE.get();

                        serverLevel.setBlockAndUpdate(flowerPos, blockToPlace.defaultBlockState());
                        break; // 放置成功后就不再往下找了
                    }
                }
            }
            // 播放一点自然生长的音效
            serverLevel.playSound(null, pos, SoundEvents.BONE_MEAL_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
    }

    public static void spawnWitherRoseAround(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            int flowerCount = level.random.nextInt(5); // 随机生成 4~8 朵花

            for (int i = 0; i < flowerCount; i++) {
                // 在祭坛周围 3~6 格范围内随机寻找位置
                double offsetX = (level.random.nextDouble() - 0.5) * 12.0D;
                double offsetZ = (level.random.nextDouble() - 0.5) * 12.0D;
                BlockPos targetPos = pos.offset((int) offsetX, 0, (int) offsetZ);

                // 检测这个位置的地面是否是草地/泥土，且上方是空气
                // 我们循环往下找一下地面，防止由于高低落差导致生成失败
                for (int y = 1; y >= -2; y--) {
                    BlockPos groundPos = targetPos.offset(0, y, 0);
                    BlockState groundState = serverLevel.getBlockState(groundPos);
                    BlockPos flowerPos = groundPos.above();

                    // 如果地面是草方块或泥土，且上面一格是空气
                    if (groundState.is(Blocks.GRASS_BLOCK) ||
                            groundState.is(Blocks.SAND) || groundState.is(Blocks.SOUL_SAND)  &&
                            serverLevel.isEmptyBlock(flowerPos)) {

                        // 随机决定是不是放玩家给的那种花，或者随机放一朵别的
                        net.minecraft.world.level.block.Block blockToPlace = Blocks.WITHER_ROSE;

                        serverLevel.setBlockAndUpdate(flowerPos, blockToPlace.defaultBlockState());
                        break; // 放置成功后就不再往下找了
                    }
                }
            }
            // 播放一点自然生长的音效
            serverLevel.playSound(null, pos, SoundEvents.BONE_MEAL_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
    }

    // 【新增】生成水牢陷阱
    public static void spawnWaterPrison(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            // 水牢生成在祭坛上方 1 格
            BlockPos basePos = pos.above();
            int radius = 1; // 3x3 大小，半径就是 1

            // 1. 建造水牢结构
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    for (int y = 0; y <= 3; y++) {
                        BlockPos target = basePos.offset(x, y, z);

                        // 底层 (y=0): 9 个木板
                        if (y == 0) {
                            serverLevel.setBlockAndUpdate(target, net.minecraft.world.level.block.Blocks.OAK_PLANKS.defaultBlockState());
                        }
                        // 中间层 (y=1): 围墙栅栏，内部空气
                        else if (y == 1) {
                            if (Math.abs(x) == radius || Math.abs(z) == radius) {
                                // 外圈栅栏
                                serverLevel.setBlockAndUpdate(target, net.minecraft.world.level.block.Blocks.OAK_FENCE.defaultBlockState());
                            } else {
                                // 内部空气（之后会灌水）
                                serverLevel.setBlockAndUpdate(target, Blocks.AIR.defaultBlockState());
                            }
                        }
                        // 水层 (y=2): 全部灌水
                        else if (y == 2) {
                            serverLevel.setBlockAndUpdate(target, Blocks.WATER.defaultBlockState());
                        }
                        // 顶层 (y=3): 木板封顶
                        else if (y == 3) {
                            serverLevel.setBlockAndUpdate(target, net.minecraft.world.level.block.Blocks.OAK_PLANKS.defaultBlockState());
                        }
                    }
                }
            }

            // 2. 把附近玩家传送到水牢正中心
            AABB area = new AABB(pos).inflate(10.0D);
            List<ServerPlayer> players = serverLevel.getEntitiesOfClass(ServerPlayer.class, area);

            for (ServerPlayer player : players) {
                // 传送到中间的水里
                player.teleportTo(basePos.getX() + 0.5D, basePos.getY() + 2.0D, basePos.getZ() + 0.5D);
            }

            // 3. 播放音效和提示
            serverLevel.playSound(null, pos, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 1.0F, 1.0F);
            serverLevel.playSound(null, pos, SoundEvents.BUCKET_EMPTY, SoundSource.BLOCKS, 1.0F, 1.0F);


        }
    }

    // 【新增】水瓶仪式：碎裂特效与力量效果
    public static void triggerPotionSplash(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            double x = pos.getX() + 0.5D;
            double y = pos.getY() + 1.0D;
            double z = pos.getZ() + 0.5D;

            // 1. 播放药水碎裂的粒子特效（原版水瓶碎裂音效 + 水花粒子）
            serverLevel.sendParticles(net.minecraft.core.particles.ParticleTypes.SPLASH, x, y, z, 50, 0.5D, 0.5D, 0.5D, 0.1D);
            serverLevel.sendParticles(net.minecraft.core.particles.ParticleTypes.ITEM_SLIME, x, y, z, 20, 0.3D, 0.3D, 0.3D, 0.1D);
            serverLevel.playSound(null, pos, SoundEvents.SPLASH_POTION_BREAK, SoundSource.BLOCKS, 1.0F, 1.0F);

            // 2. 寻找周围 8 格内的玩家并给予力量效果
            AABB area = new AABB(pos).inflate(8.0D);
            List<ServerPlayer> players = serverLevel.getEntitiesOfClass(ServerPlayer.class, area);

            for (ServerPlayer player : players) {
                // 给予力量效果：持续 30 秒（600 ticks），等级 II（ amplifier 1 表示二级）
                player.addEffect(new net.minecraft.world.effect.MobEffectInstance(EffectInit.PLAGAS.get(), 600, 1, false, true, true));
            }

            // 3. （可选）生成一个真实的喷溅型药水实体来模拟更真实的破裂效果
            /*
            net.minecraft.world.entity.projectile.ThrownPotion potion = new net.minecraft.world.entity.projectile.ThrownPotion(level, x, y, z);
            potion.setItem(new ItemStack(Items.SPLASH_POTION));
            potion.setDeltaMovement(0, 0.5D, 0); // 向上抛出
            serverLevel.addFreshEntity(potion);
            */
        }
    }

    // 喷出活鱼
    public static void triggerLiveFishFountain(Level level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel) {
            int fishCount = 3 + level.random.nextInt(4); // 3~6条活鱼

            for (int i = 0; i < fishCount; i++) {
                // 随机选择实体类型
                EntityType<?> fishType = level.random.nextBoolean() ? EntityType.COD : EntityType.SALMON;

                // 创建活鱼实体
                net.minecraft.world.entity.animal.AbstractFish fish = (net.minecraft.world.entity.animal.AbstractFish) fishType.create(serverLevel);
                if (fish != null) {
                    // 让鱼从祭坛正上方生成
                    fish.moveTo(pos.getX() + 0.5D, pos.getY() + 1.2D, pos.getZ() + 0.5D,
                            level.random.nextFloat() * 360F, 0.0F);

                    // 同样给一个向上的喷泉初速度
                    fish.setDeltaMovement(
                            (level.random.nextDouble() - 0.5D) * 0.5D,
                            0.6D + level.random.nextDouble() * 0.4D,
                            (level.random.nextDouble() - 0.5D) * 0.5D
                    );

                    serverLevel.addFreshEntity(fish);
                }
            }
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.isActivated = tag.getBoolean("IsActivated");
        this.tickCount = tag.getInt("TickCount");
        this.cooldown = tag.getInt("Cooldown");
        if (tag.contains("StoredItem")) {
            this.storedItem = ItemStack.of(tag.getCompound("StoredItem"));
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putBoolean("IsActivated", this.isActivated);
        tag.putInt("TickCount", this.tickCount);
        tag.putInt("Cooldown", this.cooldown);
        if (!storedItem.isEmpty()) {
            tag.put("StoredItem", storedItem.save(new CompoundTag()));
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = new CompoundTag();
        tag.put("StoredItem", this.storedItem.save(new CompoundTag()));
        tag.putBoolean("IsActivated", this.isActivated);
        tag.putInt("TickCount", this.tickCount);
        tag.putInt("Cooldown", this.cooldown);
        return tag;
    }

    @Override
    public void handleUpdateTag(CompoundTag tag) {
        this.storedItem = ItemStack.of(tag.getCompound("StoredItem"));
        this.isActivated = tag.getBoolean("IsActivated");
        this.tickCount = tag.getInt("TickCount");
        this.cooldown = tag.getInt("Cooldown");
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    public boolean isActivated() {
        return isActivated;
    }
}