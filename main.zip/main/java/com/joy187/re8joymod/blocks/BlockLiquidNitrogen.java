package com.joy187.re8joymod.blocks;

import com.joy187.re8joymod.entity.EntityVerdugo;
import com.joy187.re8joymod.init.EffectInit;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.function.Predicate;

public class BlockLiquidNitrogen extends Block {
    protected static final VoxelShape SHAPE = Block.box(2.0D, 0.0D, 2.0D, 14.0D, 20.0D, 14.0D);

    public BlockLiquidNitrogen() {
        super(Properties.copy(Blocks.STONE).
                strength(3f,3f).sound(SoundType.METAL).requiresCorrectToolForDrops());
    }

    private static final Predicate<Entity> OIL_AREA = (entity) -> {
        return entity.isAlive();
    };

    @Override
    public void onProjectileHit(Level level, BlockState state, BlockHitResult hit, Projectile projectile) {
        if (level.isClientSide) return; // 只在服务端执行

        BlockPos pos = hit.getBlockPos(); // 准确坐标

        Entity entity = projectile.getOwner();
        if (entity instanceof ServerPlayer serverplayer) {
            serverplayer.awardStat(Stats.TARGET_HIT);
            CriteriaTriggers.TARGET_BLOCK_HIT.trigger(serverplayer, projectile, hit.getLocation(), 1);
        }

        AABB aabb = new AABB(pos).inflate(3D);
        for (LivingEntity lvt : level.getEntitiesOfClass(LivingEntity.class, aabb, OIL_AREA)) {
            lvt.addEffect(new MobEffectInstance(EffectInit.STUN.get(), 200, 0));
            if (lvt instanceof EntityVerdugo verdugo) {
                verdugo.onLiquidNitrogenBurst();
            }
        }

        for (int x = -1; x <= 1; x++)
            for (int y = -1; y <= 1; y++)
                for (int z = -1; z <= 1; z++) {
                    BlockPos pos1 = pos.offset(x, y, z);
                    BlockState s = level.getBlockState(pos1);
                    if (s.is(Blocks.FIRE) || s.is(Blocks.SOUL_FIRE)) {
                        level.removeBlock(pos1, false);
                    } else if (s.is(Blocks.LAVA)) {
                        level.setBlock(pos1, Blocks.OBSIDIAN.defaultBlockState(), 3);
                    } else if (s.is(Blocks.WATER)) {
                        level.setBlock(pos1, Blocks.BLUE_ICE.defaultBlockState(), 3);
                    }
                }

        // 先移除本体，再爆炸（爆炸用 NONE，不会炸方块，但中心点用方块中心更准）
        level.removeBlock(pos, false);
        level.explode(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                2.0F, Level.ExplosionInteraction.NONE);
    }

    public VoxelShape getShape(BlockState p_52988_, BlockGetter p_52989_, BlockPos p_52990_, CollisionContext p_52991_) {
        return SHAPE;
    }
}
