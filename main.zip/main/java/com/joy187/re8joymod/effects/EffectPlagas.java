package com.joy187.re8joymod.effects;

import com.joy187.re8joymod.entity.*;
import com.joy187.re8joymod.init.EffectInit;
import com.joy187.re8joymod.init.EntityInit;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class EffectPlagas extends BaseEffect {

    public EffectPlagas(MobEffectCategory type, int color, boolean isInstant) {
        super(type, color, isInstant);
    }

    @Override
    protected boolean canApplyEffect(int remainingTicks, int level) {
        return remainingTicks % 5 == 0;
    }

    @Override
    public void applyEffectTick(LivingEntity living, int amplified) {
        amplified++;
        if (living.getEffect(EffectInit.PLAGAS.get()) == null) return;

        // 只在效果即将结束的最后 5 tick 触发爆发/变异
        if (living.getEffect(EffectInit.PLAGAS.get()).getDuration() == 5) {

            // ==========================================
            // 1. 优先处理变异转换 (转化后直接 return，防止多重判定)
            // ==========================================
            if (living instanceof EntityZealot) {
                convertToPlagas(living, new EntityPlagasm(EntityInit.PLAGASM.get(), living.level()));
                return;
            }
            if (living instanceof Wolf) {
                convertToPlagas(living, new EntityEvilDog(EntityInit.EVILDOG.get(), living.level()));
                return;
            }
            if (living instanceof EntityEvilDog) {
                convertToPlagas(living, new EntityPlagasDog(EntityInit.PLAGASDOG.get(), living.level()));
                return;
            }
            if (living instanceof EntityRegenerator) {
                convertToPlagas(living, new EntityRegenerator2(EntityInit.REGENERATOR2.get(), living.level()));
                return;
            }
            if (living instanceof AbstractSkeleton) {
                convertToPlagas(living, new EntityFaceEater(EntityInit.FE.get(), living.level()));
                return;
            }
            if (living instanceof Villager) {
                convertToPlagas(living, new EntityPlagasVillager(EntityInit.PLAGASVILLAGER.get(), living.level()));
                return;
            }
            if (living instanceof Zombie) {
                convertToPlagas(living, new EntityPlagasZombie(EntityInit.PLAGASZOMBIE.get(), living.level()));
                return;
            }
            if (living instanceof EnderMan) {
                convertToPlagas(living, new EntityPlagasEnderman(EntityInit.PLAGASENDERMAN.get(), living.level()));
                return;
            }
            if (living instanceof Creeper) {
                convertToPlagas(living, new EntityPlagasCreeper(EntityInit.PLAGASCREEPER.get(), living.level()));
                return;
            }

            // ==========================================
            // 2. 如果是玩家，按概率触发直接伤害或负面效果
            // ==========================================
            if (living instanceof Player) {
                int k = living.getRandom().nextInt(10);
                if (k < 4) {
                    // 40% 概率：直接造成高额物理伤害 (仙人掌类型)
                    living.hurt(living.damageSources().cactus(), 10F * amplified);
                } else if (k > 8) {
                    // 10% 概率：赋予增益 (Zenheart)
                    living.addEffect(new MobEffectInstance(EffectInit.ZENHEART.get(), 200, 0));
                } else {
                    // 50% 概率：赋予严重负面效果 (Deadly)
                    living.addEffect(new MobEffectInstance(EffectInit.DEADLY.get(), 200, 1));
                }
                return;
            }

            // ==========================================
            // 3. 其他普通生物（伤害已下调）
            // ==========================================
            if (living.getRandom().nextFloat() < 0.3f) {
                // 30% 概率：造成 25% 最大生命值的魔法伤害（原为 90%，已大幅下调防秒杀）
                living.hurt(living.damageSources().magic(), living.getMaxHealth() * 0.25f);
            } else {
                // 70% 概率：挂上 3 级灼烧
                living.addEffect(new MobEffectInstance(EffectInit.BURN.get(), 200, 3));
            }
        }
    }

    /**
     * 统一的变异转化逻辑
     */
    private void convertToPlagas(LivingEntity oldEntity, LivingEntity newEntity) {
        Level level = oldEntity.level();
        newEntity.copyPosition(oldEntity);
        oldEntity.discard();

        level.playSound(null, oldEntity.getX(), oldEntity.getY(), oldEntity.getZ(),
                SoundEvents.ZOMBIE_INFECT, SoundSource.PLAYERS, 1.0F,
                1.0F / (oldEntity.getRandom().nextFloat() * 0.4F + 1.2F) + 0.5F);

        level.addFreshEntity(newEntity);
    }

    @Override
    public boolean isBeneficial() {
        return false;
    }
}