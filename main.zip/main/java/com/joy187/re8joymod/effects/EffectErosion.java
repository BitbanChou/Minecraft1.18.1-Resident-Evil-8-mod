package com.joy187.re8joymod.effects;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

public class EffectErosion extends BaseEffect {

	public EffectErosion(MobEffectCategory type, int color, boolean isInstant) {
		super(type, color, isInstant);
	}

	@Override
	protected boolean canApplyEffect(int remainingTicks, int level) {
		// 每 20 tick（1秒）触发一次，降低频率，防止几秒钟扒光玩家
		return remainingTicks % 20 == 0;
	}

	@Override
	public void applyEffectTick(LivingEntity living, int amplified) {
		// amplified 从 0 开始，+1 变成实际等级
		int level = amplified + 1;

		// 创造模式玩家免疫
		if (living instanceof net.minecraft.world.entity.player.Player player && player.isCreative()) {
			return;
		}

		// 获得所有有耐久的装备槽
		EquipmentSlot[] slots = {
				EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,
				EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND
		};

		// 每次只随机破坏 1~2 个槽位的装备，而不是全身一起掉耐久
		int breakCount = Math.min(level, 2); // 最高同时损坏 2 个槽位
		for (int i = 0; i < breakCount; i++) {
			EquipmentSlot slot = slots[living.getRandom().nextInt(slots.length)];
			ItemStack stack = living.getItemBySlot(slot);

			// 如果该槽位有可以掉耐久的物品
			if (!stack.isEmpty() && stack.isDamageableItem()) {
				// 每次扣除 1 * 等级 点耐久
				int damageAmount = level;

				// 执行掉耐久逻辑（自动触发 broadcastBreakEvent 碎装备音效）
				stack.hurtAndBreak(damageAmount, living, (entity) -> {
					entity.broadcastBreakEvent(slot);
				});
			}
		}

		// 视觉反馈：身上冒出灰烬粒子
		if (living.level() instanceof ServerLevel server) {
			server.sendParticles(ParticleTypes.ASH,
					living.getX(), living.getY() + living.getBbHeight() * 0.5, living.getZ(),
					3, // 粒子数量
					0.4, 0.4, 0.4, 0.02);
		}
	}

	@Override
	public boolean isBeneficial() {
		return false;
	}
}