package com.joy187.re8joymod.entity;

import com.joy187.re8joymod.init.ParticleInit;
import com.joy187.re8joymod.util.CommonFunctions;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ToolActions;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;
import java.util.Random;
import java.util.function.Predicate;

public class EntityElg extends EntityU3 implements GeoEntity {

    private final AnimatableInstanceCache factory = GeckoLibUtil.createInstanceCache(this);

    private int attr = 0, attackTimer = 0;
    private boolean zuan = false;

    // ===== 硬直 =====
    private int stunTimer = 0;
    private static final int BASE_STUN_TICKS = 45;
    // ================

    // ===== 骑乘控制 =====
    private int rideTimer = 0;
    private static final int RIDE_DURATION = 40;
    // ====================

    // ===== 冲撞加速 =====
    private static final double NORMAL_SPEED_MOD = 0.4D;
    private static final double CHARGE_SPEED = 0.25D;
    // ====================

    public EntityElg(EntityType<? extends Ravager> type, Level worldIn) {
        super(type, worldIn);
        this.attackTimer = 0;
        this.zuan = false;
    }

    public static AttributeSupplier.Builder prepareAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 450.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.10D)
                .add(Attributes.FOLLOW_RANGE, 28.0D)
                .add(Attributes.ARMOR, 1.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 2.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.75D)
                .add(Attributes.ATTACK_DAMAGE, 10.0D);
    }

    // ===== 硬直 =====
    public boolean isStunned() {
        return this.stunTimer > 0;
    }
    // ================

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(1, new RandomLookAroundGoal(this));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 8.0F));

        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true) {
            @Override
            public boolean canUse() {
                return !isStunned() && super.canUse();
            }
            @Override
            public boolean canContinueToUse() {
                return !isStunned() && super.canContinueToUse();
            }
        });

        this.addBehaviourGoals();
    }

    protected void addBehaviourGoals() {
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.targetSelector.addGoal(1, (new HurtByTargetGoal(this)).setAlertOthers(ZombifiedPiglin.class));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Creeper.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractVillager.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
    }

    private static final Predicate<Entity> ELG_AREA = (entity) ->
            entity.isAlive() && !(entity instanceof EntityElg);

    // ===== 硬直：锁移动/跳跃/转向 =====
    @Override
    protected void updateControlFlags() {
        if (this.entityData.get(STATE) == 4) {
            this.goalSelector.setControlFlag(Goal.Flag.MOVE, false);
            this.goalSelector.setControlFlag(Goal.Flag.JUMP, false);
            this.goalSelector.setControlFlag(Goal.Flag.LOOK, false);
            this.goalSelector.setControlFlag(Goal.Flag.TARGET, true);
            return;
        }
        super.updateControlFlags();
    }
    // ==================================

    @Override
    public void tick() {
        super.tick();

        // ===== 硬直处理（最前，短路后续攻击逻辑） =====
        if (this.stunTimer > 0) {
            this.stunTimer--;
            this.getNavigation().stop();
            this.setDeltaMovement(0, this.getDeltaMovement().y, 0);
            if (this.stunTimer == 0) {
                this.setAttackingState(0);
            }
            return;
        }
        // ==================================================

        // ===== 目标无效时强制重置攻击状态（修复：目标死亡后不播走路动画） =====
        LivingEntity target = this.getTarget();
        if ((target == null || !target.isAlive()) && this.getAttckingState() != 0) {
            this.setAttackingState(0);
            this.attackTimer = -10;
            this.attr = 0;
            this.zuan = false;
            this.rideTimer = 0;
            for (Entity passenger : this.getPassengers()) {
                passenger.stopRiding();
            }
            return;
        }
        // ==================================================================

        // ===== 骑乘倒计时（到点强制放下） =====
        if (this.rideTimer > 0) {
            this.rideTimer--;
            if (this.rideTimer == 0) {
                for (Entity passenger : this.getPassengers()) {
                    passenger.stopRiding();
                }
            }
        }
        // ==================================

        if (this.getTarget() != null) {
            this.setAggressive(true);

            LivingEntity livingentity = this.getTarget();
            if (livingentity != null && this.hasLineOfSight(livingentity)) {
                ++this.attackTimer;
                Random rand = new Random();
                Vec3 vector3d = this.getViewVector(1.0F);

                this.attr = this.attackTimer;

                // ===== 冲撞期间用冲撞速度，平时用普通导航 =====
                if (this.getAttckingState() == 2 && this.attackTimer >= 20 && this.attackTimer <= 30) {
                    Vec3 look = this.getViewVector(1.0F);
                    this.setDeltaMovement(look.x * CHARGE_SPEED, this.getDeltaMovement().y, look.z * CHARGE_SPEED);
                } else {
                    this.getNavigation().moveTo(livingentity, NORMAL_SPEED_MOD);
                }
                // ============================================

                // 钻地（原逻辑保留）
                if (rand.nextInt(100) < 20 && !this.zuan) {
                    this.setDeltaMovement(vector3d);
                    this.zuan = false;
                } else {
                    if (this.attackTimer == 20) {
                        if (rand.nextInt(100) < 50) {
                            this.setAttackingState(3);
                            this.triggerAnim("controller1", "doubleSmash");
                        } else {
                            this.setAttackingState(2);
                            this.triggerAnim("controller1", "charge");
                            if (!livingentity.hasPassenger(this) && !(livingentity instanceof EnderDragon)
                                    && livingentity.getBbWidth() < 1.81F) {
                                livingentity.stopRiding();
                                livingentity.startRiding(this, true);
                                this.rideTimer = RIDE_DURATION;
                            }
                        }
                    } else if (this.attackTimer == 45) {
                        if (this.getAttckingState() == 3) {
                            for (LivingEntity lvt : this.level().getEntitiesOfClass(
                                    LivingEntity.class, this.getBoundingBox().inflate(1.0D), ELG_AREA)) {
                                lvt.hurt(lvt.damageSources().mobAttack(this), lvt.getMaxHealth() * 0.25f);
                            }
                        }
                    } else if (this.attackTimer == 30) {
                        if (this.getAttckingState() == 2) {
                            for (LivingEntity lvt : this.level().getEntitiesOfClass(
                                    LivingEntity.class, this.getBoundingBox().inflate(0.5D), ELG_AREA)) {
                                double d00 = lvt.getX() - this.getX();
                                double d10 = lvt.getZ() - this.getZ();
                                double d20 = Math.max(d00 * d00 + d10 * d10, 0.001D);
                                lvt.push(d00 / d20 * 4.0D, 0.2D, d10 / d20 * 4.0D);
                                lvt.hurt(lvt.damageSources().mobAttack(this),
                                        lvt.getArmorValue() + lvt.getMaxHealth() * 0.15f);
                            }
                        }
                        this.level().addParticle(ParticleInit.MUCUS_PARTICLE.get(),
                                this.getRandomX(0.5), this.getRandomY(), this.getRandomZ(0.5),
                                0.0, 0.0, 0.0);
                    } else if (this.attackTimer == 1) {
                        this.setAttackingState(1);
                        this.triggerAnim("controller1", "jumpSmash");
                        this.setDeltaMovement(0, 0.45 + this.random.nextDouble() * 0.15, 0);
                    }
                }

                if (this.attackTimer == 18 && this.getAttckingState() == 1) {
                    for (int l = 1; l < 10; l++) {
                        this.blockSmashAttack(l, 3F, 1.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, -1.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, 2.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, -2.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, 3.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, -3.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, 4.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, -4.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, 5.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, -5.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, 6.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, -6.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, 7.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, -7.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, 8.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, -8.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, 9.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.blockSmashAttack(l, 3F, -9.5F, 150, 1.5F, 0.15F, 1.0F);
                    }
                    EntityCameraShake.ScreenShake(this.level(),
                            new Vec3(this.getX(), this.getY(), this.getZ()), 30.0f, 0.15f, 0, 50);
                    for (LivingEntity lvt : this.level().getEntitiesOfClass(
                            LivingEntity.class, this.getBoundingBox().inflate(1.1D), ELG_AREA)) {
                        double d00 = lvt.getX() - this.getX();
                        double d10 = lvt.getZ() - this.getZ();
                        double d20 = Math.max(d00 * d00 + d10 * d10, 0.001D);
                        lvt.getDeltaMovement().add(d00 * 0.2D, d20 + rand.nextDouble(), d10 * 0.2D);
                    }
                }

                this.lookAt(livingentity, 30.0F, 30.0F);
            }
        }

        // ===== 攻击结束 → 进硬直 =====
        if (this.attackTimer >= 80) {
            this.setAttackingState(4);
            this.attackTimer = -10;
            this.attr = 0;
            this.zuan = false;

            for (Entity passenger : this.getPassengers()) {
                passenger.stopRiding();
            }
            this.rideTimer = 0;

            float hpRatio = this.getHealth() / this.getMaxHealth();
            this.stunTimer = (int) (BASE_STUN_TICKS * (0.5F + 0.5F * hpRatio));
            this.triggerAnim("controller1", "stun");
        }
        // ==================================================
    }

    // ===== 硬直：受击缩短 =====
    @Override
    public boolean hurt(DamageSource source, float amount) {
        // 1. 计算非玩家减伤后的最终伤害
        float finalDamage = CommonFunctions.applyNonPlayerReduction(this, source, amount);

        // 2. 扣血（传入 finalDamage）
        boolean result = super.hurt(source, finalDamage);

        // 3. 硬直削减逻辑（保持原版逻辑）
        if (result && this.stunTimer > 20) {
            this.stunTimer = Math.max(10, this.stunTimer - 5);
        }
        return result;
    }
    // ========================

    @Override
    public void aiStep() {
        super.aiStep();
        this.hurt(this.level().getEntities(this,
                this.getBoundingBox().inflate(0.6D), EntitySelector.NO_CREATIVE_OR_SPECTATOR));
        if (this.entityData.get(STATE) == 2) {
            this.roar();
        }
    }

    private void roar() {
        if (this.isAlive()) {
            Vec3 vec3 = this.getBoundingBox().getCenter();
            for (int i = 0; i < 10; i++) {
                float deltaOmega = 1.0f * i;
                Vec3 pos = new Vec3(vec3.x + Math.sin(deltaOmega), vec3.y, vec3.z + Math.cos(deltaOmega));
                this.level().addParticle(ParticleInit.MUCUS_PARTICLE.get(),
                        pos.x, pos.y, pos.z, 0, 0, 0);
            }
            this.level().gameEvent(this, GameEvent.ENTITY_ROAR, this.getEyePosition());
        }
    }

    private void hurt(List<Entity> entities) {
        for (Entity entity : entities) {
            if (entity instanceof LivingEntity) {
                entity.hurt(damageSources().mobAttack(this), 4.0F * random.nextFloat());
                this.doEnchantDamageEffects(this, entity);
                if (!this.isStunned() && random.nextInt(10) > 8) {
                    this.heal(random.nextFloat() * 2);
                }
            }
        }
    }

    private void blockSmashAttack(int distance, float mxy, float math, int shieldbreakticks,
                                  float damage, float hpdamage, float airborne) {
        int hitY = Mth.floor(this.getBoundingBox().minY - 0.5);
        double minY = this.getY() - 2.0;
        double maxY = this.getY() + mxy;
        float angle = (float) Math.PI / 180 * this.yBodyRot;
        float f = Mth.cos(this.getYRot() * ((float) Math.PI / 180));
        float f1 = Mth.sin(this.getYRot() * ((float) Math.PI / 180));
        double extraX = distance * Mth.sin((float) (Math.PI + angle));
        double extraZ = distance * Mth.cos(angle);
        double px = this.getX() + extraX + f * math;
        double pz = this.getZ() + extraZ + f1 * math;
        int hitX = Mth.floor(px);
        int hitZ = Mth.floor(pz);
        BlockPos pos = new BlockPos(hitX, hitY, hitZ);
        BlockPos abovePos = pos.above();
        BlockState block = this.level().getBlockState(pos);
        BlockState blockAbove = this.level().getBlockState(abovePos);
        if (block.getBlock() != Blocks.AIR && !block.hasBlockEntity() && !blockAbove.blocksMotion()) {
            EntityFallingBlock fallingBlockEntity = new EntityFallingBlock(this.level(),
                    hitX + 0.5, hitY + 1.0, hitZ + 0.5, block, 10);
            fallingBlockEntity.push(0.0, 0.2 + this.getRandom().nextGaussian() * 0.15, 0.0);
            this.level().addFreshEntity(fallingBlockEntity);
        }
        AABB selection = new AABB(px - 0.5, minY, pz - 0.5, px + 0.5, maxY, pz + 0.5);
        List<LivingEntity> hit = this.level().getEntitiesOfClass(LivingEntity.class, selection);
        for (LivingEntity entity : hit) {
            if (this.isAlliedTo(entity) || entity instanceof EntityHeisen || entity == this) continue;
            if (entity instanceof Player player
                    && player.getUseItem().canPerformAction(ToolActions.SHIELD_BLOCK)
                    && shieldbreakticks > 0) {
                disableShield(player, shieldbreakticks);
            } else {
                boolean flag = entity.hurt(damageSources().mobAttack(this),
                        (float) (this.getAttributeValue(Attributes.ATTACK_DAMAGE) * damage
                                + entity.getMaxHealth() * hpdamage));
                if (flag)
                    entity.setDeltaMovement(entity.getDeltaMovement().add(0.0, airborne + 0.5, 0.0));
            }
        }
    }

    public static void disableShield(LivingEntity livingEntity, int ticks) {
        if (!(livingEntity instanceof Player player)) return;
        player.getCooldowns().addCooldown(livingEntity.getUseItem().getItem(), ticks);
        livingEntity.getUseItem().hurtAndBreak(5 + livingEntity.getRandom().nextInt(2),
                livingEntity, p -> p.broadcastBreakEvent(livingEntity.getUsedItemHand()));
        livingEntity.stopUsingItem();
        livingEntity.level().broadcastEntityEvent(livingEntity, (byte) 30);
    }

    // ==========================================
    // GeckoLib 4.x 动画控制器
    // ==========================================
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar data) {
        AnimationController<EntityElg> actionController =
                new AnimationController<>(this, "controller1", 3, state -> PlayState.STOP)
                        .triggerableAnim("jumpSmash",   RawAnimation.begin().thenPlay("animation.u3.attack3"))
                        .triggerableAnim("charge",      RawAnimation.begin().thenPlay("animation.u3.attack"))
                        .triggerableAnim("doubleSmash", RawAnimation.begin().thenPlay("animation.u3.attack2"))
                        .triggerableAnim("stun",        RawAnimation.begin().thenPlay("animation.u3.stun"));

        data.add(actionController);
        data.add(new AnimationController<>(this, "controller", 5, this::predicate));
    }

    private <E extends GeoAnimatable> PlayState predicate(AnimationState<E> event) {
        if (this.entityData.get(STATE) != 0) {
            return PlayState.STOP;
        }
        if (this.dead || this.getHealth() < 0.01 || this.isDeadOrDying()) {
            event.setAndContinue(RawAnimation.begin().thenPlay("animation.u3.death"));
            return PlayState.CONTINUE;
        }
        if (event.isMoving()) {
            event.setAndContinue(RawAnimation.begin().thenPlay("animation.u3.walk"));
            return PlayState.CONTINUE;
        }
        event.setAndContinue(RawAnimation.begin().thenPlay("animation.u3.idle"));
        return PlayState.CONTINUE;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.factory;
    }
}