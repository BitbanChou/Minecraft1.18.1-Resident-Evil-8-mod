package com.joy187.re8joymod.entity;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;

import javax.annotation.Nullable;

import com.joy187.re8joymod.init.BlockInit;
import com.joy187.re8joymod.init.EntityInit;
import com.joy187.re8joymod.init.SoundInit;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ToolActions;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;

public class EntityMiranda1 extends Ravager implements GeoEntity {

    // ==================== 状态常量 ====================
    public static final int STATE_IDLE = 0;
    public static final int STATE_ATTACK = 1;
    public static final int STATE_ATTACK2 = 2;
    public static final int STATE_STAGGER = 3;
    public static final int STATE_RECOVER = 4;

    // ==================== 硬直参数（按技能次数触发） ====================
    private static final int STAGGER_DURATION = 30;            // 1.5s
    private static final int RECOVER_DURATION = 20;            // 1.0s
    private static final int SKILLS_PER_STAGGER_CHECK = 4;     // 每 4 次技能判定一次
    private static final float STAGGER_CHANCE = 0.35F;         // 判定后 35% 概率进入硬直

    // ==================== 变身 Mia 参数 ====================
    private static final float MIA_FORM_HP_RATIO = 0.35F;
    private static final int MIA_FORM_COOLDOWN = 20 * 20;      // 20s
    private static final int MIA_FORM_DURATION = 20 * 5;       // 5s

    private AnimatableInstanceCache factory = GeckoLibUtil.createInstanceCache(this);

    private final ServerBossEvent bossInfo = (ServerBossEvent) (new ServerBossEvent(
            this.getDisplayName(), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS))
            .setDarkenScreen(true);

    private static final EntityDataAccessor<Integer> DATA_ID_INV =
            SynchedEntityData.defineId(EntityMiranda1.class, EntityDataSerializers.INT);
    public static final EntityDataAccessor<Integer> STATE =
            SynchedEntityData.defineId(EntityMiranda1.class, EntityDataSerializers.INT);
    public static final EntityDataAccessor<Integer> DEFENDSTATE =
            SynchedEntityData.defineId(EntityMiranda1.class, EntityDataSerializers.INT);
    /** 0=正常, 1=硬直, 2=恢复 */
    public static final EntityDataAccessor<Integer> STAGGER_STATE =
            SynchedEntityData.defineId(EntityMiranda1.class, EntityDataSerializers.INT);

    // ==================== 运行时字段 ====================
    private int skillCount = 0;          // 已完整释放技能次数
    private int staggerTicks = 0;
    private int recoverTicks = 0;
    private int healFlags = 0;
    private int miaFormCooldown = 0;

    private static final Predicate<LivingEntity> LIVING_ENTITY_SELECTOR = (p) ->
            p.getMobType() != MobType.UNDEAD && p.attackable();

    public EntityMiranda1(EntityType<? extends Ravager> type, Level worldIn) {
        super(type, worldIn);
        this.xpReward = 280;
        this.isNonBoss();
        this.setPathfindingMalus(BlockPathTypes.LAVA, 8.0F);
    }

    protected boolean isSunSensitive() {
        return true;
    }

    public static AttributeSupplier.Builder prepareAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 200.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.32D)
                .add(Attributes.FOLLOW_RANGE, 28.0D)
                .add(Attributes.ARMOR, 5.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 5.0D)
                .add(Attributes.ATTACK_DAMAGE, 8.5D);
    }

    // ==================== AI 目标 ====================
    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(1, new AttackGoal(this));
        this.goalSelector.addGoal(1, new RandomLookAroundGoal(this));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(
                this, LivingEntity.class, 0, false, false, LIVING_ENTITY_SELECTOR));
        this.addBehaviourGoals();
    }

    protected void addBehaviourGoals() {
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.targetSelector.addGoal(1, (new HurtByTargetGoal(this)).setAlertOthers(ZombifiedPiglin.class));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractVillager.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, EntityHeisen.class, true));
    }

    // ==================== 近战 ====================
    @Override
    public boolean doHurtTarget(Entity entityIn) {
        if (!super.doHurtTarget(entityIn)) {
            return false;
        }
        if (entityIn instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.WITHER, 20, 0, true, true));
        }
        return true;
    }

    // ==================== 音效 ====================
    @Override
    protected SoundEvent getDeathSound() {
        return this.random.nextBoolean()
                ? SoundInit.ENTITY_MIRA_DEATH1.get()
                : SoundInit.ENTITY_MIRA_DEATH2.get();
    }

    @Override
    protected SoundEvent getAmbientSound() {
        int co = this.random.nextInt(3);
        if (co == 0) return SoundInit.ENTITY_MIRA_AMBIENT1.get();
        if (co == 1) return SoundInit.ENTITY_MIRA_AMBIENT3.get();
        return SoundInit.ENTITY_MIRA_AMBIENT2.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return this.random.nextBoolean()
                ? SoundInit.ENTITY_MIRA_HURT1.get()
                : SoundInit.ENTITY_MIRA_HURT2.get();
    }

    public int getInvulnerableTicks() {
        return 200;
    }

    public void setInvulnerableTicks(int ticks) {
        this.entityData.set(DATA_ID_INV, ticks);
    }

    // ==================== 存档 ====================
    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setInvulnerableTicks(tag.getInt("Invul"));
        this.healFlags = tag.getInt("HealFlags");
        this.miaFormCooldown = tag.getInt("MiaFormCd");
        this.skillCount = tag.getInt("SkillCount");
        if (this.hasCustomName()) {
            this.bossInfo.setName(this.getDisplayName());
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Invul", this.entityData.get(DATA_ID_INV));
        tag.putInt("HealFlags", this.healFlags);
        tag.putInt("MiaFormCd", this.miaFormCooldown);
        tag.putInt("SkillCount", this.skillCount);
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        this.bossInfo.setName(this.getDisplayName());
    }

    // ==================== 主 AI ====================
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();

        if (this.miaFormCooldown > 0) this.miaFormCooldown--;

        // ---- 硬直 ----
        if (this.staggerTicks > 0) {
            this.staggerTicks--;
            this.getNavigation().stop();
            this.setDeltaMovement(0, Math.min(0, this.getDeltaMovement().y), 0);
            if (this.staggerTicks == 0) {
                this.recoverTicks = RECOVER_DURATION;
                this.entityData.set(STAGGER_STATE, 2);
                this.setAttackingState(STATE_RECOVER);
                this.triggerStateAnim(STATE_RECOVER);
            }
            this.bossInfo.setProgress(this.getHealth() / this.getMaxHealth());
            return;
        }
        // ---- 恢复 ----
        if (this.recoverTicks > 0) {
            this.recoverTicks--;
            this.getNavigation().stop();
            this.setDeltaMovement(0, Math.min(0, this.getDeltaMovement().y), 0);
            if (this.recoverTicks == 0) {
                this.entityData.set(STAGGER_STATE, 0);
                this.setAttackingState(STATE_IDLE);
            }
            this.bossInfo.setProgress(this.getHealth() / this.getMaxHealth());
            return;
        }

        // ---- 变身 Mia ----
        LivingEntity target = this.getTarget();
        if (target != null && target.isAlive()
                && this.miaFormCooldown <= 0
                && this.getHealth() > 10.0F
                && this.getHealth() / this.getMaxHealth() <= MIA_FORM_HP_RATIO) {
            this.becomeMia(target);
            return;
        }

        // ---- 回血（每档一次） ----
        this.tickHealFlags();

        // ---- 阶段转换 ----
        if (this.getHealth() > 0.1F && this.getHealth() <= 10.0F) {
            EntityMiranda2 next = this.convertTo(EntityInit.MIRANDA2.get(), true);
            if (next == null) {
                this.kill();
            }
            return;
        }

        // ---- 粒子 ----
        if (this.getHealth() >= 130.0F && this.getHealth() <= 160.0F) {
            this.level().addParticle(ParticleTypes.LANDING_OBSIDIAN_TEAR,
                    this.getX() + this.random.nextFloat(), this.getY(),
                    this.getZ() + this.random.nextFloat(), 0, 0, 0);
        }

        // ---- 卡墙脱困 ----
        if (this.isInWall()) {
            this.teleportTo(this.getX() + 2 * this.random.nextFloat(), this.getY(),
                    this.getZ() + 2 * this.random.nextFloat());
        }

        this.bossInfo.setProgress(this.getHealth() / this.getMaxHealth());
    }

    // ==================== 硬直（按技能次数触发） ====================
    public boolean isStaggered() {
        return this.staggerTicks > 0 || this.recoverTicks > 0;
    }

    /**
     * 每次技能完整释放后由 AttackGoal 调用。
     * 每满 SKILLS_PER_STAGGER_CHECK 次，按 STAGGER_CHANCE 概率进入硬直。
     */
    public void onSkillFinished() {
        if (this.level().isClientSide) return;
        if (this.isStaggered()) return;   // 已在硬直/恢复中，不重复计数

        this.skillCount++;
        if (this.skillCount >= SKILLS_PER_STAGGER_CHECK) {
            this.skillCount = 0;
            if (this.random.nextFloat() < STAGGER_CHANCE) {
                this.beginStagger();
            }
        }
    }

    public void beginStagger() {
        if (this.isStaggered()) return;
        this.staggerTicks = STAGGER_DURATION;
        this.entityData.set(STAGGER_STATE, 1);
        this.setAttackingState(STATE_STAGGER);
        this.triggerStateAnim(STATE_STAGGER);
        this.getNavigation().stop();
        this.setDeltaMovement(Vec3.ZERO);
        this.level().playSound(null, this.blockPosition(),
                SoundEvents.RAVAGER_STUNNED, SoundSource.HOSTILE, 1.1F, 0.85F);
    }

    // 注意：不再覆盖 hurt 触发硬直；硬直完全由 onSkillFinished 驱动。

    // ==================== 回血（每档一次） ====================
    private void tickHealFlags() {
        float hp = this.getHealth();
        if (!hasFlag(0) && hp >= 10.0F && hp <= 18.0F) { healOnce(2.0F, 5); setFlag(0); }
        if (!hasFlag(1) && hp >= 50.0F && hp <= 55.0F) { healOnce(2.0F, 4); setFlag(1); }
        if (!hasFlag(2) && hp >= 100.0F && hp <= 120.0F) { healOnce(1.5F, 4); setFlag(2); }
        if (!hasFlag(3) && hp >= 130.0F && hp <= 160.0F) { healOnce(1.0F, 3); setFlag(3); }
    }

    private void healOnce(float perTick, int times) {
        float total = 0;
        for (int i = 0; i < times; i++) total += perTick * this.random.nextFloat();
        this.heal(total);
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.HEART,
                    this.getX(), this.getY() + this.getBbHeight() * 0.6, this.getZ(),
                    6, 0.4, 0.4, 0.4, 0.02);
        }
    }

    private boolean hasFlag(int bit) { return (this.healFlags & (1 << bit)) != 0; }
    private void setFlag(int bit) { this.healFlags |= (1 << bit); }

    // ==================== 变身 Mia ====================
    /** Miranda1 → Mia，5 秒后由 Mia 自己变回。 */
    public void becomeMia(LivingEntity target) {
        if (this.level().isClientSide || !(this.level() instanceof ServerLevel server)) return;

        float keepHealth = this.getHealth();
        double sx = this.getX(), sy = this.getY(), sz = this.getZ();
        float yaw = this.getYRot(), pitch = this.getXRot();

        EntityMia mia = new EntityMia(EntityInit.MIA.get(), server);
        mia.moveTo(sx, sy, sz, yaw, pitch);

        // 显式设置血量
        float maxHp = mia.getMaxHealth();
        mia.setHealth(Math.max(1.0F, Math.min(keepHealth, maxHp)));

        // 把血量写进 Mia 的 savedHealth，变回时恢复
        mia.setFromMiranda(true, MIA_FORM_DURATION, keepHealth);

        // 保留目标
        if (target != null && target.isAlive()) {
            mia.setTarget(target);
            mia.setLastHurtByMob(target);
        }

        server.addFreshEntity(mia);

        // 变身特效
        server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                sx, sy + 1.0, sz, 40, 0.6, 0.8, 0.6, 0.05);
        mia.playSound(SoundInit.ENTITY_MIA_AMBIENT1.get(), 1.5F, 0.8F);

        // 本体移除
        this.discard();
    }

    /** 供 EntityMia.revertToMiranda() 调用。 */
    public void setMiaFormCooldown(int ticks) {
        this.miaFormCooldown = Math.max(0, ticks);
    }

    // ==================== Boss 条 ====================
    public boolean isNonBoss() {
        return false;
    }

    public void startSeenByPlayer(ServerPlayer p) {
        super.startSeenByPlayer(p);
        this.bossInfo.addPlayer(p);
    }

    public void stopSeenByPlayer(ServerPlayer p) {
        super.stopSeenByPlayer(p);
        this.bossInfo.removePlayer(p);
    }

    // ==================== 同步数据 ====================
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(STATE, 0);
        this.entityData.define(DEFENDSTATE, 0);
        this.entityData.define(DATA_ID_INV, 0);
        this.entityData.define(STAGGER_STATE, 0);
    }

    public int getAttckingState() {
        return this.entityData.get(STATE);
    }

    public void setAttackingState(int state) {
        if (state < STATE_IDLE || state > STATE_RECOVER) return;
        this.entityData.set(STATE, state);
    }

    public int getDefendingState() {
        return this.entityData.get(DEFENDSTATE);
    }

    public void setDefendingState(int v) {
        this.entityData.set(DEFENDSTATE, v);
    }

    // ==================== 动画控制器（trigger 形式） ====================
    private <E extends GeoAnimatable> PlayState predicateMovement(AnimationState<E> event) {
        if (event.isMoving()) {
            event.setAndContinue(RawAnimation.begin().thenPlay("animation.miranda1.walk"));
            return PlayState.CONTINUE;
        }
        int co = this.random.nextInt(30);
        if (co == 1) {
            event.setAndContinue(RawAnimation.begin().thenPlay("animation.miranda1.idle2"));
            return PlayState.CONTINUE;
        }
        event.setAndContinue(RawAnimation.begin().thenPlay("animation.miranda1.idle"));
        return PlayState.CONTINUE;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar data) {
        data.add(new AnimationController<>(this, "movement", 5, this::predicateMovement));

        AnimationController<?> attackController =
                new AnimationController<>(this, "attack", 0, state -> PlayState.STOP)
                        .triggerableAnim("attack", RawAnimation.begin().thenPlay("animation.miranda1.attack"))
                        .triggerableAnim("attack2", RawAnimation.begin().thenPlay("animation.miranda1.attack2"))
                        .triggerableAnim("stagger", RawAnimation.begin().thenPlay("animation.miranda1.stagger"))
                        .triggerableAnim("recover", RawAnimation.begin().thenPlay("animation.miranda1.recover"));
        data.add(attackController);
    }

    /** 统一入口：根据 STATE 触发对应动画。 */
    private void triggerStateAnim(int state) {
        String name = switch (state) {
            case STATE_ATTACK -> "attack";
            case STATE_ATTACK2 -> "attack2";
            case STATE_STAGGER -> "stagger";
            case STATE_RECOVER -> "recover";
            default -> null;
        };
        if (name != null) {
            this.triggerAnim("attack", name);
        }
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.factory;
    }

    // ==================== AttackGoal ====================
    static class AttackGoal extends Goal {
        private final EntityMiranda1 parentEntity;
        protected int attackTimer = 0;

        public AttackGoal(EntityMiranda1 mob) {
            this.parentEntity = mob;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        public boolean canUse() {
            return this.parentEntity.getTarget() != null;
        }

        public void start() {
            super.start();
            this.parentEntity.setAggressive(true);
        }

        @Override
        public void stop() {
            super.stop();
            this.parentEntity.setAggressive(false);
            this.parentEntity.setAttackingState(STATE_IDLE);
            this.attackTimer = -1;
        }

        public void tick() {
            // 硬直 / 恢复期间不推进攻击；attackTimer 缓慢回退
            if (this.parentEntity.isStaggered()) {
                if (this.attackTimer > 0) --this.attackTimer;
                return;
            }
            LivingEntity target = this.parentEntity.getTarget();
            if (target == null) return;

            if (this.parentEntity.hasLineOfSight(target)) {
                if (!this.parentEntity.hasEffect(MobEffects.DAMAGE_RESISTANCE)) {
                    ++this.attackTimer;
                } else {
                    this.parentEntity.setDefendingState(0);
                }

                if (this.attackTimer == 10) {
                    float hp = this.parentEntity.getHealth() / this.parentEntity.getMaxHealth();
                    boolean charging = (hp >= 0.8F && hp < 0.9F)
                            || (hp >= 0.4F && hp < 0.5F)
                            || (hp >= 0.2F && hp < 0.3F);
                    if (charging) {
                        this.parentEntity.getNavigation().moveTo(target, 1.2D);
                        this.parentEntity.setAttackingState(STATE_ATTACK2);
                        this.parentEntity.triggerStateAnim(STATE_ATTACK2);
                    } else {
                        this.parentEntity.getNavigation().stop();
                        this.parentEntity.setAttackingState(STATE_ATTACK);
                        this.parentEntity.triggerStateAnim(STATE_ATTACK);
                    }
                }

                if (this.attackTimer == 15 && this.parentEntity.getAttckingState() == STATE_ATTACK) {
                    this.parentEntity.getNavigation().moveTo(
                            target.getX() + 2 * this.parentEntity.random.nextInt(3),
                            this.parentEntity.getY(),
                            target.getZ() + 2 * this.parentEntity.random.nextInt(3), 3D);
                }

                if (this.attackTimer == 25 && this.parentEntity.getAttckingState() == STATE_ATTACK) {
                    this.parentEntity.getNavigation().moveTo(
                            target.getX() + 2 * this.parentEntity.random.nextInt(3),
                            this.parentEntity.getY(),
                            target.getZ() + 2 * this.parentEntity.random.nextInt(3), 3D);
                    this.smashGrid();
                }

                if (this.attackTimer == 30) {
                    this.parentEntity.setAttackingState(STATE_IDLE);
                    this.attackTimer = -5;
                    // 技能完成 → 计数 + 概率硬直
                    this.parentEntity.onSkillFinished();

                    float hp = this.parentEntity.getHealth();
                    if ((hp >= 50.0F && hp <= 55.0F) || (hp >= 100.0F && hp <= 120.0F)) {
                        this.parentEntity.setDefendingState(1);
                        this.parentEntity.addEffect(new MobEffectInstance(
                                MobEffects.DAMAGE_RESISTANCE, 20 * 5, 10, true, true));
                        this.parentEntity.addEffect(new MobEffectInstance(
                                MobEffects.WEAKNESS, 20 * 5, 10, true, true));
                    }
                }
            } else if (this.attackTimer > 0) {
                --this.attackTimer;
            }
            this.parentEntity.lookAt(target, 30.0F, 30.0F);
        }

        /** 单 tick 网格砸地：限流 + 去重。 */
        private void smashGrid() {
            Set<LivingEntity> alreadyHit = new HashSet<>();
            int budget = 40;
            for (int dist = 1; dist <= 9 && budget > 0; dist++) {
                for (float math = -7.5F; math <= 7.5F && budget > 0; math += 1.5F) {
                    this.parentEntity.blockSmashAttack(dist, 3F, math, 150, 1.5F, 0.15F, 1.0F, alreadyHit);
                    budget--;
                }
            }
        }
    }

    // ==================== 砸地 ====================
    private void blockSmashAttack(int distance, float mxy, float math, int shieldbreakticks,
                                  float damage, float hpdamage, float airborne,
                                  Set<LivingEntity> alreadyHit) {
        int hitY = Mth.floor(this.getBoundingBox().minY - 0.5);
        double minY = this.getY() - 2.0;
        double maxY = this.getY() + mxy;
        float angle = (float) Math.PI / 180 * this.yBodyRot;
        float f = Mth.cos(this.getYRot() * ((float) Math.PI / 180));
        float f1 = Mth.sin(this.getYRot() * ((float) Math.PI / 180));
        double extraX = distance * Mth.sin((float) (Math.PI + angle));
        double extraZ = distance * Mth.cos(angle);
        double px = this.getX() + extraX + f * math;
        double pz = this.getZ() + extraZ + f1 * math;
        int hitX = Mth.floor(px);
        int hitZ = Mth.floor(pz);
        BlockPos pos = new BlockPos(hitX, hitY, hitZ);
        BlockPos abovePos = pos.above();
        BlockState block = this.level().getBlockState(pos);
        BlockState blockAbove = this.level().getBlockState(abovePos);

        if (block.getBlock() != Blocks.AIR && !block.hasBlockEntity()
                && !blockAbove.blocksMotion() && this.random.nextFloat() < 0.3F) {
            EntityFallingBlock fb = new EntityFallingBlock(this.level(),
                    hitX + 0.5, hitY + 1.0, hitZ + 0.5,
                    BlockInit.EXAMPLE_BLOCK.get().defaultBlockState(), 10);
            fb.push(0.0, 0.2 + this.getRandom().nextGaussian() * 0.15, 0.0);
            this.level().addFreshEntity(fb);
        }

        AABB selection = new AABB(px - 0.5, minY, pz - 0.5, px + 0.5, maxY, pz + 0.5);
        for (LivingEntity entity : this.level().getEntitiesOfClass(LivingEntity.class, selection)) {
            if (this.isAlliedTo(entity) || entity instanceof EntityHeisen || entity == this) continue;
            if (!alreadyHit.add(entity)) continue;
            if (entity instanceof Player player
                    && player.getUseItem().canPerformAction(ToolActions.SHIELD_BLOCK)
                    && shieldbreakticks > 0) {
                disableShield(entity, shieldbreakticks);
            } else {
                boolean flag = entity.hurt(this.damageSources().mobAttack(this),
                        (float) (this.getAttributeValue(Attributes.ATTACK_DAMAGE) * damage
                                + entity.getMaxHealth() * hpdamage));
                if (flag) {
                    entity.setDeltaMovement(entity.getDeltaMovement().add(0.0, airborne + 0.5, 0.0));
                }
            }
        }
    }

    public static void disableShield(LivingEntity livingEntity, int ticks) {
        if (!(livingEntity instanceof Player player)) return;
        player.getCooldowns().addCooldown(player.getUseItem().getItem(), ticks);
        player.getUseItem().hurtAndBreak(4 + player.getRandom().nextInt(2), player,
                (p) -> p.broadcastBreakEvent(player.getUsedItemHand()));
        player.stopUsingItem();
        player.level().broadcastEntityEvent(player, (byte) 30);
    }
}