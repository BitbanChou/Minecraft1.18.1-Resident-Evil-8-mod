package com.joy187.re8joymod.entity;

import java.util.List;
import java.util.function.IntFunction;

import com.google.common.collect.Lists;
import com.joy187.re8joymod.init.BlockInit;
import com.joy187.re8joymod.init.EntityInit;
import com.joy187.re8joymod.init.ItemInit;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ServerboundPaddleBoatPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.ByIdMap;
import net.minecraft.util.Mth;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.WaterAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.entity.vehicle.DismountHelper;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.WaterlilyBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class EntityObBoat extends Boat {

	// ===================== 同步数据 =====================
	private static final EntityDataAccessor<Integer> TIME_SINCE_HIT =
			SynchedEntityData.defineId(EntityObBoat.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Integer> FORWARD_DIRECTION =
			SynchedEntityData.defineId(EntityObBoat.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Float> DAMAGE_TAKEN =
			SynchedEntityData.defineId(EntityObBoat.class, EntityDataSerializers.FLOAT);
	private static final EntityDataAccessor<Integer> DATA_ID_HURTDIR =
			SynchedEntityData.defineId(EntityObBoat.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Integer> DATA_ID_BUBBLE_TIME =
			SynchedEntityData.defineId(EntityObBoat.class, EntityDataSerializers.INT);
	@SuppressWarnings("unchecked")
	private static final EntityDataAccessor<Boolean>[] DATA_ID_PADDLE = new EntityDataAccessor[]{
			SynchedEntityData.defineId(EntityObBoat.class, EntityDataSerializers.BOOLEAN),
			SynchedEntityData.defineId(EntityObBoat.class, EntityDataSerializers.BOOLEAN)
	};
	// 关键修复：必须用 EntityObBoat.class，不能用 Boat.class
	private static final EntityDataAccessor<Integer> DATA_ID_TYPE =
			SynchedEntityData.defineId(EntityObBoat.class, EntityDataSerializers.INT);

	private final float[] paddlePositions;

	private float outOfControlCounter;
	private float deltaRotation;
	private int lerpSteps;
	private double boatPitch;
	private double lerpY;
	private double lerpZ;
	private double boatYaw;
	private double lerpXRot;
	private boolean leftInputDown;
	private boolean rightInputDown;
	private boolean forwardInputDown;
	private boolean backInputDown;
	private double lavaLevel;
	private float bubbleMultiplier;
	private float bubbleAngle;
	private float bubbleAngleO;
	private boolean isAboveBubbleColumn;
	private boolean bubbleColumnDirectionIsDown;
	private float invFriction;

	private float boatGlide;
	private Status status;
	private Status previousStatus;
	private double lastYd;

	// ===================== 构造 =====================
	public EntityObBoat(EntityType<? extends EntityObBoat> entityIn, Level world) {
		super(entityIn, world);
		this.paddlePositions = new float[2];
		this.blocksBuilding = true;
		this.setDeltaMovement(Vec3.ZERO);
	}

	public EntityObBoat(Level world) {
		super(EntityInit.OBBOAT.get(), world);
		this.paddlePositions = new float[2];
	}

	public EntityObBoat(Level world, double x, double y, double z) {
		this(EntityInit.OBBOAT.get(), world);
		this.setDeltaMovement(Vec3.ZERO);
		this.xo = x;
		this.yo = y;
		this.zo = z;
		this.setPos(x, y, z);
	}

	public static AttributeSupplier.Builder prepareAttributes() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, 20.0D)
				.add(Attributes.MOVEMENT_SPEED, 0.20D);
	}

	// ===================== 同步数据定义 =====================
	@Override
	protected void defineSynchedData() {
		// 关键修复：必须先调用 super，初始化父类 Boat 的数据
		super.defineSynchedData();

		this.entityData.define(TIME_SINCE_HIT, 0);
		this.entityData.define(FORWARD_DIRECTION, 1);
		this.entityData.define(DAMAGE_TAKEN, 0.0F);
		this.entityData.define(DATA_ID_HURTDIR, 1);
		this.entityData.define(DATA_ID_BUBBLE_TIME, 0);
		this.entityData.define(DATA_ID_TYPE, Type.EBONY.ordinal());

		for (EntityDataAccessor<Boolean> parameter : DATA_ID_PADDLE) {
			this.entityData.define(parameter, false);
		}
	}

	// ===================== 基础属性 =====================
	protected boolean canTriggerWalking() {
		return false;
	}

	public AABB getCollisionBox(Entity entity) {
		return entity.isPushable() ? entity.getBoundingBox() : null;
	}

	public AABB getCollisionBoundingBox() {
		return this.getBoundingBox();
	}

	@Override
	public boolean isPushable() {
		return true;
	}

	@Override
	public double getPassengersRidingOffset() {
		return -0.1D;
	}

	@Override
	public boolean canBeCollidedWith() {
		return !this.isRemoved();
	}

	@Override
	public Direction getMotionDirection() {
		return this.getDirection().getClockWise();
	}

	// ===================== 气泡柱 =====================
	private void tickBubbleColumn() {
		if (this.level().isClientSide) {
			int i = this.getBubbleTime();
			if (i > 0) {
				this.bubbleMultiplier += 0.05F;
			} else {
				this.bubbleMultiplier -= 0.1F;
			}

			this.bubbleMultiplier = Mth.clamp(this.bubbleMultiplier, 0.0F, 1.0F);
			this.bubbleAngleO = this.bubbleAngle;
			this.bubbleAngle = 10.0F * (float) Math.sin(0.5F * (float) this.level().getGameTime()) * this.bubbleMultiplier;
		} else {
			if (!this.isAboveBubbleColumn) {
				this.setBubbleTime(0);
			}

			int k = this.getBubbleTime();
			if (k > 0) {
				--k;
				this.setBubbleTime(k);
				int j = 60 - k - 1;
				if (j > 0 && k == 0) {
					this.setBubbleTime(0);
					Vec3 vec3 = this.getDeltaMovement();
					if (this.bubbleColumnDirectionIsDown) {
						this.setDeltaMovement(vec3.add(0.0D, -0.7D, 0.0D));
						this.ejectPassengers();
					} else {
						this.setDeltaMovement(vec3.x, this.hasPassenger((p) -> p instanceof Player) ? 2.7D : 0.6D, vec3.z);
					}
				}

				this.isAboveBubbleColumn = false;
			}
		}
	}

	public Item getDropItem() {
		return ItemInit.OBBOAT.get();
	}

	// ===================== 伤害 =====================
	@Override
	public boolean hurt(DamageSource source, float amount) {
		if (this.isInvulnerableTo(source)) {
			return false;
		} else if (!this.level().isClientSide && !this.isRemoved()) {
			this.setHurtDir(-this.getHurtDir());
			this.setHurtTime(10);
			this.setDamage(this.getDamage() + amount * 10.0F);
			this.markHurt();
			this.gameEvent(GameEvent.ENTITY_DAMAGE, source.getEntity());
			boolean flag = source.getEntity() instanceof Player && ((Player) source.getEntity()).getAbilities().instabuild;
			if (flag || this.getDamage() > 40.0F) {
				if (!flag && this.level().getGameRules().getBoolean(GameRules.RULE_DOENTITYDROPS)) {
					this.spawnAtLocation(this.getDropItem());
				}
				this.discard();
			}
			return true;
		} else {
			return true;
		}
	}

	@Override
	public boolean isInvulnerableTo(DamageSource source) {
		// 免疫火焰、熔岩、爆炸等环境伤害（但保留玩家攻击可破坏船的逻辑）
		if (source.is(net.minecraft.tags.DamageTypeTags.IS_FIRE)
				|| source.is(net.minecraft.tags.DamageTypeTags.IS_EXPLOSION)) {
			return true;
		}
		return super.isInvulnerableTo(source);
	}

	@Override
	public boolean fireImmune() {
		return true;
	}

	public void onAboveBubbleCol(boolean down) {
		if (!this.level().isClientSide) {
			this.isAboveBubbleColumn = true;
			this.bubbleColumnDirectionIsDown = down;
			if (this.getBubbleTime() == 0) {
				this.setBubbleTime(60);
			}
		}

		this.level().addParticle(ParticleTypes.SPLASH,
				this.getX() + this.random.nextFloat(), this.getY() + 0.7D, this.getZ() + this.random.nextFloat(),
				0.0D, 0.0D, 0.0D);
		if (this.random.nextInt(20) == 0) {
			this.level().playLocalSound(this.getX(), this.getY(), this.getZ(),
					this.getSwimSplashSound(), this.getSoundSource(),
					1.0F, 0.8F + 0.4F * this.random.nextFloat(), false);
		}
		this.gameEvent(GameEvent.SPLASH, this.getControllingPassenger());
	}

	@Override
	public void push(Entity entity) {
		if (entity instanceof EntityObBoat) {
			if (entity.getBoundingBox().minY < this.getBoundingBox().maxY) {
				super.push(entity);
			}
		} else if (entity.getBoundingBox().minY <= this.getBoundingBox().minY) {
			super.push(entity);
		}
	}

	@OnlyIn(Dist.CLIENT)
	public void animateHurt() {
		this.setBubbleTime(-this.getBubbleTime());
		this.setHurtTime(10);
		this.setDamage(this.getDamage() * 11.0F);
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public void lerpTo(double x, double y, double z, float yaw, float pitch, int posRotationIncrements, boolean teleport) {
		this.boatPitch = x;
		this.lerpY = y;
		this.lerpZ = z;
		this.boatYaw = yaw;
		this.lerpXRot = pitch;
		this.lerpSteps = 10;
	}

	// ===================== 主 tick =====================
	@Override
	public void tick() {
		// 关键修复：调用父类 tick（Entity.baseTick 等基础逻辑）
		super.tick();

		this.previousStatus = this.status;
		this.status = this.getBoatStatus();

		if (this.status != Status.UNDER_LAVA && this.status != Status.UNDER_FLOWING_LAVA) {
			this.outOfControlCounter = 0.0F;
		} else {
			this.outOfControlCounter++;
		}

//		if (!this.level().isClientSide && this.outOfControlCounter >= 60.0F) {
//			this.ejectPassengers();
//		}

		if (this.getHurtTime() > 0) {
			this.setHurtTime(this.getHurtTime() - 1);
		}

		if (this.getDamage() > 0.0F) {
			this.setDamage(this.getDamage() - 1.0F);
		}

		this.tickLerp();
		this.tickBubbleColumn();

		if (this.isControlledByLocalInstance()) {
			if (this.getPassengers().isEmpty() || !(this.getPassengers().get(0) instanceof Player)) {
				this.setPaddleState(false, false);
			}

			this.updateMotion();

			if (this.level().isClientSide) {
				this.controlBoat();
				this.level().sendPacketToServer(new ServerboundPaddleBoatPacket(
						this.getPaddleState(0), this.getPaddleState(1)));
			}

			this.move(MoverType.SELF, this.getDeltaMovement());
		} else {
			this.setDeltaMovement(Vec3.ZERO);
		}

		for (int i = 0; i <= 1; i++) {
			if (this.getPaddleState(i)) {
				if (!this.isSilent()
						&& (double) (this.paddlePositions[i] % ((float) Math.PI * 2F)) <= (Math.PI / 4D)
						&& ((double) this.paddlePositions[i] + 0.39269909262657166D) % (Math.PI * 2D) >= (Math.PI / 4D)) {
					SoundEvent event = this.getPaddleSound();
					if (event != null) {
						Vec3 look = this.getViewVector(1.0F);
						double lookX = i == 1 ? -look.z : look.z;
						double lookZ = i == 1 ? look.x : -look.x;
						this.level().playSound(null, this.getX() + lookX, this.getY(), this.getZ() + lookZ,
								event, this.getSoundSource(), 1.0F, 0.8F + 0.4F * this.random.nextFloat());
					}
				}

				this.paddlePositions[i] = (float) ((double) this.paddlePositions[i] + 0.39269909262657166D);
			} else {
				this.paddlePositions[i] = 0.0F;
			}
		}

		this.checkInsideBlocks();

		List<Entity> entities = this.level().getEntities(this,
				this.getBoundingBox().inflate(0.20000000298023224D, -0.009999999776482582D, 0.20000000298023224D),
				EntitySelector.pushableBy(this));

		if (!entities.isEmpty()) {
			boolean flag = !this.level().isClientSide && !(this.getControllingPassenger() instanceof Player);

			for (Entity entity : entities) {
				if (!entity.hasPassenger(this)) {
					if (flag && this.getPassengers().size() < 2 && !entity.isPassenger()
							&& entity.getBbWidth() < this.getBbWidth()
							&& entity instanceof LivingEntity
							&& !(entity instanceof WaterAnimal)
							&& !(entity instanceof Player)) {
						entity.startRiding(this);
					} else {
						this.push(entity);
					}
				}
			}
		}
	}

	protected SoundEvent getPaddleSound() {
		switch (this.getBoatStatus()) {
			case IN_LAVA:
			case UNDER_LAVA:
			case UNDER_FLOWING_LAVA:
				return SoundEvents.BOAT_PADDLE_WATER;
			case ON_LAND:
				return SoundEvents.BOAT_PADDLE_LAND;
			case IN_AIR:
			default:
				return null;
		}
	}

	private void tickLerp() {
		if (this.lerpSteps > 0 && !this.isControlledByLocalInstance()) {
			double posX = this.getX() + (this.boatPitch - this.getX()) / (double) this.lerpSteps;
			double posY = this.getY() + (this.lerpY - this.getY()) / (double) this.lerpSteps;
			double posZ = this.getZ() + (this.lerpZ - this.getZ()) / (double) this.lerpSteps;
			double yaw = Mth.wrapDegrees(this.boatYaw - (double) this.getYRot());

			this.setYRot(this.getYRot() + (float) yaw / (float) this.lerpSteps);
			this.setXRot(this.getXRot() + (float) (this.lerpXRot - (double) this.getXRot()) / (float) this.lerpSteps);

			this.lerpSteps--;
			this.setPos(posX, posY, posZ);
			this.setRot(this.getYRot(), this.getXRot());
		}
	}

	// ===================== 划桨 =====================
	@Override
	public void setPaddleState(boolean leftPaddle, boolean rightPaddle) {
		this.entityData.set(DATA_ID_PADDLE[0], leftPaddle);
		this.entityData.set(DATA_ID_PADDLE[1], rightPaddle);
	}

	@Override
	public boolean getPaddleState(int state) {
		return this.entityData.get(DATA_ID_PADDLE[state]) && this.getControllingPassenger() != null;
	}

	@OnlyIn(Dist.CLIENT)
	public float getRowingTime(int side, float limbSwing) {
		return this.getPaddleState(side)
				? (float) Mth.clampedLerp((double) this.paddlePositions[side] - 0.39269909262657166D,
				this.paddlePositions[side], limbSwing)
				: 0.0F;
	}

	// ===================== 状态判定 =====================
	private Status getBoatStatus() {
		Status status = this.getUnderLavaStatus();
		if (status != null) {
			this.lavaLevel = this.getBoundingBox().maxY;
			return status;
		} else if (this.checkInLava()) {
			return Status.IN_LAVA;
		} else {
			float f = this.getGroundFriction();
			if (f > 0.0F) {
				this.boatGlide = f;
				return Status.ON_LAND;
			} else {
				return Status.IN_AIR;
			}
		}
	}

	private float getLavaLevelAbove() {
		AABB aabb = this.getBoundingBox();
		int i = Mth.floor(aabb.minX);
		int j = Mth.ceil(aabb.maxX);
		int k = Mth.floor(aabb.maxY);
		int l = Mth.ceil(aabb.maxY - this.lastYd);
		int i1 = Mth.floor(aabb.minZ);
		int j1 = Mth.ceil(aabb.maxZ);
		BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();

		label39:
		for (int k1 = k; k1 < l; ++k1) {
			float f = 0.0F;
			for (int l1 = i; l1 < j; ++l1) {
				for (int i2 = i1; i2 < j1; ++i2) {
					mutable.set(l1, k1, i2);
					FluidState fluidstate = this.level().getFluidState(mutable);
					if (fluidstate.is(FluidTags.WATER) || fluidstate.is(FluidTags.LAVA)) {
						f = Math.max(f, fluidstate.getHeight(this.level(), mutable));
					}
					if (f >= 1.0F) {
						continue label39;
					}
				}
			}
			if (f < 1.0F) {
				return (float) mutable.getY() + f;
			}
		}
		return (float) (l + 1);
	}

	public float getGroundFriction() {
		AABB aabb = this.getBoundingBox();
		AABB aabb1 = new AABB(aabb.minX, aabb.minY - 0.001D, aabb.minZ, aabb.maxX, aabb.minY, aabb.maxZ);
		int i = Mth.floor(aabb1.minX) - 1;
		int j = Mth.ceil(aabb1.maxX) + 1;
		int k = Mth.floor(aabb1.minY) - 1;
		int l = Mth.ceil(aabb1.maxY) + 1;
		int i1 = Mth.floor(aabb1.minZ) - 1;
		int j1 = Mth.ceil(aabb1.maxZ) + 1;
		VoxelShape voxelshape = Shapes.create(aabb1);
		float f = 0.0F;
		int k1 = 0;
		BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();

		for (int l1 = i; l1 < j; ++l1) {
			for (int i2 = i1; i2 < j1; ++i2) {
				int j2 = (l1 != i && l1 != j - 1 ? 0 : 1) + (i2 != i1 && i2 != j1 - 1 ? 0 : 1);
				if (j2 != 2) {
					for (int k2 = k; k2 < l; ++k2) {
						if (j2 <= 0 || k2 != k && k2 != l - 1) {
							mutable.set(l1, k2, i2);
							BlockState blockstate = this.level().getBlockState(mutable);
							if (!(blockstate.getBlock() instanceof WaterlilyBlock)
									&& Shapes.joinIsNotEmpty(
									blockstate.getCollisionShape(this.level(), mutable).move(l1, k2, i2),
									voxelshape, BooleanOp.AND)) {
								f += blockstate.getFriction(this.level(), mutable, this);
								++k1;
							}
						}
					}
				}
			}
		}

		return f / (float) k1;
	}

	private boolean checkInLava() {
		AABB box = this.getBoundingBox();
		int minX = Mth.floor(box.minX);
		int maxX = Mth.ceil(box.maxX);
		int minY = Mth.floor(box.minY);
		int maxY = Mth.ceil(box.minY + 0.001D);
		int minZ = Mth.floor(box.minZ);
		int maxZ = Mth.ceil(box.maxZ);
		boolean flag = false;
		this.lavaLevel = -Double.MAX_VALUE;
		BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();

		for (int x = minX; x < maxX; x++) {
			for (int y = minY; y < maxY; y++) {
				for (int z = minZ; z < maxZ; z++) {
					mutable.set(x, y, z);
					FluidState fluidstate = this.level().getFluidState(mutable);
					if (fluidstate.is(FluidTags.WATER) || fluidstate.is(FluidTags.LAVA)) {
						float f = (float) y + fluidstate.getHeight(this.level(), mutable);
						this.lavaLevel = Math.max((double) f, this.lavaLevel);
						flag |= box.minY < (double) f;
					}
				}
			}
		}

		return flag;
	}

	private Status getUnderLavaStatus() {
		AABB box = this.getBoundingBox();
		double entityHeight = box.maxY + 0.001D;
		int minX = Mth.floor(box.minX);
		int maxX = Mth.ceil(box.maxX);
		int minY = Mth.floor(box.maxY);
		int maxY = Mth.ceil(entityHeight);
		int minZ = Mth.floor(box.minZ);
		int maxZ = Mth.ceil(box.maxZ);
		boolean flag = false;
		BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();

		for (int k1 = minX; k1 < maxX; ++k1) {
			for (int l1 = minY; l1 < maxY; ++l1) {
				for (int i2 = minZ; i2 < maxZ; ++i2) {
					mutable.set(k1, l1, i2);
					FluidState fluidstate = this.level().getFluidState(mutable);
					if ((fluidstate.is(FluidTags.WATER) || fluidstate.is(FluidTags.LAVA))
							&& entityHeight < (double) ((float) mutable.getY()
							+ fluidstate.getHeight(this.level(), mutable))) {
						if (!fluidstate.isSource()) {
							return Status.UNDER_FLOWING_LAVA;
						}
						flag = true;
					}
				}
			}
		}

		return flag ? Status.UNDER_LAVA : null;
	}

	// ===================== 运动 =====================
	private void updateMotion() {
		double gravity = this.isNoGravity() ? 0.0D : -0.03999999910593033D;
		double position = 0.0D;
		this.invFriction = 0.05F;

		if (this.previousStatus == Status.IN_AIR && this.status != Status.IN_AIR && this.status != Status.ON_LAND) {
			this.lavaLevel = this.getY(1.0D);
			this.setPos(this.getX(), (double) (this.getLavaLevelAbove() - this.getBbHeight()) + 0.101D, this.getZ());
			this.setDeltaMovement(this.getDeltaMovement().multiply(1.0D, 0.0D, 1.0D));
			this.lastYd = 0.0D;
			this.status = Status.IN_LAVA;
		} else {
			if (this.status == Status.IN_LAVA) {
				position = (this.lavaLevel - this.getY()) / (double) this.getBbHeight();
				this.invFriction = 0.9F;
			} else if (this.status == Status.UNDER_FLOWING_LAVA) {
				gravity = -7.0E-4D;
				this.invFriction = 0.9F;
			} else if (this.status == Status.UNDER_LAVA) {
				position = 0.009999999776482582D;
				this.invFriction = 0.45F;
			} else if (this.status == Status.IN_AIR) {
				this.invFriction = 0.9F;
			} else if (this.status == Status.ON_LAND) {
				this.invFriction = this.boatGlide;
				if (this.getControllingPassenger() instanceof Player) {
					this.boatGlide /= 2.0F;
				}
			}

			Vec3 vec3 = this.getDeltaMovement();
			this.setDeltaMovement(vec3.x * (double) this.invFriction, vec3.y + gravity, vec3.z * this.invFriction);
			this.deltaRotation *= this.invFriction;
			if (position > 0.0D) {
				Vec3 vec31 = this.getDeltaMovement();
				this.setDeltaMovement(vec31.x, (vec31.y + position * 0.06153846016296973D) * 0.75D, vec31.z);
			}
		}
	}

	private void controlBoat() {
		if (this.isVehicle()) {
			float speed = 0.0F;

			if (this.leftInputDown) {
				this.deltaRotation += -1.0F;
			}
			if (this.rightInputDown) {
				this.deltaRotation++;
			}

			if (this.rightInputDown != this.leftInputDown && !this.forwardInputDown && !this.backInputDown) {
				speed += 0.005F;
			}

			this.setYRot(this.getYRot() + this.deltaRotation);
			if (this.forwardInputDown) {
				speed += 0.04F;
			}
			if (this.backInputDown) {
				speed -= 0.005F;
			}

			this.setDeltaMovement(this.getDeltaMovement().add(
					(double) (Mth.sin(-this.getYRot() * ((float) Math.PI / 180F)) * speed),
					0D,
					(double) (Mth.cos(this.getYRot() * ((float) Math.PI / 180F)) * speed)));

			this.setPaddleState(
					this.rightInputDown && !this.leftInputDown || this.forwardInputDown,
					this.leftInputDown && !this.rightInputDown || this.forwardInputDown);
		}
	}

	// ===================== 乘客 =====================
	@Override
	public void positionRider(Entity passenger, MoveFunction moveFunction) {
		if (this.hasPassenger(passenger)) {
			// 抗火：只在没有效果或即将过期时添加，避免每 tick 刷新
			if (passenger instanceof LivingEntity living) {
				MobEffectInstance current = living.getEffect(MobEffects.FIRE_RESISTANCE);
				if (current == null || current.getDuration() < 80) {
					living.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 100, 0, false, false, false));
				}
			}

			float x = 0.0F;
			float height = (float) ((this.isRemoved() ? 0.009999999776482582D : this.getPassengersRidingOffset())
					+ passenger.getMyRidingOffset());

			if (this.getPassengers().size() > 1) {
				int index = this.getPassengers().indexOf(passenger);
				if (index == 0) {
					x = 0.2F;
				} else {
					x = -0.6F;
				}
				if (passenger instanceof Animal) {
					x = (float) ((double) x + 0.2D);
				}
			}

			Vec3 pos = (new Vec3(x, 0.0D, 0.0D)).yRot(-this.getYRot() * 0.017453292F - ((float) Math.PI / 2F));
			passenger.setPos(this.position().x + pos.x, this.position().y + (double) height, this.position().z + pos.z);
			passenger.setYHeadRot(passenger.getYHeadRot() + this.deltaRotation);
			passenger.setYRot(passenger.getYRot() + this.deltaRotation);
			this.clampRotation(passenger);

			if (passenger instanceof Animal && this.getPassengers().size() > 1) {
				int rotation = passenger.getId() % 2 == 0 ? 90 : 270;
				passenger.setYBodyRot(((Animal) passenger).yBodyRot + (float) rotation);
				passenger.setYHeadRot(passenger.getYHeadRot() + (float) rotation);
			}
		}
	}

	@Override
	public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
		Vec3 vec3 = getCollisionHorizontalEscapeVector(
				(double) (this.getBbWidth() * Mth.SQRT_OF_TWO),
				(double) passenger.getBbWidth(),
				passenger.getYRot());
		double d0 = this.getX() + vec3.x;
		double d1 = this.getZ() + vec3.z;
		BlockPos blockpos = new BlockPos(Mth.floor(d0), Mth.floor(this.getBoundingBox().maxY), Mth.floor(d1));
		BlockPos blockpos1 = blockpos.below();

		// 修复：|| 改为 &&，否则条件恒为 true
		if (!this.level().getFluidState(blockpos1).is(FluidTags.WATER)
				&& !this.level().getFluidState(blockpos1).is(FluidTags.LAVA)) {
			List<Vec3> list = Lists.newArrayList();
			double d2 = this.level().getBlockFloorHeight(blockpos);
			if (DismountHelper.isBlockFloorValid(d2)) {
				list.add(new Vec3(d0, (double) blockpos.getY() + d2, d1));
			}

			double d3 = this.level().getBlockFloorHeight(blockpos1);
			if (DismountHelper.isBlockFloorValid(d3)) {
				list.add(new Vec3(d0, (double) blockpos1.getY() + d3, d1));
			}

			for (Pose pose : passenger.getDismountPoses()) {
				for (Vec3 vec31 : list) {
					if (DismountHelper.canDismountTo(this.level(), vec31, passenger, pose)) {
						passenger.setPose(pose);
						return vec31;
					}
				}
			}
		}

		return super.getDismountLocationForPassenger(passenger);
	}

	@Override
	protected void clampRotation(Entity entityToUpdate) {
		entityToUpdate.setYBodyRot(this.getYRot());
		float f = Mth.wrapDegrees(entityToUpdate.getYRot() - this.getYRot());
		float f1 = Mth.clamp(f, -105.0F, 105.0F);
		entityToUpdate.yRotO += f1 - f;
		entityToUpdate.setYRot(entityToUpdate.getYRot() + f1 - f);
		entityToUpdate.setYHeadRot(entityToUpdate.getYRot());
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public void onPassengerTurned(Entity entityToUpdate) {
		this.clampRotation(entityToUpdate);
	}

	// ===================== 存档持久化 =====================
	@Override
	protected void addAdditionalSaveData(CompoundTag tag) {
		super.addAdditionalSaveData(tag);
		tag.putString("ObBoatType", this.getModVariant().getSerializedName());
	}

	@Override
	protected void readAdditionalSaveData(CompoundTag tag) {
		super.readAdditionalSaveData(tag);
		if (tag.contains("ObBoatType")) {
			this.setVariant(Type.byName(tag.getString("ObBoatType")));
		}
	}

	// ===================== 交互 =====================
	@Override
	public InteractionResult interact(Player player, InteractionHand hand) {
		if (player.isSecondaryUseActive()) {
			return InteractionResult.PASS;
		} else if (this.outOfControlCounter < 60.0F) {
			if (!this.level().isClientSide) {
				return player.startRiding(this) ? InteractionResult.CONSUME : InteractionResult.PASS;
			} else {
				return InteractionResult.SUCCESS;
			}
		} else {
			return InteractionResult.PASS;
		}
	}

	// ===================== 坠落 =====================
	@Override
	protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
		this.lastYd = this.getDeltaMovement().y;

		if (!this.isPassenger()) {
			if (onGround) {
				if (this.fallDistance > 3.0F) {
					if (this.status != Status.ON_LAND) {
						this.fallDistance = 0.0F;
						return;
					}

					this.causeFallDamage(this.fallDistance, 1.0F, this.damageSources().fall());
					if (!this.level().isClientSide && !this.isRemoved()) {
						this.kill();
						if (this.level().getGameRules().getBoolean(GameRules.RULE_DOENTITYDROPS)) {
							for (int i = 0; i < 3; i++) {
								this.spawnAtLocation(new ItemStack(BlockInit.EBONY_PLANKS.get()), 0.0F);
							}
						}
					}
				}
				this.fallDistance = 0.0F;
			} else if (y < 0.0D
					&& !this.level().getFluidState(this.blockPosition().below()).is(FluidTags.LAVA)
					&& !this.level().getFluidState(this.blockPosition().below()).is(FluidTags.WATER)) {
				this.fallDistance = (float) ((double) this.fallDistance - y);
			}
		}
	}

	// ===================== 伤害数值读写 =====================
	public void setDamage(float damage) {
		this.entityData.set(DAMAGE_TAKEN, damage);
	}

	public float getDamage() {
		return this.entityData.get(DAMAGE_TAKEN);
	}

	@Override
	public void setHurtTime(int hurtTime) {
		this.entityData.set(TIME_SINCE_HIT, hurtTime);
	}

	@Override
	public int getHurtTime() {
		return this.entityData.get(TIME_SINCE_HIT);
	}

	public void setHurtDir(int dir) {
		this.entityData.set(DATA_ID_HURTDIR, dir);
	}

	public int getHurtDir() {
		return this.entityData.get(DATA_ID_HURTDIR);
	}

	public void setBubbleTime1(int bubbleTime) {
		this.entityData.set(FORWARD_DIRECTION, bubbleTime);
	}

	public int getBubbleTime1() {
		return this.entityData.get(FORWARD_DIRECTION);
	}

	private void setBubbleTime(int time) {
		this.entityData.set(DATA_ID_BUBBLE_TIME, time);
	}

	private int getBubbleTime() {
		return this.entityData.get(DATA_ID_BUBBLE_TIME);
	}

	// ===================== 乘客管理 =====================
	@Override
	protected boolean canAddPassenger(Entity passenger) {
		return this.getPassengers().size() < 2;
	}

	@Override
	public LivingEntity getControllingPassenger() {
		List<Entity> passengers = this.getPassengers();
		return passengers.isEmpty() ? null : (LivingEntity) passengers.get(0);
	}

	@OnlyIn(Dist.CLIENT)
	public void setInput(boolean left, boolean right, boolean forward, boolean back) {
		this.leftInputDown = left;
		this.rightInputDown = right;
		this.forwardInputDown = forward;
		this.backInputDown = back;
	}

	// ===================== 变体 =====================
	public Type getBoatType() {
		return Type.EBONY;
	}

	public void setVariant(Type variant) {
		this.entityData.set(DATA_ID_TYPE, variant.ordinal());
	}

	public Type getModVariant() {
		return Type.byId(this.entityData.get(DATA_ID_TYPE));
	}

	public enum Status {
		IN_LAVA,
		UNDER_LAVA,
		UNDER_FLOWING_LAVA,
		ON_LAND,
		IN_AIR
	}

	public enum Type implements StringRepresentable {
		EBONY(BlockInit.EBONY_PLANKS.get(), "obboat1");

		private final String name;
		private final Block planks;
		public static final StringRepresentable.EnumCodec<EntityObBoat.Type> CODEC =
				StringRepresentable.fromEnum(EntityObBoat.Type::values);
		private static final IntFunction<Type> BY_ID =
				ByIdMap.continuous(Enum::ordinal, values(), ByIdMap.OutOfBoundsStrategy.ZERO);

		Type(Block planks, String name) {
			this.name = name;
			this.planks = planks;
		}

		public String getSerializedName() {
			return this.name;
		}

		public String getName() {
			return this.name;
		}

		public Block getPlanks() {
			return this.planks;
		}

		@Override
		public String toString() {
			return this.name;
		}

		public static Type byId(int id) {
			return BY_ID.apply(id);
		}

		public static Type byName(String name) {
			return CODEC.byName(name, EBONY);
		}
	}
}