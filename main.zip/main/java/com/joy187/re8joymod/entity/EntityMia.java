package com.joy187.re8joymod.entity;

import java.util.EnumSet;
import java.util.Random;

import javax.annotation.Nullable;

import com.joy187.re8joymod.init.EntityInit;
import com.joy187.re8joymod.init.SoundInit;
import com.joy187.re8joymod.util.CommonFunctions;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.GolemRandomStrollInVillageGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MoveBackToVillageGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsTargetGoal;
import net.minecraft.world.entity.ai.goal.OfferFlowerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.DefendVillageTargetGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.ResetUniversalAngerTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;

public class EntityMia extends EntityEthan implements GeoEntity {

    // ==================== 状态常量 ====================
    public static final int STATE_IDLE = 0;
    public static final int STATE_ATTACK = 1;
    public static final int STATE_ATTACK2 = 2;

    // ==================== 变身参数 ====================
    /** 变回 Miranda1 后，Miranda1 侧的变身冷却。 */
    public static final int MIA_FORM_COOLDOWN_AFTER_REVERT = 20 * 20;   // 20s
    private static final int MIA_FORM_DURATION_DEFAULT = 20 * 5;        // 5s

    private AnimatableInstanceCache factory = GeckoLibUtil.createInstanceCache(this);

    public static final EntityDataAccessor<Integer> STATE =
            SynchedEntityData.defineId(EntityMia.class, EntityDataSerializers.INT);
    /** true = 本实体由 Miranda1 变身而来，计时到点要变回 */
    public static final EntityDataAccessor<Boolean> FROM_MIRANDA =
            SynchedEntityData.defineId(EntityMia.class, EntityDataSerializers.BOOLEAN);

    private int healFlags = 0;
    /** 变身剩余 tick，0 = 不是变身状态 */
    private int miaFormTicks = 0;
    /** 变身回 Miranda1 时要恢复的血量（参考 EntityAngie.savedHealth） */
    private float savedHealth = 0.0F;

    public EntityMia(EntityType<? extends IronGolem> type, Level worldIn) {
        super(type, worldIn);
        this.xpReward = 50;
    }

    // ==================== AI 目标 ====================
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new AttackGoal(this));
        this.goalSelector.addGoal(2, new MoveTowardsTargetGoal(this, 0.9D, 32.0F));
        this.goalSelector.addGoal(2, new MoveBackToVillageGoal(this, 0.6D, false));
        this.goalSelector.addGoal(4, new GolemRandomStrollInVillageGoal(this, 0.6D));
        this.goalSelector.addGoal(5, new OfferFlowerGoal(this));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new DefendVillageTargetGoal(this));
        this.targetSelector.addGoal(2, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Mob.class, 5, false, false,
                (p) -> p instanceof Enemy && !(p instanceof Creeper)));
        this.targetSelector.addGoal(4, new ResetUniversalAngerTargetGoal<>(this, true));
    }

    public static AttributeSupplier.Builder prepareAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 45.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.45D)
                .add(Attributes.ATTACK_DAMAGE, 9.2D);
    }

    // ==================== 主 AI ====================
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();

        // ---- 变身计时：到点变回 Miranda1 ----
        if (this.entityData.get(FROM_MIRANDA) && this.miaFormTicks > 0) {
            this.miaFormTicks--;
            if (this.miaFormTicks <= 0) {
                this.revertToMiranda();
                return;
            }
        }

        // ---- 回血（每档一次） ----
        this.tickHealFlags();
    }

    @Override
    public void aiStep() {
        super.aiStep();
        // 粒子降频：每 5 tick 一次
        if (this.getHealth() < 15.0F && this.tickCount % 5 == 0) {
            CommonFunctions.spawnHexAround(ParticleTypes.HEART, this.level(), this.getOnPos(), 1.0F);
        }
    }

    // ==================== 变身：由 Miranda1 调用 ====================
    /**
     * 标记本 Mia 由 Miranda1 变身而来。
     * 参考 EntityAngie.setAvatarHost：手动保存血量，变回时恢复。
     */
    public void setFromMiranda(boolean from, int durationTicks, float health) {
        this.entityData.set(FROM_MIRANDA, from);
        this.miaFormTicks = from ? durationTicks : 0;
        this.savedHealth = from ? health : 0.0F;
    }

    public void setFromMiranda(boolean from, int durationTicks) {
        this.setFromMiranda(from, durationTicks, this.getHealth());
    }

    public boolean isFromMiranda() {
        return this.entityData.get(FROM_MIRANDA);
    }

    /**
     * Mia → Miranda1：手动 new + setHealth + discard，参考 EntityAngie.restoreHost。
     */
    private void revertToMiranda() {
        if (this.level().isClientSide || !(this.level() instanceof ServerLevel server)) return;

        float keepHealth = this.savedHealth > 0.0F ? this.savedHealth : this.getHealth();
        LivingEntity t = this.getTarget();

        EntityMiranda1 back = new EntityMiranda1(EntityInit.MIRANDA1.get(), server);
        back.moveTo(this.getX(), this.getY(), this.getZ(), this.getYRot(), this.getXRot());

        // 显式恢复血量
        float maxHp = back.getMaxHealth();
        back.setHealth(Math.max(1.0F, Math.min(keepHealth, maxHp)));

        // 变回后的冷却
        back.setMiaFormCooldown(MIA_FORM_COOLDOWN_AFTER_REVERT);

        // 保留目标
        if (t != null && t.isAlive()) {
            back.setTarget(t);
            back.setLastHurtByMob(t);
        }

        server.addFreshEntity(back);

        // 变回特效
        server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                back.getX(), back.getY() + 1.0, back.getZ(), 40, 0.6, 0.8, 0.6, 0.05);
        back.playSound(SoundInit.ENTITY_MIRA_HURT1.get(), 1.5F, 0.8F);

        // 替身功成身退
        this.discard();
    }

    // ==================== 回血（每档一次） ====================
    private void tickHealFlags() {
        float hp = this.getHealth();
        if (!hasFlag(0) && hp >= 10.0F && hp <= 20.0F) {
            healOnce(2.2F, 5);
            setFlag(0);
        }
    }

    private void healOnce(float perTick, int times) {
        float total = 0;
        for (int i = 0; i < times; i++) total += perTick * this.random.nextFloat();
        this.heal(total);
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.HEART,
                    this.getX(), this.getY() + this.getBbHeight() * 0.6, this.getZ(),
                    6, 0.4, 0.4, 0.4, 0.02);
        }
    }

    private boolean hasFlag(int bit) { return (this.healFlags & (1 << bit)) != 0; }
    private void setFlag(int bit) { this.healFlags |= (1 << bit); }

    // ==================== 音效 ====================
    @Override
    protected SoundEvent getAmbientSound() {
        return this.random.nextBoolean()
                ? SoundInit.ENTITY_MIA_AMBIENT1.get()
                : SoundInit.ENTITY_MIA_AMBIENT2.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundInit.ENTITY_MIA_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundInit.ENTITY_MIA_DEATH.get();
    }

    // ==================== 存档 ====================
    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.healFlags = tag.getInt("HealFlags");
        this.miaFormTicks = tag.getInt("MiaFormTicks");
        this.savedHealth = tag.getFloat("SavedHealth");
        this.entityData.set(FROM_MIRANDA, tag.getBoolean("FromMiranda"));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("HealFlags", this.healFlags);
        tag.putInt("MiaFormTicks", this.miaFormTicks);
        tag.putFloat("SavedHealth", this.savedHealth);
        tag.putBoolean("FromMiranda", this.entityData.get(FROM_MIRANDA));
    }

    // ==================== 同步数据 ====================
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(STATE, 0);
        this.entityData.define(FROM_MIRANDA, false);
    }

    public int getAttckingState() {
        return this.entityData.get(STATE);
    }

    public void setAttackingState(int state) {
        if (state < STATE_IDLE || state > STATE_ATTACK2) return;
        this.entityData.set(STATE, state);
    }

    // ==================== 动画控制器（trigger 形式） ====================
    private <E extends GeoAnimatable> PlayState predicateMovement(AnimationState<E> event) {
        if (event.isMoving()) {
            event.setAndContinue(RawAnimation.begin().thenPlay("animation.mia.walk"));
            return PlayState.CONTINUE;
        }
        event.setAndContinue(RawAnimation.begin().thenPlay("animation.mia.idle"));
        return PlayState.CONTINUE;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar data) {
        data.add(new AnimationController<>(this, "movement", 5, this::predicateMovement));

        AnimationController<?> attackController =
                new AnimationController<>(this, "attack", 0, state -> PlayState.STOP)
                        .triggerableAnim("attack", RawAnimation.begin().thenPlay("animation.mia.attack"))
                        .triggerableAnim("attack2", RawAnimation.begin().thenPlay("animation.mia.attack2"));
        data.add(attackController);
    }

    private void triggerStateAnim(int state) {
        String name = switch (state) {
            case STATE_ATTACK -> "attack";
            case STATE_ATTACK2 -> "attack2";
            default -> null;
        };
        if (name != null) {
            this.triggerAnim("attack", name);
        }
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.factory;
    }

    // ==================== AttackGoal ====================
    static class AttackGoal extends Goal {
        private final EntityMia parentEntity;
        protected int attackTimer = 0;

        public AttackGoal(EntityMia mob) {
            this.parentEntity = mob;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        public boolean canUse() {
            return this.parentEntity.getTarget() != null;
        }

        public void start() {
            super.start();
            this.parentEntity.setAggressive(true);
        }

        @Override
        public void stop() {
            super.stop();
            this.parentEntity.setAggressive(false);
            this.parentEntity.setAttackingState(STATE_IDLE);
            this.attackTimer = -1;
        }

        public void tick() {
            LivingEntity target = this.parentEntity.getTarget();
            if (target == null) return;

            if (this.parentEntity.hasLineOfSight(target)) {
                ++this.attackTimer;
                this.parentEntity.getNavigation().moveTo(target, 1.5D);

                if (this.attackTimer > 0 && this.attackTimer < 15) {
                    if (this.parentEntity.getAttckingState() != STATE_ATTACK2) {
                        this.parentEntity.setAttackingState(STATE_ATTACK2);
                        this.parentEntity.triggerStateAnim(STATE_ATTACK2);
                    }
                } else if (this.attackTimer >= 15 && this.attackTimer < 30) {
                    if (this.parentEntity.getAttckingState() != STATE_ATTACK) {
                        this.parentEntity.setAttackingState(STATE_ATTACK);
                        this.parentEntity.triggerStateAnim(STATE_ATTACK);
                    }
                }

                if (this.attackTimer == 30) {
                    this.parentEntity.setAttackingState(STATE_IDLE);
                    this.attackTimer = -5;
                }
                this.parentEntity.lookAt(target, 30.0F, 30.0F);
            } else if (this.attackTimer > 0) {
                --this.attackTimer;
            }
        }
    }
}