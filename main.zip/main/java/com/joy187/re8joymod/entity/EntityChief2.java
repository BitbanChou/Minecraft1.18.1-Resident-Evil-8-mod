package com.joy187.re8joymod.entity;

import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

import javax.annotation.Nullable;

import com.joy187.re8joymod.init.BlockInit;
import com.joy187.re8joymod.init.EffectInit;
import com.joy187.re8joymod.init.EntityInit;
import com.joy187.re8joymod.init.ParticleInit;
import com.joy187.re8joymod.init.SoundInit;
import com.joy187.re8joymod.util.CommonFunctions;
import com.mojang.blaze3d.vertex.PoseStack.Pose;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.phys.Vec3;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;

public class EntityChief2 extends Ravager implements GeoEntity {

    private final AnimatableInstanceCache factory = GeckoLibUtil.createInstanceCache(this);

    // ===== 动画名 =====
    private static final String ANIM_WALK = "animation.chief2.walk";
    private static final String ANIM_IDLE = "animation.chief2.idle";
    private static final String ANIM_ATK1 = "animation.chief2.attack";
    private static final String ANIM_ATK2 = "animation.chief2.attack2";
    private static final String ANIM_RECOVER = "animation.chief2.recover"; // 需补

    // ===== 基础 =====
    private final ServerBossEvent bossInfo = (ServerBossEvent) (new ServerBossEvent(
            this.getDisplayName(), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS)).setDarkenScreen(true);

    public int explosionPower = 5, attr = 0, pre = 0;
    public boolean isaoe = false;

    public static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(EntityChief2.class,
            EntityDataSerializers.INT);
    public static final EntityDataAccessor<Integer> DEFENDSTATE = SynchedEntityData.defineId(EntityChief2.class,
            EntityDataSerializers.INT);

    // ===== 硬直 / recover =====
    private static final int STUN_TICKS = 20;      // 1 秒
    private int stunTicks = 0;
    private static final int RECOVER_TICKS = 20;   // 1 秒
    private int recoverTimer = 0;

    // ===== 出招计数 → 强制硬直 =====
    private int attacksSinceStun = 0;
    private int nextStunThreshold = 3;

    // ===== 螺旋冲刺 =====
    private boolean spiralDashing = false;
    private Vec3 spiralDashDir = Vec3.ZERO;
    private int spiralDashTicks = 0;
    private static final int SPIRAL_DASH_DURATION = 12;    // 12 tick = 0.6 秒
    private static final double SPIRAL_DASH_SPEED = 0.8;   // 每 tick 0.8 格
    private static final float SPIRAL_HIT_DAMAGE_MULT = 1.5F;
    private final Set<UUID> spiralHitSet = new HashSet<>();

    private static final Predicate<LivingEntity> LIVING_ENTITY_SELECTOR = (p) ->
            p.getMobType() != MobType.UNDEAD && p.attackable();

    public EntityChief2(EntityType<? extends Ravager> type, Level worldIn) {
        super(type, worldIn);
        this.xpReward = 250;
        this.isNonBoss();
        this.isSunSensitive();
        this.setPathfindingMalus(BlockPathTypes.LAVA, 8.0F);
    }

    protected boolean isSunSensitive() { return true; }

    // ==================== 属性 ====================

    public static AttributeSupplier.Builder prepareAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 200.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.29D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.50D)
                .add(Attributes.ATTACK_DAMAGE, 9.0D);
    }

    // ==================== Goals ====================

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new AttackGoal(this));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D) {
            @Override
            public boolean canUse() {
                return EntityChief2.this.getAttckingState() == 0
                        && EntityChief2.this.recoverTimer <= 0
                        && EntityChief2.this.stunTicks <= 0
                        && !EntityChief2.this.spiralDashing
                        && super.canUse();
            }
            @Override
            public boolean canContinueToUse() {
                return EntityChief2.this.getAttckingState() == 0
                        && EntityChief2.this.recoverTimer <= 0
                        && EntityChief2.this.stunTicks <= 0
                        && !EntityChief2.this.spiralDashing
                        && super.canContinueToUse();
            }
        });
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, AbstractVillager.class, 8.0F));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, IronGolem.class, 8.0F));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 0, false, false, LIVING_ENTITY_SELECTOR));
        this.targetSelector.addGoal(1, (new HurtByTargetGoal(this)).setAlertOthers(ZombifiedPiglin.class));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, EntityRe8Dimi.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
    }

    // ==================== 状态存取 ====================

    public int getAttckingState() { return this.entityData.get(STATE); }

    public void setAttackingState(int time) {
        int prev = this.entityData.get(STATE);
        this.entityData.set(STATE, time);
        if (time != prev) {
            if (time == 1) this.triggerAnim("controller1", "atk1");
            else if (time == 2) this.triggerAnim("controller1", "atk2");
            else if (time == 3) this.triggerAnim("controller1", "atk2");
        }
    }

    public int getDefendingState() { return this.entityData.get(DEFENDSTATE); }
    public void setDefendingState(int time) { this.entityData.set(DEFENDSTATE, time); }

    public int getStunTicks() { return this.stunTicks; }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(STATE, 0);
        this.entityData.define(DEFENDSTATE, 0);
    }

    // ==================== NBT ====================

    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (this.hasCustomName()) this.bossInfo.setName(this.getDisplayName());
    }

    public void addAdditionalSaveData(CompoundTag tag) { super.addAdditionalSaveData(tag); }

    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        this.bossInfo.setName(this.getDisplayName());
    }

    // ==================== BossBar ====================

    public boolean isNonBoss() { return false; }

    public void startSeenByPlayer(ServerPlayer p) {
        super.startSeenByPlayer(p);
        this.bossInfo.addPlayer(p);
    }

    public void stopSeenByPlayer(ServerPlayer p) {
        super.stopSeenByPlayer(p);
        this.bossInfo.removePlayer(p);
    }

    // ==================== 声音 ====================

    @Override
    protected SoundEvent getAmbientSound() {
        int co = this.random.nextInt(3);
        if (co == 0) return SoundInit.ENTITY_CHIEF_AMBIENT1.get();
        if (co == 1) return SoundInit.ENTITY_CHIEF_AMBIENT2.get();
        return SoundEvents.RAVAGER_ROAR;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource src) {
        return this.random.nextInt(2) == 0 ? SoundEvents.RAVAGER_HURT : SoundInit.ENTITY_HESEN_HURT2.get();
    }

    @Override
    protected SoundEvent getDeathSound() { return SoundInit.ENTITY_CHIEF_DEATH.get(); }

    protected float getStandingEyeHeight(Pose pose, EntityDimensions dims) { return 1.5F; }

    // ==================== AI Step ====================

    public void aiStep() {
        super.aiStep();
        Random ran = new Random();
        int co = ran.nextInt(4);
        if (co == 1 && this.attr != 2 && this.attr != 3) {
            for (int i = 0; i < 30; i++) {
                float deltaOmega = 1.0f * i;
                Vec3 pos = new Vec3(this.position().x + Math.sin(deltaOmega),
                        this.position().y + 0.1f * this.random.nextFloat(),
                        this.position().z + Math.cos(deltaOmega));
                this.level().addParticle(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 0, 0, 0);
            }
        }
        if (this.entityData.get(STATE) == 3) this.defend();
        if (this.entityData.get(STATE) == 2) {
            CommonFunctions.spawnFireFlame(this, ParticleInit.FLAME_PARTICLE.get());
        }
    }

    protected void customServerAiStep() {
        super.customServerAiStep();
        Random ran = new Random();
        if (this.getHealth() < 200F) {
            this.level().addParticle(ParticleTypes.SMOKE,
                    this.position().x + this.random.nextGaussian() * 0.3F,
                    this.position().y + this.random.nextGaussian() * 0.3F,
                    this.position().z + this.random.nextGaussian() * 0.3F, 0, 0, 0);
        }
        if (this.getHealth() >= 20F && this.getHealth() <= 30F) {
            for (int i = 0; i < 5; i++) this.heal(1.0F * ran.nextFloat());
        }
        if (this.getHealth() >= 60F && this.getHealth() <= 65F) {
            for (int i = 0; i < 4; i++) this.heal(2F * ran.nextFloat());
        }
        if (this.getHealth() < 10f && this.getHealth() > 0.01f) {
            this.convertTo(EntityInit.CHIEF3.get(), true);
        }
        this.bossInfo.setProgress(this.getHealth() / this.getMaxHealth());
    }

    private void defend() {
        if (!this.isAlive()) return;
        Vec3 c = this.getBoundingBox().getCenter();
        for (int j = 0; j < 3; j++)
            for (int i = 0; i < 10; i++) {
                float d = 1.0f * i;
                Vec3 p = new Vec3(c.x + 3 * Math.sin(d), c.y + j, c.z + 3 * Math.cos(d));
                this.level().addParticle(ParticleInit.DEFEND_PARTICLE.get(), p.x, p.y, p.z,
                        this.random.nextGaussian() * 0.07, this.random.nextGaussian() * 0.07, this.random.nextGaussian() * 0.07);
            }
        this.level().gameEvent(this, GameEvent.ENTITY_ROAR, this.getEyePosition());
    }

    // ==================== 动画控制器（triggerableAnim） ====================

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar data) {
        data.add(new AnimationController<>(this, "controller1", 3, state -> PlayState.STOP)
                .triggerableAnim("atk1", RawAnimation.begin().thenPlay(ANIM_ATK1))
                .triggerableAnim("atk2", RawAnimation.begin().thenPlay(ANIM_ATK2))
                .triggerableAnim("recover", RawAnimation.begin().thenPlay(ANIM_RECOVER)));
        data.add(new AnimationController(this, "controller", 4, this::predicate));
    }

    private <E extends GeoAnimatable> PlayState predicate(AnimationState<E> event) {
        if (this.stunTicks > 0 || this.recoverTimer > 0) return PlayState.STOP;
        if (this.getAttckingState() != 0) return PlayState.STOP;
        if (this.spiralDashing) return PlayState.STOP;
        if (event.isMoving()) {
            event.setAndContinue(RawAnimation.begin().thenLoop(ANIM_WALK));
            return PlayState.CONTINUE;
        }
        event.setAndContinue(RawAnimation.begin().thenLoop(ANIM_IDLE));
        return PlayState.CONTINUE;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return this.factory; }

    // ==================== tick ====================

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;

        // 硬直优先
        if (this.stunTicks > 0) {
            --this.stunTicks;
            this.getNavigation().stop();
            this.setDeltaMovement(this.getDeltaMovement().multiply(0.1, 1, 0.1));
            if (this.getAttckingState() != 0) this.setAttackingState(0);
            // ★ 添加这行：硬直期间每 tick 散发灰烬/眩晕粒子
            CommonFunctions.spawnStunParticles(this);
            return;
        }

        // recover 后摇
        if (this.recoverTimer > 0) {
            --this.recoverTimer;
            this.getNavigation().stop();
            this.setDeltaMovement(0, this.getDeltaMovement().y, 0);
            if (this.getAttckingState() != 0) this.setAttackingState(0);
            return;
        }

        // 螺旋冲刺
        if (this.spiralDashing) {
            this.tickSpiralDash();
        }
    }

    @Override
    public boolean doHurtTarget(Entity entityIn) {
        if (entityIn instanceof LivingEntity target) {
            float sizeMult = CommonFunctions.getSizeDamageMultiplier(this, target);

            // 如果倍率 > 1，额外补一发真实伤害（不影响原版击退和动画）
            if (sizeMult > 1.0F) {
                float baseDamage = (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE);
                float extraDamage = baseDamage * (sizeMult - 1.0F);
                target.hurt(target.damageSources().mobAttack(this), extraDamage);
            }
        }
        return super.doHurtTarget(entityIn);
    }

    @Override
    protected void updateControlFlags() {
        if (this.stunTicks > 0 || this.recoverTimer > 0 || this.spiralDashing) {
            this.goalSelector.setControlFlag(Goal.Flag.MOVE, false);
            this.goalSelector.setControlFlag(Goal.Flag.JUMP, false);
            this.goalSelector.setControlFlag(Goal.Flag.LOOK, false);
            return;
        }
        boolean flag = this.getTarget() != null && this.hasLineOfSight(this.getTarget());
        this.goalSelector.setControlFlag(Goal.Flag.LOOK, flag);
        super.updateControlFlags();
    }

    // ==================== 螺旋冲刺 ====================

    public void startSpiralDash(LivingEntity target) {
        if (target == null) return;
        Vec3 to = target.position().subtract(this.position());
        Vec3 flat = new Vec3(to.x, 0, to.z);
        if (flat.lengthSqr() < 1e-4) flat = this.getLookAngle();
        this.spiralDashDir = flat.normalize().scale(SPIRAL_DASH_SPEED);
        this.spiralDashing = true;
        this.spiralDashTicks = 0;
        this.spiralHitSet.clear();
        this.getNavigation().stop();
        this.playSound(SoundEvents.RAVAGER_ROAR, 1.0F, 1.2F);
    }

    public void tickSpiralDash() {
        if (!this.spiralDashing) return;
        this.spiralDashTicks++;

        // 移动
        this.setDeltaMovement(this.spiralDashDir.x, this.getDeltaMovement().y, this.spiralDashDir.z);
        this.hurtMarked = true;
        this.getNavigation().stop();

        // 路径伤害
        for (LivingEntity living : this.level().getEntitiesOfClass(LivingEntity.class,
                this.getBoundingBox().inflate(1.5), PIGEON_AREA)) {
            if (living == this || this.isAlliedTo(living)) continue;
            if (this.spiralHitSet.add(living.getUUID())) {
                living.hurt(this.damageSources().mobAttack(this),
                        (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE) * SPIRAL_HIT_DAMAGE_MULT);
                living.knockback(1.0, this.spiralDashDir.x, this.spiralDashDir.z);
                if (this.level() instanceof ServerLevel server) {
                    server.sendParticles(ParticleTypes.CRIT,
                            living.getX(), living.getY() + 1.0, living.getZ(),
                            8, 0.2, 0.2, 0.2, 0.1);
                }
            }
        }

        // 结束
        if (this.spiralDashTicks >= SPIRAL_DASH_DURATION) {
            this.spiralDashing = false;
            this.setDeltaMovement(0, this.getDeltaMovement().y, 0);
            this.spiralHitSet.clear();
        }
    }

    // ==================== 受击硬直 ====================

    @Override
    public boolean hurt(DamageSource source, float amount) {
        // 1. 计算减伤后的最终伤害（调用你刚写好的公共工具类）
        float finalDamage = CommonFunctions.applyNonPlayerReduction(this, source, amount);

        // 2. 扣血（传入 finalDamage）
        boolean hurt = super.hurt(source, finalDamage);

        // 3. 硬直判定（依然使用原始的 amount，这样怪物打出的高额伤害依然能造成硬直，不会因为被减伤而废掉）
        if (hurt && !this.level().isClientSide) {
            if (amount >= 6.0F && this.random.nextInt(5) == 0 && this.getAttckingState() == 0 && !this.spiralDashing) {
                this.stunTicks = STUN_TICKS;
                this.triggerAnim("controller1", "recover");
            }
        }
        return hurt;
    }

    public void triggerForcedStun() {
        this.stunTicks = STUN_TICKS;
        if (this.getAttckingState() != 0) this.setAttackingState(0);
        if (this.spiralDashing) {
            this.spiralDashing = false;
            this.setDeltaMovement(0, this.getDeltaMovement().y, 0);
        }
        this.triggerAnim("controller1", "recover");
        this.playSound(SoundEvents.ANVIL_LAND, 1.0F, 0.8F);
        if (this.level() instanceof ServerLevel server) {
            for (int i = 0; i < 10; i++) {
                double dx = (this.random.nextDouble() - 0.5) * 2.0;
                double dz = (this.random.nextDouble() - 0.5) * 2.0;
                server.sendParticles(ParticleTypes.CRIT,
                        this.getX() + dx, this.getY() + 1.0, this.getZ() + dz,
                        1, 0, 0, 0, 0.1);
            }
        }
    }

    // ==================== AttackGoal ====================

    private static final Predicate<Entity> PIGEON_AREA = (e) -> e.isAlive() && !(e instanceof EntityChief2);

    static class AttackGoal extends Goal {
        private final EntityChief2 parentEntity;
        protected int attackTimer = 0;

        public AttackGoal(EntityChief2 ghast) { this.parentEntity = ghast; }

        public boolean canUse() { return this.parentEntity.getTarget() != null; }

        public void start() { super.start(); this.parentEntity.setAggressive(true); }

        @Override
        public void stop() {
            super.stop();
            this.parentEntity.setAggressive(false);
            this.parentEntity.setAttackingState(0);
            this.parentEntity.spiralDashing = false;
            this.attackTimer = -1;
        }

        public void tick() {
            if (this.parentEntity.getStunTicks() > 0 || this.parentEntity.recoverTimer > 0) {
                this.parentEntity.setAttackingState(0);
                return;
            }

            LivingEntity livingentity = this.parentEntity.getTarget();
            if (livingentity != null && this.parentEntity.hasLineOfSight(livingentity)) {
                Level world = this.parentEntity.level();
                ++this.attackTimer;
                Random rand = new Random();
                float f = (float) Mth.atan2(livingentity.getZ() - parentEntity.getZ(),
                        livingentity.getX() - parentEntity.getX());

                // 选招
                if (this.attackTimer == 1) {
                    this.parentEntity.getNavigation().moveTo(livingentity, 1.2D);
                    this.parentEntity.setAttackingState(1);
                } else if (this.attackTimer == 18) {
                    if (this.parentEntity.getHealth() < 5 || this.parentEntity.getHealth() > 135
                            || (this.parentEntity.getHealth() > 90 && this.parentEntity.getHealth() < 101)
                            || (this.parentEntity.getHealth() > 66 && this.parentEntity.getHealth() < 81)
                            || (this.parentEntity.getHealth() > 26 && this.parentEntity.getHealth() < 39)
                            || (this.parentEntity.getHealth() > 10 && this.parentEntity.getHealth() < 18)) {
                        // STATE 2：螺旋冲刺
                        this.parentEntity.setAttackingState(2);
                        this.parentEntity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 35, 10, true, true));
                        this.parentEntity.startSpiralDash(livingentity);
                    } else {
                        // STATE 3：落石 + 燃烧
                        this.parentEntity.getNavigation().stop();
                        this.parentEntity.setAttackingState(3);
                    }
                }
                int state = this.parentEntity.getAttckingState();

                // STATE 2：冲刺中锁朝向，冲刺结束后爆炸
                if (state == 2) {
                    if (this.parentEntity.spiralDashing) {
                        this.parentEntity.getNavigation().stop();
                        this.parentEntity.lookAt(livingentity, 30.0F, 30.0F);
                    }
                    // 冲刺结束后的爆炸
                    if (this.attackTimer == 30) {
                        this.parentEntity.level().explode(this.parentEntity,
                                this.parentEntity.getX(), this.parentEntity.getY(), this.parentEntity.getZ(),
                                2.0F, true, Level.ExplosionInteraction.NONE);
                        for (LivingEntity lvt : this.parentEntity.level().getEntitiesOfClass(LivingEntity.class,
                                this.parentEntity.getBoundingBox().inflate(3.0), PIGEON_AREA)) {
                            if (lvt == this.parentEntity || this.parentEntity.isAlliedTo(lvt)) continue;
                            lvt.hurt(this.parentEntity.damageSources().mobAttack(this.parentEntity),
                                    lvt.getMaxHealth() * 0.2F);
                        }
                    }
                }

                // STATE 3：落石 + 燃烧
                if (this.attackTimer == 25 && this.parentEntity.getAttckingState() == 3) {
                    for (int i = 0; i < 7; ++i) {
                        float f1 = f + i * (float) Math.PI * 0.4F;
                        EntityFallingBlock fb = new EntityFallingBlock(this.parentEntity.level(),
                                this.parentEntity.getX() + Mth.cos(f1) * 1.5D,
                                this.parentEntity.getY() + this.parentEntity.random.nextDouble(),
                                this.parentEntity.getZ() + Mth.sin(f1) * 1.5D,
                                BlockInit.FACT_IRON_BLOCK.get().defaultBlockState(), 10);
                        this.parentEntity.level().addFreshEntity(fb);
                    }
                    for (int k = 0; k < 10; ++k) {
                        float f2 = f + k * (float) Math.PI * 2.0F / 8.0F + 1.2566371F;
                        EntityFallingBlock fb = new EntityFallingBlock(this.parentEntity.level(),
                                this.parentEntity.getX() + Mth.cos(f2) * 1.5D,
                                this.parentEntity.getY() + this.parentEntity.random.nextDouble(),
                                this.parentEntity.getZ() + Mth.sin(f2) * 1.5D,
                                BlockInit.FACT_IRON_BLOCK.get().defaultBlockState(), 10);
                        this.parentEntity.level().addFreshEntity(fb);
                    }
                }

                if (this.attackTimer == 30 && this.parentEntity.getAttckingState() == 3) {
                    Vec3 c = this.parentEntity.getBoundingBox().getCenter();
                    for (int j = 0; j < 10; j++)
                        for (int i = 0; i < 10; i++) {
                            float d = 1.0f * i;
                            Vec3 p = new Vec3(c.x + Math.sin(d), c.y + j, c.z + Math.cos(d));
                            this.parentEntity.level().addParticle(ParticleInit.DEFEND_PARTICLE.get(), p.x, p.y, p.z, 0, 0, 0);
                        }
                    for (LivingEntity lvt : this.parentEntity.level().getEntitiesOfClass(LivingEntity.class,
                            this.parentEntity.getBoundingBox().inflate(6.0D), PIGEON_AREA)) {
                        lvt.addEffect(new MobEffectInstance(EffectInit.BURN.get(), 10 * 20, 2, true, true));
                    }
                }

                // 收尾：进入 recover + 出招计数
                if (this.attackTimer == 35) {
                    this.parentEntity.setAttackingState(0);
                    this.parentEntity.recoverTimer = RECOVER_TICKS;
                    this.parentEntity.triggerAnim("controller1", "recover");
                    this.attackTimer = -5;

                    this.parentEntity.attacksSinceStun++;
                    if (this.parentEntity.attacksSinceStun >= this.parentEntity.nextStunThreshold) {
                        this.parentEntity.attacksSinceStun = 0;
                        this.parentEntity.nextStunThreshold = 3 + this.parentEntity.random.nextInt(3);
                        this.parentEntity.triggerForcedStun();
                    }
                }

                this.parentEntity.lookAt(livingentity, 30.0F, 30.0F);
            } else if (this.attackTimer > 0) {
                --this.attackTimer;
            }
        }
    }
}