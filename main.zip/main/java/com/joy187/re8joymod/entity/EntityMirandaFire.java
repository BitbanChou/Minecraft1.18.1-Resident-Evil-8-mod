package com.joy187.re8joymod.entity;

import com.joy187.re8joymod.init.EntityInit;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Barrage fireball. Same burn-on-hit as a small fireball, without lighting blocks.
 */
public class EntityMirandaFire extends SmallFireball {
    private static final int MAX_LIFE = 80;
    public EntityMirandaFire(EntityType<? extends SmallFireball> type, Level level) {
        super(type, level);
    }

    public EntityMirandaFire(Level level, LivingEntity owner, double x, double y, double z, double dx, double dy, double dz) {
        this(EntityInit.MIRANDA_FIRE.get(), level);
        this.setOwner(owner);
//        this.setPos(x, y, z);
        this.moveTo(x, y, z, this.getYRot(), this.getXRot());
        double len = Math.sqrt(dx*dx+dy*dy+dz*dz);
        if(len<1E-6D){
            len=1.0D;
            dy=-1.0D;
        }
        this.xPower = dx / len * 0.1D;
        this.yPower = dy / len * 0.1D;
        this.zPower = dz / len * 0.1D;
        this.setDeltaMovement(this.xPower,this.yPower,this.zPower);
    }

    @Override
    public void tick() {
        super.tick();
        if(!this.level().isClientSide && this.tickCount > MAX_LIFE) {
            this.discard();
        }
    }


    @Override
    protected void onHitBlock(BlockHitResult result) {
        // 不点燃方块，但必须让火球消失，否则会永久残留
    }
}