package com.joy187.re8joymod.entity;

import java.util.List;

import com.joy187.re8joymod.init.ParticleInit;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.Vec3;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public class EntityAxeman extends EntityUrias implements GeoEntity {

	// ===================== 动画/同步数据 =====================
	private final AnimatableInstanceCache factory = GeckoLibUtil.createInstanceCache(this);

	/** 跳跃技能阶段同步：0=无, 1=windup, 2=leap, 3=land（客户端 predicate 用） */
	public static final EntityDataAccessor<Integer> JUMPSTATE =
			SynchedEntityData.defineId(EntityAxeman.class, EntityDataSerializers.INT);

	// ===================== 跳跃技能字段（仅服务端逻辑用） =====================
	private static final int JUMP_NONE   = 0;
	private static final int JUMP_WINDUP = 1;
	private static final int JUMP_LEAP   = 2;
	private static final int JUMP_LAND   = 3;

	private static final int WINDUP_TICKS = 15;
	private static final int LEAP_MAX_TICKS = 20;
	private static final int LAND_RECOVER_TICKS = 6;

	private int jumpPhase = JUMP_NONE;
	private int jumpTimer = 0;
	private int jumpCooldown = 0;

	/** 跳跃技能触发参数 */
	private static final double JUMP_TRIGGER_MIN = 6.0D;
	private static final double JUMP_TRIGGER_MAX = 8.0D;
	private static final int    JUMP_TRIGGER_CHANCE = 35;  // 35%
	private static final int    JUMP_COOLDOWN_TICKS = 120; // 6s

	// ===================== 构造 & 属性 =====================
	public EntityAxeman(EntityType<? extends Ravager> type, Level worldIn) {
		super(type, worldIn);
		this.xpReward = 100;
	}

	public static AttributeSupplier.Builder prepareAttributes() {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, 120.0D)
				.add(Attributes.MOVEMENT_SPEED, 0.16D)       // 慢
				.add(Attributes.FOLLOW_RANGE, 25.0D)
				.add(Attributes.ARMOR, 10.0D)
				.add(Attributes.ARMOR_TOUGHNESS, 25.0D)
				.add(Attributes.KNOCKBACK_RESISTANCE, 0.85D)
				.add(Attributes.ATTACK_DAMAGE, 26.0D);       // 高伤
	}

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();               // 父类已 define STATE/DEFENDSTATE
		this.entityData.define(JUMPSTATE, 0);
	}

	// ===================== 禁冲锋 + 重击权重（覆盖父类钩子） =====================
	@Override protected int getChargeChance() { return 0; }         // 永不冲锋
	@Override protected double getChargeMinDist() { return 0.0D; }
	@Override protected double getChargeMaxDist() { return 0.0D; }

	// ===================== 动画控制器 =====================
	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar data) {
		data.add(new AnimationController<>(this, "controller1", 3, state -> PlayState.STOP)
				.triggerableAnim("slash",      RawAnimation.begin().thenPlay("animation.axeman.attack"))
				.triggerableAnim("heavy",      RawAnimation.begin().thenPlay("animation.axeman.attack2"))
				.triggerableAnim("jump_windup",RawAnimation.begin().thenPlay("animation.axeman.jump_windup"))
				.triggerableAnim("jump_leap",  RawAnimation.begin().thenPlay("animation.axeman.jump_leap"))
				.triggerableAnim("jump_land",  RawAnimation.begin().thenPlay("animation.axeman.jump_land")));
		data.add(new AnimationController<>(this, "controller", 8, this::predicate));
	}

	@Override
	protected <E extends GeoAnimatable> PlayState predicate(AnimationState<E> event) {
		int atk  = this.getAttckingState();                 // 父类 STATE
		int jump = this.entityData.get(JUMPSTATE);

		// 攻击或跳跃时让 controller1 主导，locomotion 停止
		if (atk == 1 || atk == 2 || jump != JUMP_NONE) {
			return PlayState.STOP;
		}
		// 后摇恢复（父类攻击结束后会进 DEFENDSTATE=1）
		if (this.getDefendingState() == 1) {
			event.setAndContinue(RawAnimation.begin().thenLoop("animation.axeman.recover"));
			return PlayState.CONTINUE;
		}
		boolean moving = event.isMoving()
				|| this.getDeltaMovement().horizontalDistanceSqr() > 1.0E-5D;
		if (moving) {
			event.setAndContinue(RawAnimation.begin().thenLoop("animation.axeman.walk"));
			return PlayState.CONTINUE;
		}
		event.setAndContinue(RawAnimation.begin().thenLoop("animation.axeman.idle"));
		return PlayState.CONTINUE;
	}

	@Override
	protected void startAttackAnim(int state) {
		if (state == 1)      this.triggerAnim("controller1", "slash");
		else if (state == 2) this.triggerAnim("controller1", "heavy");
		// state == 3：无冲锋，不做事
	}

	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {
		return this.factory;
	}

	// ===================== tick：跳跃技能优先，再走父类 =====================
	@Override
	public void tick() {
		if (this.jumpCooldown > 0) this.jumpCooldown--;

		// --- 跳跃技能进行中：自己处理，然后仍调 super.tick() 让重力/移动生效 ---
		if (this.jumpPhase != JUMP_NONE) {
			this.handleJumpSkill(this.getTarget());
			super.tick();
			this.getNavigation().stop();   // 覆盖父类 tick 内的 moveTo，避免干扰跳跃
			return;
		}

		// --- 触发判定 ---
		LivingEntity target = this.getTarget();
		if (target != null
				&& this.hasLineOfSight(target)
				&& this.getAttckingState() == 0
				&& this.jumpCooldown <= 0
				&& !this.hasEffect(MobEffects.DAMAGE_RESISTANCE)
				&& this.onGround()) {
			double dist = this.distanceTo(target);
			if (dist >= JUMP_TRIGGER_MIN && dist <= JUMP_TRIGGER_MAX
					&& this.random.nextInt(100) < JUMP_TRIGGER_CHANCE) {
				this.startJumpSkill(target);
				super.tick();
				this.getNavigation().stop();
				return;
			}
		}

		super.tick();
	}

	// ===================== 跳跃技能实现 =====================
	private void startJumpSkill(LivingEntity target) {
		this.jumpPhase = JUMP_WINDUP;
		this.jumpTimer = 0;
		this.jumpCooldown = JUMP_COOLDOWN_TICKS;

		// 清父类攻击态，并锁住父类"attackTimer==3 选技能"
		this.setAttackingState(0);
		this.lockParentAttackTimer();

		this.entityData.set(JUMPSTATE, JUMP_WINDUP);
		this.triggerAnim("controller1", "jump_windup");

		this.getNavigation().stop();
		this.setDeltaMovement(Vec3.ZERO);
		if (target != null) this.lookAt(target, 30.0F, 30.0F);
		this.playSound(SoundEvents.RAVAGER_ROAR, 0.8F, 0.7F);
	}

	private void handleJumpSkill(LivingEntity target) {
		this.jumpTimer++;

		switch (this.jumpPhase) {
			case JUMP_WINDUP -> {
				this.getNavigation().stop();
				this.setDeltaMovement(this.getDeltaMovement().multiply(0.2D, 1.0D, 0.2D));
				if (target != null) this.lookAt(target, 30.0F, 30.0F);
				this.spawnWindupParticles();

				if (this.jumpTimer >= WINDUP_TICKS) {
					this.launchToward(target);
				}
			}
			case JUMP_LEAP -> {
				this.spawnAirParticles();
				boolean landed = this.onGround() && this.jumpTimer > 3;
				if (landed || this.jumpTimer >= LEAP_MAX_TICKS) {
					this.jumpPhase = JUMP_LAND;
					this.jumpTimer = 0;
					this.entityData.set(JUMPSTATE, JUMP_LAND);
					this.triggerAnim("controller1", "jump_land");
					this.performJumpLanding(target);
				}
			}
			case JUMP_LAND -> {
				this.setDeltaMovement(this.getDeltaMovement().multiply(0.3D, 1.0D, 0.3D));
				if (this.jumpTimer >= LAND_RECOVER_TICKS) {
					this.jumpPhase = JUMP_NONE;
					this.jumpTimer = 0;
					this.entityData.set(JUMPSTATE, JUMP_NONE);
					this.unlockParentAttackTimer();
					// 后摇无敌/虚弱，给玩家反应时间
					this.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20, 10, true, true));
					this.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 20, 10, true, true));
				}
			}
			default -> { /* no-op */ }
		}
	}

	/** 起跳：朝目标给抛物线初速度。 */
	private void launchToward(LivingEntity target) {
		if (target != null) {
			Vec3 to = target.position().subtract(this.position());
			Vec3 flat = new Vec3(to.x, 0.0D, to.z);
			double horiz = flat.length();
			double speed = Math.min(1.2D, 0.35D + horiz * 0.06D);
			Vec3 dir = horiz > 1.0E-4D ? flat.scale(speed / horiz) : Vec3.ZERO;
			this.setDeltaMovement(dir.x, 0.85D, dir.z);
		} else {
			this.setDeltaMovement(0.0D, 0.85D, 0.0D);
		}
		this.hasImpulse = true;

		this.jumpPhase = JUMP_LEAP;
		this.jumpTimer = 0;
		this.entityData.set(JUMPSTATE, JUMP_LEAP);
		this.triggerAnim("controller1", "jump_leap");
		this.playSound(SoundEvents.RAVAGER_ROAR, 1.0F, 0.8F);
	}

	/** 落地：中心高、边缘低的范围伤害 + 浮空 + 复用地形砸击 + 粒子音效。 */
	private void performJumpLanding(LivingEntity target) {
		float radius = 3.5F;
		List<LivingEntity> hits = this.level().getEntitiesOfClass(
				LivingEntity.class,
				this.getBoundingBox().inflate(radius, 1.5D, radius),
				e -> e.isAlive() && e != this && !(e instanceof EntityUrias));

		for (LivingEntity lvt : hits) {
			double d = lvt.position().distanceTo(this.position());
			float factor = (float) Mth.clamp(1.0D - d / (radius + 0.5D), 0.3D, 1.0D);
			float dmg = (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE) * 1.5F * factor;
			lvt.hurt(this.damageSources().mobAttack(this), dmg);
			lvt.knockback(0.9D, this.getX() - lvt.getX(), this.getZ() - lvt.getZ());
			lvt.setDeltaMovement(lvt.getDeltaMovement().add(0.0D, 0.35D * factor, 0.0D));
		}

		// 复用地形砸击（破盾 + 百分比伤害），环形 6 点
		for (int i = 0; i < 6; i++) {
			float ang = (float) (Math.PI * 2.0D / 6.0D * i);
			this.blockSmashAttack(2, 2.0F, (float) Mth.cos(ang) * 2.0F,
					100, 0.6F, 0.05F, 0.4F);
		}

		this.spawnLandParticles();
		this.playSound(SoundEvents.GENERIC_EXPLODE, 1.2F, 0.7F);
		this.playSound(SoundEvents.RAVAGER_STUNNED, 1.0F, 0.6F);
		this.level().gameEvent(this, GameEvent.ENTITY_ROAR, this.getEyePosition());
	}

	// ===================== 粒子 =====================
	private void spawnWindupParticles() {
		Vec3 c = this.position();
		for (int i = 0; i < 8; i++) {
			float a = (float) (Math.PI * 2.0D / 8.0D * i + this.tickCount * 0.15F);
			double x = c.x + Math.cos(a) * 1.2D;
			double z = c.z + Math.sin(a) * 1.2D;
			this.level().addParticle(ParticleInit.MUCUS_PARTICLE.get(),
					x, c.y + 0.1D, z, 0.0D, 0.02D, 0.0D);
		}
		this.level().addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE,
				c.x, c.y + 0.2D, c.z, 0.0D, 0.05D, 0.0D);
	}

	private void spawnAirParticles() {
		Vec3 c = this.getBoundingBox().getCenter();
		this.level().addParticle(ParticleTypes.CLOUD, c.x, c.y, c.z, 0.0D, -0.05D, 0.0D);
	}

	private void spawnLandParticles() {
		Vec3 c = this.position();
		for (int j = 0; j < 3; j++) {
			for (int i = 0; i < 16; i++) {
				float a = (float) (Math.PI * 2.0D / 16.0D * i);
				double r = 1.0D + j * 0.8D;
				double x = c.x + Math.cos(a) * r;
				double z = c.z + Math.sin(a) * r;
				this.level().addParticle(ParticleInit.DEFEND_PARTICLE.get(),
						x, c.y + 0.1D + j * 0.05D, z, 0.0D, 0.05D, 0.0D);
			}
		}
		for (int i = 0; i < 24; i++) {
			double dx = (this.random.nextDouble() - 0.5D) * 0.6D;
			double dz = (this.random.nextDouble() - 0.5D) * 0.6D;
			this.level().addParticle(ParticleTypes.EXPLOSION,
					c.x, c.y + 0.2D, c.z, dx, 0.1D, dz);
		}
	}

	// ===================== 父类 attackTimer 锁（见文末说明） =====================
	/**
	 * 跳跃期间要阻止父类 tick 里 "attackTimer == 3 选技能" 的逻辑。
	 * 父类 attackTimer 是 private，这里用反射把它设成很大负数。
	 * 若你能改父类，把 attackTimer 改为 protected，则删掉反射、直接 this.attackTimer = -9999。
	 */
	private void lockParentAttackTimer() {
		setParentIntField("attackTimer", -9999);
		setParentIntField("attr", 0);
	}

	private void unlockParentAttackTimer() {
		setParentIntField("attackTimer", 0);
	}

	private void setParentIntField(String name, int value) {
		try {
			var f = EntityUrias.class.getDeclaredField(name);
			f.setAccessible(true);
			f.setInt(this, value);
		} catch (ReflectiveOperationException e) {
			// 若父类字段已改 protected，可直接访问，这里不会走到
			throw new RuntimeException("Failed to set EntityUrias." + name, e);
		}
	}
}