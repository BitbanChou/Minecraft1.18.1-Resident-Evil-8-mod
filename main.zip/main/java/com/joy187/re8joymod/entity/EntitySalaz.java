package com.joy187.re8joymod.entity;

import java.util.*;
import java.util.function.Predicate;

import com.joy187.re8joymod.init.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.BossEvent.BossBarColor;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ThrownEgg;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ToolActions;
import net.minecraftforge.event.ForgeEventFactory;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public class EntitySalaz extends Monster implements RangedAttackMob, GeoEntity {

    private AnimatableInstanceCache factory = GeckoLibUtil.createInstanceCache(this);

    private final float[] xRotHeads = new float[2];
    private final float[] yRotHeads = new float[2];
    private final float[] xRotOHeads = new float[2];
    private final float[] yRotOHeads = new float[2];
    private final int[] nextHeadUpdate = new int[2];
    private final int[] idleHeadUpdates = new int[2];
    public float Laser_Mode_Progress;
    public float prev_Laser_Mode_Progress;
    public float deactivateProgress;
    public float prevdeactivateProgress;
    private int destroyBlocksTick;
    private int blockBreakCounter;

    // === FIX 1: 拆方块统一冷却 & 单次上限 ===
    private int blockBreakCooldown = 0;
    private static final int BLOCK_BREAK_COOLDOWN_TICKS = 120;   // 6 秒
    private static final int MAX_BLOCKS_PER_BREAK = 6;
    private static final int MAX_BLOCKS_PER_CHARGE = 3;
    private static final float BLOCK_BREAK_CHANCE = 0.35F;
    private static final double MOB_GRIEFING_RADIUS = 1.5D;

    // === FIX 3: 硬直系统 ===
    public static final EntityDataAccessor<Integer> STUN_TICKS =
            SynchedEntityData.defineId(EntitySalaz.class, EntityDataSerializers.INT);
    private static final int MAX_STUN_TICKS = 60;   // 硬直上限 3 秒

    // === FIX 2: 技能全局冷却 ===
    private static final int SKILL_COOLDOWN_TICKS = 200;          // 10 秒
    private static final int SKILL_COOLDOWN_AFTER_ATTACK = 60;    // 每次技能后 3 秒

    private final ServerBossEvent bossInfo = (ServerBossEvent)
            (new ServerBossEvent(this.getDisplayName(), BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS))
                    .setDarkenScreen(true);

    public static final EntityDataAccessor<Integer> STATE =
            SynchedEntityData.defineId(EntitySalaz.class, EntityDataSerializers.INT);
    public static final EntityDataAccessor<Boolean> ISCHARGE =
            SynchedEntityData.defineId(EntitySalaz.class, EntityDataSerializers.BOOLEAN);

    private int mode_change_cooldown;
    private int skill_cooldown;

    private static final Predicate<LivingEntity> LIVING_ENTITY_SELECTOR = (p_31504_) ->
            p_31504_.attackable() && !(p_31504_ instanceof EntitySalaz);

    private static final TargetingConditions TARGETING_CONDITIONS =
            TargetingConditions.forCombat().range(20.0D).selector(LIVING_ENTITY_SELECTOR);

    public EntitySalaz(EntityType entity, Level world) {
        super(entity, world);
        this.mode_change_cooldown = 0;
        this.skill_cooldown = 160;
        this.xpReward = 300;
        this.moveControl = new FlyingMoveControl(this, 10, false);
    }

    protected PathNavigation createNavigation(Level p_186262_) {
        FlyingPathNavigation flyingpathnavigation = new FlyingPathNavigation(this, p_186262_);
        flyingpathnavigation.setCanOpenDoors(false);
        flyingpathnavigation.setCanFloat(true);
        flyingpathnavigation.setCanPassDoors(true);
        return flyingpathnavigation;
    }

    protected void registerGoals() {
        this.goalSelector.addGoal(1, new AttackGoal(this));
        // === FIX 2: 弹幕冷却从 40 → 80 ===
        this.goalSelector.addGoal(2, new RangedAttackGoal(this, 1.0D, 80, 20.0F));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomFlyingGoal(this, 1.0D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this, new Class[0]));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal(this, LivingEntity.class, 0, false, false, LIVING_ENTITY_SELECTOR));
    }

    public static Builder prepareAttributes() {
        return Monster.createMonsterAttributes().
                add(Attributes.MAX_HEALTH, 350.0D).
                add(Attributes.MOVEMENT_SPEED, 0.601D).
                add(Attributes.KNOCKBACK_RESISTANCE, 0.60000002384185).
                add(Attributes.FLYING_SPEED, 0.701D).
                add(Attributes.ARMOR, 10.01D).
                add(Attributes.ATTACK_DAMAGE, 9.0D);
    }

    protected int decreaseAirSupply(int air) { return air; }

    public boolean causeFallDamage(float p_148711_, float p_148712_, DamageSource p_148713_) { return false; }

    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ISCHARGE, false);
        this.entityData.define(STATE, 0);
        // === FIX 3: 注册硬直同步字段 ===
        this.entityData.define(STUN_TICKS, 0);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("BlockBreakCooldown", this.blockBreakCooldown);
        tag.putInt("SkillCooldown", this.skill_cooldown);
        tag.putInt("StunTicks", this.getStunTicks());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (this.hasCustomName()) {
            this.bossInfo.setName(this.getDisplayName());
        }

        if (tag.contains("BlockBreakCooldown")) this.blockBreakCooldown = tag.getInt("BlockBreakCooldown");
        if (tag.contains("SkillCooldown")) this.skill_cooldown = tag.getInt("SkillCooldown");
        if (tag.contains("StunTicks")) this.setStunTicks(tag.getInt("StunTicks"));
    }

    public double calculateRange(DamageSource damagesource) {
        return damagesource.getEntity() != null ? this.distanceToSqr(damagesource.getEntity()) : -1.0D;
    }

    public boolean hurt(DamageSource source, float damage) {
        Entity entity1 = source.getEntity();
        if (entity1 instanceof EntitySalaz) {
            return false;
        } else if (source == damageSources().lightningBolt() || source == damageSources().fellOutOfWorld()) {
            return super.hurt(source, damage);
        } else if (entity1 instanceof EntitySaddler || entity1 instanceof EntitySaddler2) {
            return super.hurt(source, damage * 5);
        } else if (source.getDirectEntity() instanceof ThrownEgg) {
            return super.hurt(source, 10);
        } else if (source.getDirectEntity() instanceof EntityGE) {
            return super.hurt(source, this.getMaxHealth() * 0.6f);
        } else if (source.getEntity() instanceof EntityChief || source.getEntity() instanceof EntitySaddler) {
            return super.hurt(source, damage / 3);
        } else if (source.getEntity() instanceof IronGolem) {
            return super.hurt(source, damage / 4);
        } else {
            for (int i = 0; i < this.idleHeadUpdates.length; ++i) {
                this.idleHeadUpdates[i] += 3;
            }

            double range = this.calculateRange(source);
            if (range > 8D) {
                return false;
            } else {
                if (this.destroyBlocksTick <= 0 && this.blockBreakCooldown <= 0) {
                    this.destroyBlocksTick = 20;
                }

                if (!source.isIndirect()) {
                    damage = Math.min(10, damage);
                }

                Entity entity = source.getDirectEntity();
                if (entity instanceof AbstractArrow) {
                    return false;
                }

                // === FIX 3: 受击累积硬直 ===
                boolean result = !source.isIndirect() ? false : super.hurt(source, damage);
                if (result && !this.level().isClientSide) {
                    int add = (int) (damage * 2);
                    this.setStunTicks(Math.min(this.getStunTicks() + add, MAX_STUN_TICKS));
                }
                return result;
            }
        }
    }

    // ===== 硬直 getter/setter =====
    public int getStunTicks() { return this.entityData.get(STUN_TICKS); }
    public void setStunTicks(int t) { this.entityData.set(STUN_TICKS, Math.max(0, t)); }
    public boolean isStunned() { return this.getStunTicks() > 0; }

    public void startSeenByPlayer(ServerPlayer p_184178_1_) {
        super.startSeenByPlayer(p_184178_1_);
        this.bossInfo.addPlayer(p_184178_1_);
    }

    public void stopSeenByPlayer(ServerPlayer p_184203_1_) {
        super.stopSeenByPlayer(p_184203_1_);
        this.bossInfo.removePlayer(p_184203_1_);
    }

    public void aiStep() {
        Vec3 vec3 = this.getDeltaMovement().multiply(1.0D, 0.6D, 1.0D);

        // === FIX (bossInfo): 只在服务端同步 ===
        if (!this.level().isClientSide) {
            this.bossInfo.setProgress(this.getHealth() / this.getMaxHealth());
        }

        this.prev_Laser_Mode_Progress = this.Laser_Mode_Progress;
        this.prevdeactivateProgress = this.deactivateProgress;

        if (!this.getIsAct() && this.deactivateProgress < 40.0F) {
            this.deactivateProgress = 40.0F;
        }

        if (this.getIsAct() && this.deactivateProgress > 0.0F) {
            --this.deactivateProgress;
        }

        // === FIX 2: skill_cooldown 每 tick 递减 ===
        if (this.skill_cooldown > 0) {
            --this.skill_cooldown;
        }

        if (!this.isSilent() && !this.level().isClientSide && this.deactivateProgress == 0.0F) {
            this.level().broadcastEntityEvent(this, (byte) 67);
        }

        Entity entity = this.level().getEntity(this.getAlternativeTarget(0));
        LivingEntity target = this.getTarget();

        // === FIX 3: 硬直期间压低移动速度 ===
        if (this.isStunned()) {
            vec3 = vec3.multiply(0.5, 0.5, 0.5);
        }

        this.setDeltaMovement(vec3);
        if (vec3.horizontalDistanceSqr() > 0.05D) {
            this.setYRot((float) Mth.atan2(vec3.z, vec3.x) * 57.295776F - 90.0F);
        }

        super.aiStep();

        int j;
        for (j = 0; j < 2; ++j) {
            this.yRotOHeads[j] = this.yRotHeads[j];
            this.xRotOHeads[j] = this.xRotHeads[j];
        }

        for (j = 0; j < 2; ++j) {
            int k = j;
            Entity entity1 = null;
            if (k > 0) {
                entity1 = this.level().getEntity(k);
            }

            if (entity1 != null) {
                double d9 = this.getHeadX(j + 1);
                double d1 = this.getHeadY(j + 1);
                double d3 = this.getHeadZ(j + 1);
                double d4 = entity1.getX() - d9;
                double d5 = entity1.getEyeY() - d1;
                double d6 = entity1.getZ() - d3;
                double d7 = Math.sqrt(d4 * d4 + d6 * d6);
                float f = (float) (Mth.atan2(d6, d4) * 57.2957763671875D) - 90.0F;
                float f1 = (float) (-(Mth.atan2(d5, d7) * 57.2957763671875D));
                this.xRotHeads[j] = this.m_31442_(this.xRotHeads[j], f1, 40.0F);
                this.yRotHeads[j] = this.m_31442_(this.yRotHeads[j], f, 10.0F);
            } else {
                this.yRotHeads[j] = this.m_31442_(this.yRotHeads[j], this.yBodyRot, 10.0F);
            }
        }

        if (this.level().isClientSide && this.getIsAct()) {
            double d0 = (double) (this.random.nextFloat() - 0.5F) + this.getDeltaMovement().x;
            double d1 = (double) (this.random.nextFloat() - 0.5F) + this.getDeltaMovement().y;
            double d2 = (double) (this.random.nextFloat() - 0.5F) + this.getDeltaMovement().z;
            double dist = (double) (1.0F + this.random.nextFloat() * 0.2F);
            double d3 = d0 * dist;
            double d4 = d1 * dist;
            double d5 = d2 * dist;
            this.level().addParticle(ParticleInit.FLAME_PARTICLE.get(), this.getX() + d0, this.getY() + 2.0D, this.getZ() + d2, d3, d4, d5);

            if (entity != null && this.getAttckingState() != 0) {
                float f = Mth.cos(this.yBodyRot * 0.017453292F);
                float f1 = Mth.sin(this.yBodyRot * 0.017453292F);
                double theta = (double) this.yBodyRot * 0.017453292519943295D;
                ++theta;
                double vecX = Math.cos(theta);
                double vecZ = Math.sin(theta);
                double vec = -1.75D;
                double math = 1.35D;

                int i1;
                float angle;
                double extraX;
                double extraY;
                double extraZ;
                for (i1 = 0; i1 < 10; ++i1) {
                    angle = 0.017453292F * this.yBodyRot + (float) i1;
                    extraX = (double) (0.2F * Mth.sin((float) (3.141592653589793D + (double) angle)));
                    extraY = 2.75D;
                    extraZ = (double) (0.2F * Mth.cos(angle));
                    this.level().addParticle(ParticleInit.MUCUS_PARTICLE.get(), this.getX() + vec * vecX + extraX + (double) f * math, this.getY() + extraY, this.getZ() + vec * vecZ + extraZ + (double) f1 * math, 0.0D, -0.07D, 0.0D);
                    this.level().addParticle(ParticleInit.MUCUS_PARTICLE.get(), this.getX() + vec * vecX + extraX + (double) f * -math, this.getY() + extraY, this.getZ() + vec * vecZ + extraZ + (double) f1 * -math, 0.0D, -0.07D, 0.0D);
                }

                for (i1 = 0; i1 < 5; ++i1) {
                    angle = 0.017453292F * this.yBodyRot + (float) i1;
                    extraX = (double) (0.2F * Mth.sin((float) (3.141592653589793D + (double) angle)));
                    extraY = 2.75D;
                    extraZ = (double) (0.2F * Mth.cos(angle));
                    this.level().addParticle(ParticleTypes.SQUID_INK, this.getX() + vec * vecX + extraX + (double) f * math, this.getY() + extraY, this.getZ() + vec * vecZ + extraZ + (double) f1 * math, 0.0D, -0.07D, 0.0D);
                    this.level().addParticle(ParticleTypes.SQUID_INK, this.getX() + vec * vecX + extraX + (double) f * -math, this.getY() + extraY, this.getZ() + vec * vecZ + extraZ + (double) f1 * -math, 0.0D, -0.07D, 0.0D);
                }
            }

            if (this.getAttckingState() == 2) {
                for (int i = 0; i < 2; ++i) {
                    this.level().addParticle(ParticleTypes.SMOKE, this.getRandomX(1.5D), this.getRandomY(), this.getRandomZ(1.5D), 0.0D, 0.0D, 0.0D);
                }
            }
        }
    }

    // === FIX 1: blockbreak 加冷却 + 概率 + 单次上限 ===
    private void blockbreak() {
        // 伤害逻辑保留，但硬直期间不执行
        if (this.getIsCharge() && this.tickCount % 4 == 0 && !this.isStunned()) {
            for (LivingEntity Lentity : this.level().getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(1.5D))) {
                if (!this.isAlliedTo(Lentity) && !(Lentity instanceof EntitySalaz) && Lentity != this) {
                    boolean flag = Lentity.hurt(Lentity.damageSources().mobAttack(this),
                            (float) ((double) ((float) this.getAttributeValue(Attributes.ATTACK_DAMAGE) + (float) this.random.nextInt(5))
                                    + Math.min(this.getAttributeValue(Attributes.ATTACK_DAMAGE), (double) Lentity.getMaxHealth() * 0.2D)));
                    if (flag && Lentity.onGround()) {
                        double d0 = Lentity.getX() - this.getX();
                        double d1 = Lentity.getZ() - this.getZ();
                        double d2 = Math.max(d0 * d0 + d1 * d1, 0.001D);
                        float f = 1.5F;
                        Lentity.push(d0 / d2 * (double) f, 0.5D, d1 / d2 * (double) f);
                    }
                }
            }
        }

        // 拆方块：加冷却 + 概率 + 单次上限
        if (!this.getIsCharge() || this.level().isClientSide || this.blockBreakCooldown > 0
                || !ForgeEventFactory.getMobGriefingEvent(this.level(), this)) {
            return;
        }

        AABB aabb = this.getBoundingBox().inflate(1.0D, 0.1D, 1.0D);
        int broken = 0;
        boolean flag = false;
        for (BlockPos pos : BlockPos.betweenClosed(
                Mth.floor(aabb.minX), Mth.floor(aabb.minY), Mth.floor(aabb.minZ),
                Mth.floor(aabb.maxX), Mth.floor(aabb.maxY), Mth.floor(aabb.maxZ))) {
            if (broken >= MAX_BLOCKS_PER_CHARGE) break;
            BlockState state = this.level().getBlockState(pos);
            if (state.getBlock() instanceof AirBlock || state.is(Blocks.BEDROCK)
                    || state.hasBlockEntity() || !this.level().getFluidState(pos).isEmpty()
                    || state.getDestroySpeed(this.level(), pos) < 0
                    || !state.canEntityDestroy(this.level(), pos, this)
                    || !ForgeEventFactory.onEntityDestroyBlock(this, pos, state)) {
                continue;
            }
            if (this.random.nextFloat() > BLOCK_BREAK_CHANCE) continue;

            if (this.random.nextInt(5) == 0) {
                FireEntity fallingBlockEntity = new FireEntity(EntityInit.FIREENTITY.get(), this.level());
                fallingBlockEntity.setBlock(Blocks.BLACKSTONE.defaultBlockState());
                flag = this.level().destroyBlock(pos, false, this) || flag;
                fallingBlockEntity.setDeltaMovement(fallingBlockEntity.getDeltaMovement().add(
                        this.position().subtract(fallingBlockEntity.position()).multiply(
                                (-1.2D + this.random.nextDouble()) / 3.0D,
                                0.2D + this.getRandom().nextGaussian() * 0.15D,
                                (-1.2D + this.random.nextDouble()) / 3.0D)));
                this.level().addFreshEntity(fallingBlockEntity);
            } else {
                flag = this.level().destroyBlock(pos, false, this) || flag;
            }
            ++broken;
        }
        if (flag) {
            this.level().levelEvent((Player) null, 1022, this.blockPosition(), 0);
            this.blockBreakCooldown = BLOCK_BREAK_COOLDOWN_TICKS;
        }
    }

    // === FIX 1: destoryblock2 加冷却 + 上限 ===
    private void destoryblock2() {
        if (this.blockBreakCounter > 0) {
            --this.blockBreakCounter;
            return;
        }
        if (this.blockBreakCooldown > 0) {
            --this.blockBreakCooldown;
            return;
        }
        if (this.getIsCharge() || this.level().isClientSide || this.isStunned()
                || !ForgeEventFactory.getMobGriefingEvent(this.level(), this)) {
            return;
        }

        AABB aabb = this.getBoundingBox().inflate(MOB_GRIEFING_RADIUS, 0.2D, MOB_GRIEFING_RADIUS);
        int broken = 0;
        boolean flag = false;
        for (BlockPos pos : BlockPos.betweenClosed(
                Mth.floor(aabb.minX), Mth.floor(aabb.minY), Mth.floor(aabb.minZ),
                Mth.floor(aabb.maxX), Mth.floor(aabb.maxY), Mth.floor(aabb.maxZ))) {
            if (broken >= MAX_BLOCKS_PER_BREAK) break;
            BlockState blockstate = this.level().getBlockState(pos);
            FluidState fluidState = this.level().getFluidState(pos);
            if (blockstate.getBlock() instanceof AirBlock
                    || !blockstate.canEntityDestroy(this.level(), pos, this)
                    || !fluidState.isEmpty() || blockstate.is(Blocks.BEDROCK)
                    || blockstate.getDestroySpeed(this.level(), pos) < 0
                    || !ForgeEventFactory.onEntityDestroyBlock(this, pos, blockstate)) {
                continue;
            }
            if (this.random.nextFloat() > BLOCK_BREAK_CHANCE) continue;

            if (this.random.nextInt(5) == 0 && !blockstate.hasBlockEntity()) {
                FireEntity fallingBlockEntity = new FireEntity(EntityInit.FIREENTITY.get(), this.level());
                fallingBlockEntity.setBlock(Blocks.BLACKSTONE.defaultBlockState());
                flag = this.level().destroyBlock(pos, false, this) || flag;
                fallingBlockEntity.setDeltaMovement(fallingBlockEntity.getDeltaMovement().add(
                        this.position().subtract(fallingBlockEntity.position()).multiply(
                                (-1.2D + this.random.nextDouble()) / 3.0D,
                                0.2D + this.getRandom().nextGaussian() * 0.15D,
                                (-1.2D + this.random.nextDouble()) / 3.0D)));
                this.level().addFreshEntity(fallingBlockEntity);
            } else {
                flag = this.level().destroyBlock(pos, false, this) || flag;
                this.setDeltaMovement(this.getDeltaMovement().multiply(0.6000000238418579D, 1.0D, 0.6000000238418579D));
            }
            ++broken;
        }

        if (flag) {
            this.blockBreakCounter = 10;
            this.level().levelEvent((Player) null, 1022, this.blockPosition(), 0);
            this.blockBreakCooldown = BLOCK_BREAK_COOLDOWN_TICKS;
        }
    }

    // === FIX 1: destroyBlock 从 3×3×4=36 格 → 脚下 3×3×1 最多 3 格 ===
    private void destroyBlock() {
        if (this.level().isClientSide || this.destroyBlocksTick <= 0) return;
        --this.destroyBlocksTick;
        if (this.destroyBlocksTick != 0) return;
        if (this.blockBreakCooldown > 0 || this.isStunned()
                || !ForgeEventFactory.getMobGriefingEvent(this.level(), this)) return;

        int cx = Mth.floor(this.getX());
        int cy = Mth.floor(this.getY());
        int cz = Mth.floor(this.getZ());
        int broken = 0;
        boolean flag = false;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (broken >= 3) break;
                BlockPos pos = new BlockPos(cx + dx, cy - 1, cz + dz);
                BlockState blockstate = this.level().getBlockState(pos);
                if (blockstate.getBlock() instanceof AirBlock || blockstate.is(Blocks.BEDROCK)
                        || blockstate.hasBlockEntity()
                        || blockstate.getDestroySpeed(this.level(), pos) < 0
                        || !blockstate.canEntityDestroy(this.level(), pos, this)
                        || !ForgeEventFactory.onEntityDestroyBlock(this, pos, blockstate)) {
                    continue;
                }
                if (this.random.nextFloat() > BLOCK_BREAK_CHANCE) continue;

                if (this.random.nextInt(5) == 0) {
                    FireEntity fallingBlockEntity = new FireEntity(EntityInit.FIREENTITY.get(), this.level());
                    fallingBlockEntity.setBlock(Blocks.LAVA.defaultBlockState());
                    flag = this.level().destroyBlock(pos, false, this) || flag;
                    fallingBlockEntity.setDeltaMovement(fallingBlockEntity.getDeltaMovement().add(
                            this.position().subtract(fallingBlockEntity.position()).multiply(
                                    (-1.2D + this.random.nextDouble()) / 3.0D,
                                    0.2D + this.getRandom().nextGaussian() * 0.15D,
                                    (-1.2D + this.random.nextDouble()) / 3.0D)));
                    this.level().addFreshEntity(fallingBlockEntity);
                } else {
                    flag = this.level().destroyBlock(pos, false, this) || flag;
                }
                ++broken;
            }
        }

        if (flag) {
            this.level().levelEvent((Player) null, 1022, this.blockPosition(), 0);
            this.blockBreakCooldown = BLOCK_BREAK_COOLDOWN_TICKS;
        }
    }

    protected void customServerAiStep() {
        this.fallDistance = 0;

        // === FIX 3: 硬直期间完全不跑 AI ===
        if (this.isStunned()) {
            this.setStunTicks(this.getStunTicks() - 1);
            this.getNavigation().stop();
            this.setDeltaMovement(this.getDeltaMovement().multiply(0.5, 0.5, 0.5));
            this.setAttackingState(0);
            this.setIsCharge(false);
            return;
        }

        if (this.getIsAct()) {
            if (this.deactivateProgress > 0.0F) {
                float k1 = this.deactivateProgress - 1.0F;
                if (k1 <= 0.0F && !this.isSilent()) {
                    this.level().globalLevelEvent(1023, this.blockPosition(), 0);
                }
            } else {
                super.customServerAiStep();

                for (int i = 1; i < 3; ++i) {
                    if (this.tickCount >= this.nextHeadUpdate[i - 1]) {
                        this.nextHeadUpdate[i - 1] = this.tickCount + 10 + this.random.nextInt(10);
                        int l1 = this.getAlternativeTarget(i);
                        if (l1 <= 0) {
                            List<LivingEntity> list = this.level().getNearbyEntities(LivingEntity.class, TARGETING_CONDITIONS, this,
                                    this.getBoundingBox().inflate(20.0D, 8.0D, 20.0D));
                            if (!list.isEmpty()) {
                                LivingEntity livingentity1 = list.get(this.random.nextInt(list.size()));
                                this.setAlternativeTarget(i, livingentity1.getId());
                            }
                        } else {
                            LivingEntity livingentity = (LivingEntity) this.level().getEntity(l1);
                            if (livingentity != null && this.canAttack(livingentity) && this.distanceToSqr(livingentity) <= 1600.0D
                                    && this.hasLineOfSight(livingentity)
                                    && (this.Laser_Mode_Progress == 30.0F || this.Laser_Mode_Progress == 0.0F)
                                    && this.getAttckingState() == 1) {
                                this.performRangedAttack(i + 1, livingentity);
                                int f = this.getTarget() == null ? 15 + this.random.nextInt(5) : 30 + this.random.nextInt(20);
                                this.nextHeadUpdate[i - 1] = this.tickCount + f;
                                this.idleHeadUpdates[i - 1] = 0;
                            } else {
                                this.setAlternativeTarget(i, 0);
                            }
                        }
                    }
                }

                this.blockbreak();
                this.destroyBlock();
                if (this.getTarget() != null) {
                    this.destoryblock2();
                }

                if (this.mode_change_cooldown < 300) {
                    ++this.mode_change_cooldown;
                }

                if (this.getTarget() != null) {
                    this.setAlternativeTarget(0, this.getTarget().getId());
                } else {
                    this.setAlternativeTarget(0, 0);
                }

                if (this.tickCount % 20 == 0) {
                    this.heal(1.0F);
                }
            }
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        int co = this.random.nextInt(3);
        if (co == 0) return SoundInit.ENTITY_SALAZAR_AMBIENT1.get();
        if (co == 1) return SoundInit.ENTITY_SALAZAR_AMBIENT2.get();
        return SoundInit.ENTITY_SALAZAR_AMBIENT3.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return this.random.nextInt(2) == 0 ? SoundEvents.RAVAGER_HURT : SoundEvents.SLIME_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return this.random.nextInt(2) == 1 ? SoundInit.ENTITY_MOREAU_DEATH.get() : SoundInit.ENTITY_SALAZAR_AMBIENT3.get();
    }

    // ===== 头部位置计算 =====
    private double getHeadX(int head) {
        if (head <= 0) return this.getX();
        float f = (this.yBodyRot + (float) (180 * (head - 1))) * 0.017453292F;
        double f2 = this.getTarget() == null ? 1.65D : 1.5D;
        return this.getX() + (double) Mth.cos(f) * f2;
    }

    private double getHeadY(int head) {
        return head <= 0 ? this.getY() + 3.0D : this.getY() + 2.6D;
    }

    private double getHeadZ(int head) {
        if (head <= 0) return this.getZ();
        float f = (this.yBodyRot + (float) (180 * (head - 1))) * 0.017453292F;
        double f2 = this.getTarget() == null ? 1.65D : 1.5D;
        return this.getZ() + (double) Mth.sin(f) * f2;
    }

    private float m_31442_(float p_31443_, float p_31444_, float p_31445_) {
        float f = Mth.wrapDegrees(p_31444_ - p_31443_);
        if (f > p_31445_) f = p_31445_;
        if (f < -p_31445_) f = -p_31445_;
        return p_31443_ + f;
    }

    private void performRangedAttack(int head, LivingEntity target) {
        this.performRangedAttack(head, target.getX(), target.getY() + (double) target.getRandomY() * 0.5D, target.getZ(), target);
    }

    private void performRangedAttack(int head, double targetX, double targetY, double targetZ, LivingEntity target) {
        double d0 = this.getHeadX(head);
        double d1 = this.getHeadY(head);
        double d2 = this.getHeadZ(head);
        double d3 = targetX - d0;
        double d4 = targetY - d1;
        double d5 = targetZ - d2;
        if (this.getTarget() != null && this.getAttckingState() == 2) {
            DetonatorEntity laserBeam = new DetonatorEntity(this.level(), this);
            laserBeam.shoot(d3, d4, d5, 1.0F, 1.0F);
            laserBeam.setPosRaw(d0, d1, d2);
            this.level().addFreshEntity(laserBeam);
        } else {
            if (!this.isSilent()) {
                this.level().levelEvent((Player) null, 1024, this.blockPosition(), 0);
            }
        }
    }

    public int getAlternativeTarget(int head) { return 0; }
    public void setAlternativeTarget(int targetOffset, int newId) { }

    public boolean getIsAct() { return this.getAttckingState() == 1; }

    public void setIsCharge(boolean isCharge) { this.entityData.set(ISCHARGE, isCharge); }
    public boolean getIsCharge() { return (Boolean) this.entityData.get(ISCHARGE); }

    public boolean m_7090_() { return this.getHealth() <= this.getMaxHealth() / 2.0F; }

    public boolean canBePushedByEntity(Entity entity) { return false; }
    public boolean canChangeDimensions() { return false; }

    public boolean canBeAffected(MobEffectInstance p_31495_) {
        return p_31495_.getEffect() != MobEffects.MOVEMENT_SLOWDOWN
                && p_31495_.getEffect() != MobEffects.POISON
                && p_31495_.getEffect() != EffectInit.BURN.get()
                && p_31495_.getEffect() != MobEffects.WITHER
                && p_31495_.getEffect() != EffectInit.PLAGAS.get()
                && super.canBeAffected(p_31495_);
    }

    @Override
    public void performRangedAttack(LivingEntity p_31468_, float p_31469_) {
        this.performRangedAttack(0, p_31468_);
    }

    // ===== 攻击 Goal =====
    static class AttackGoal extends Goal {
        private final EntitySalaz parentEntity;
        protected int attackTimer = 0;

        public AttackGoal(EntitySalaz ghast) {
            this.parentEntity = ghast;
        }

        public boolean canUse() {
            // === FIX 3: 硬直时不能攻击 ===
            return this.parentEntity.getTarget() != null
                    && !this.parentEntity.isStunned()
                    && this.parentEntity.skill_cooldown <= 0;
        }

        public void start() {
            super.start();
            this.parentEntity.setAggressive(true);
        }

        @Override
        public void stop() {
            super.stop();
            this.parentEntity.setAggressive(false);
            this.parentEntity.setAttackingState(0);
            this.attackTimer = -1;
        }

        public void tick() {
            // === FIX 3: 硬直时冻结攻击计时 ===
            if (this.parentEntity.isStunned()) return;

            LivingEntity livingentity = this.parentEntity.getTarget();
            if (livingentity != null && this.parentEntity.hasLineOfSight(livingentity)) {
                ++this.attackTimer;
                Random rand = new Random();
                Vec3 vector3d = this.parentEntity.getViewVector(1.0F);

                if (this.attackTimer == 5) {
                    if ((this.parentEntity.getHealth() < this.parentEntity.getMaxHealth() && this.parentEntity.getHealth() > this.parentEntity.getMaxHealth() * 0.9)
                            || (this.parentEntity.getHealth() < this.parentEntity.getMaxHealth() * 0.5 && this.parentEntity.getHealth() > this.parentEntity.getMaxHealth() * 0.65)
                            || (this.parentEntity.getHealth() < this.parentEntity.getMaxHealth() * 0.35 && this.parentEntity.getHealth() > this.parentEntity.getMaxHealth() * 0.3)) {
                        this.parentEntity.setAttackingState(1);
                        this.parentEntity.setIsCharge(true);
                        this.parentEntity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 40, 0));
                    } else if (this.parentEntity.getHealth() < this.parentEntity.getMaxHealth() * 0.15
                            || (this.parentEntity.getHealth() < this.parentEntity.getMaxHealth() * 0.5 && this.parentEntity.getHealth() > this.parentEntity.getMaxHealth() * 0.35)
                            || (this.parentEntity.getHealth() < this.parentEntity.getMaxHealth() * 0.8 && this.parentEntity.getHealth() > this.parentEntity.getMaxHealth() * 0.65)) {
                        this.parentEntity.setAttackingState(2);
                    } else {
                        this.parentEntity.setAttackingState(3);
                    }
                }

                if (this.parentEntity.getAttckingState() == 1) {
                    if (this.attackTimer == 16) {
                        this.parentEntity.getNavigation().moveTo(livingentity, 1.5D);
                        this.parentEntity.lookAt(livingentity, 30.0F, 30.0F);
                        this.parentEntity.getLookControl().setLookAt(livingentity, 30.0F, 30.0F);
                    }

                    if (this.attackTimer == 24) {
                        this.parentEntity.getNavigation().moveTo(livingentity, 1.5D);
                        Vec3 rot = livingentity.position().subtract(0.0D, 2.0D, 0.0D)
                                .add(this.parentEntity.position().multiply(-1.0D, -1.0D, -1.0D)).normalize();
                        this.parentEntity.setDeltaMovement(rot.multiply(4.0D, 5.0D, 4.0D));

                        for (LivingEntity lvt : this.parentEntity.level().getEntitiesOfClass(LivingEntity.class,
                                this.parentEntity.getBoundingBox().inflate(6.0D), LIVING_ENTITY_SELECTOR)) {
                            lvt.hurt(lvt.damageSources().mobAttack(this.parentEntity),
                                    lvt.getMaxHealth() * 0.1F + lvt.getArmorValue());
                        }
                    }
                }

                if (this.parentEntity.getAttckingState() == 2) {
                    if (this.attackTimer == 18 && !this.parentEntity.level().isClientSide) {
                        this.parentEntity.getNavigation().moveTo(
                                livingentity.getX() + this.parentEntity.random.nextInt(4),
                                livingentity.getY() + this.parentEntity.random.nextInt(4),
                                livingentity.getZ() + this.parentEntity.random.nextInt(4), 0.9D);

                        Level level = this.parentEntity.level();
                        Vec3 c = livingentity.position(); // 锁定目标当前的位置

                        // 1. 目标脚下中心尖刺（延迟 0 刺出）
                        Vec3 p0 = EntityMyceliumSpike.ground(level, c.x, c.y, c.z);
                        EntityMyceliumSpike.rise(level, this.parentEntity, p0, 8.0F, 0);

                        // 2. 周围生成一圈“十字形”的尖刺矩阵，错峰刺出给玩家逃跑反应时间
                        int n = 4;
                        for (int i = 0; i < n; i++) {
                            double a = Math.PI * 2 * i / n;
                            // 第一圈（半径 2.0）
                            double x1 = c.x + Math.cos(a) * 2.0;
                            double z1 = c.z + Math.sin(a) * 2.0;
                            Vec3 p1 = EntityMyceliumSpike.ground(level, x1, c.y, z1);
                            EntityMyceliumSpike.rise(level, this.parentEntity, p1, 6.0F, 4 + i * 2);

                            // 第二圈（半径 4.0）
                            double x2 = c.x + Math.cos(a) * 4.0;
                            double z2 = c.z + Math.sin(a) * 4.0;
                            Vec3 p2 = EntityMyceliumSpike.ground(level, x2, c.y, z2);
                            EntityMyceliumSpike.rise(level, this.parentEntity, p2, 5.0F, 8 + i * 3);
                        }
                    }

                    if (this.attackTimer == 45) {
                        this.parentEntity.getLookControl().setLookAt(
                                livingentity.getX(), livingentity.getY() + (double) (livingentity.getBbHeight() / 2.0F),
                                livingentity.getZ(), 6.0F, 90.0F);
                        this.parentEntity.lookAt(livingentity, 30.0F, 30.0F);
                        this.parentEntity.destoryblock2();
                    }

                    if (this.attackTimer == 65) {
                        // === FIX 2: 循环步长从 1 改 2，减半 AABB 查询 ===
                        for (int l = 1; l < 10; l += 2) {
                            this.parentEntity.blockSmashAttack(l, 3F, 1.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, -1.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, 2.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, -2.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, 3.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, -3.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, 4.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, -4.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, 5.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, -5.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, 6.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, -6.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, 7.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, -7.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, 8.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, -8.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, 9.5F, 150, 1.5F, 0.15F, 1.0F);
                            this.parentEntity.blockSmashAttack(l, 3F, -9.5F, 150, 1.5F, 0.15F, 1.0F);
                        }
                        EntityCameraShake.ScreenShake(this.parentEntity.level(),
                                new Vec3(this.parentEntity.getX(), this.parentEntity.getY(), this.parentEntity.getZ()),
                                30.0f, 0.15f, 0, 50);
                        for (LivingEntity lvt : this.parentEntity.level().getEntitiesOfClass(LivingEntity.class,
                                this.parentEntity.getBoundingBox().inflate(1.1D), LIVING_ENTITY_SELECTOR)) {
                            double d00 = lvt.getX() - this.parentEntity.getX();
                            double d10 = lvt.getZ() - this.parentEntity.getZ();
                            double d20 = Math.max(d00 * d00 + d10 * d10, 0.001D);
                            lvt.getDeltaMovement().add(d00 * 0.2D, d20 + rand.nextDouble(), d10 * 0.2D);
                        }
                    }
                }

                if (this.parentEntity.getAttckingState() == 3) {
                    if (this.attackTimer == 18 || this.attackTimer == 24 || this.attackTimer == 28) {
                        this.mlaunch(2, livingentity);
                    }
                    if (this.attackTimer == 28 || this.attackTimer == 32 || this.attackTimer == 36) {
                        this.mlaunch(1, livingentity);
                    }
                    if (this.attackTimer == 45) {
                        for (LivingEntity lvt : this.parentEntity.level().getEntitiesOfClass(LivingEntity.class,
                                this.parentEntity.getBoundingBox().inflate(6.0D), LIVING_ENTITY_SELECTOR)) {
                            lvt.hurt(lvt.damageSources().mobAttack(this.parentEntity), lvt.getMaxHealth() * 0.3F);
                        }
                    }
                }

                // === FIX 2: 技能后冷却从 -5 改 -SKILL_COOLDOWN_AFTER_ATTACK ===
                if (this.attackTimer == 90) {
                    this.parentEntity.setAttackingState(0);
                    this.parentEntity.setIsCharge(false);
                    this.parentEntity.skill_cooldown = SKILL_COOLDOWN_TICKS;
                    this.attackTimer = -SKILL_COOLDOWN_AFTER_ATTACK;
                }
                this.parentEntity.lookAt(livingentity, 30.0F, 30.0F);

            } else if (this.attackTimer > 0) {
                --this.attackTimer;
            }
        }

        private void mlaunch(int head, LivingEntity target) {
            if (!this.parentEntity.isSilent()) {
                this.parentEntity.level().levelEvent((Player) null, 1024, this.parentEntity.blockPosition(), 0);
            }
            Level level = this.parentEntity.level();
            // 在目标脚下及周围随机生成尖刺
            for (int i = 0; i < 2; i++) {
                double x = target.getX() + (this.parentEntity.random.nextDouble() - 0.5) * 6.0;
                double z = target.getZ() + (this.parentEntity.random.nextDouble() - 0.5) * 6.0;
                Vec3 p = EntityMyceliumSpike.ground(level, x, target.getY(), z);
                EntityMyceliumSpike.rise(level, this.parentEntity, p, 6.0F, 5 + i * 4);
            }
        }

        private double getLauncherX(int head) {
            if (head <= 0) return this.parentEntity.getX();
            double theta = (double) this.parentEntity.yBodyRot * 0.017453292519943295D;
            ++theta;
            double vecX = Math.cos(theta);
            float f = (this.parentEntity.yBodyRot + (float) (180 * (head - 1))) * 0.017453292F;
            return this.parentEntity.getX() + (double) Mth.cos(f) * 1.25D + vecX * 1.35D;
        }

        private double getLauncherY(int head) {
            return head <= 0 ? this.parentEntity.getY() + 3.0D : this.parentEntity.getY() + 3.8D;
        }

        private double getLauncherZ(int head) {
            if (head <= 0) return this.parentEntity.getZ();
            double theta = (double) this.parentEntity.yBodyRot * 0.017453292519943295D;
            ++theta;
            double vecZ = Math.sin(theta);
            float f = (this.parentEntity.yBodyRot + (float) (180 * (head - 1))) * 0.017453292F;
            return this.parentEntity.getZ() + (double) Mth.sin(f) * 1.25D + vecZ * 1.35D;
        }
    }

    public int getAttckingState() { return this.entityData.get(STATE); }
    public void setAttackingState(int time) { this.entityData.set(STATE, time); }

    private <E extends GeoAnimatable> PlayState predicate(AnimationState<E> event) {
        if (event.isMoving()) {
            event.setAndContinue(RawAnimation.begin().thenPlay("animation.sala.walk"));
            return PlayState.CONTINUE;
        }
        event.setAndContinue(RawAnimation.begin().thenPlay("animation.sala.idle"));
        return PlayState.CONTINUE;
    }

    private <E extends GeoAnimatable> PlayState predicate1(AnimationState<E> event) {
        // === FIX 3: 硬直动画（没有资源就注释掉，用 idle 顶替） ===
        // if (this.isStunned()) {
        //     event.setAndContinue(RawAnimation.begin().thenPlay("animation.sala.stun"));
        //     return PlayState.CONTINUE;
        // }
        if (this.entityData.get(STATE) == 1 && !(this.dead || this.getHealth() < 0.01 || this.isDeadOrDying())) {
            event.setAndContinue(RawAnimation.begin().thenPlay("animation.sala.attack"));
            return PlayState.CONTINUE;
        }
        if (this.entityData.get(STATE) == 2 && !(this.dead || this.getHealth() < 0.01 || this.isDeadOrDying())) {
            event.setAndContinue(RawAnimation.begin().thenPlay("animation.sala.aoe"));
            return PlayState.CONTINUE;
        }
        if (this.entityData.get(STATE) == 3 && !(this.dead || this.getHealth() < 0.01 || this.isDeadOrDying())) {
            event.setAndContinue(RawAnimation.begin().thenPlay("animation.sala.idle"));
            return PlayState.CONTINUE;
        }
        return PlayState.CONTINUE;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar data) {
        data.add(new AnimationController(this, "controller", 0, this::predicate));
        data.add(new AnimationController(this, "controller1", 0, this::predicate1));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return this.factory; }

    private void blockSmashAttack(int distance, float mxy, float math, int shieldbreakticks,
                                  float damage, float hpdamage, float airborne) {
        double minY = this.getY() - 2.0;
        double maxY = this.getY() + (double) mxy;
        float angle = (float) Math.PI / 180 * this.yBodyRot;
        float f = Mth.cos((float) (this.getYRot() * ((float) Math.PI / 180)));
        float f1 = Mth.sin((float) (this.getYRot() * ((float) Math.PI / 180)));
        double extraX = (float) distance * Mth.sin((float) ((float) (Math.PI + (double) angle)));
        double extraZ = (float) distance * Mth.cos((float) angle);
        double px = this.getX() + extraX + (double) (f * math);
        double pz = this.getZ() + extraZ + (double) (f1 * math);

        AABB selection = new AABB(px - 1, minY, pz - 1, px + 1, maxY, pz + 1);
        List<LivingEntity> hit = this.level().getEntitiesOfClass(LivingEntity.class, selection);
        for (LivingEntity entity : hit) {
            if (this.isAlliedTo(entity) || entity instanceof EntityHeisen || entity == this) continue;
            if (entity instanceof Player && ((Player) entity).getUseItem().canPerformAction(ToolActions.SHIELD_BLOCK) && shieldbreakticks > 0) {
                disableShield(entity, shieldbreakticks);
            } else {
                boolean flag = entity.hurt(damageSources().mobAttack(this),
                        (float) (this.getAttributeValue(Attributes.ATTACK_DAMAGE) * (double) damage
                                + (double) (entity.getMaxHealth() * hpdamage)));
                if (flag)
                    entity.setDeltaMovement(entity.getDeltaMovement().add(0.0, airborne, 0.0));
            }
        }
    }

    public static void disableShield(LivingEntity livingEntity, int ticks) {
        ((Player) livingEntity).getCooldowns().addCooldown(livingEntity.getUseItem().getItem(), ticks);
        livingEntity.getUseItem().hurtAndBreak(4 + livingEntity.getRandom().nextInt(2), livingEntity,
                (p_220009_1_) -> p_220009_1_.broadcastBreakEvent(livingEntity.getUsedItemHand()));
        livingEntity.stopUsingItem();
        livingEntity.level().broadcastEntityEvent(livingEntity, (byte) 30);
    }
}