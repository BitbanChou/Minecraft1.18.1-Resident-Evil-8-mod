package com.joy187.re8joymod.entity.render;

import com.joy187.re8joymod.Main;
import com.joy187.re8joymod.entity.EntityPesanta;
import com.joy187.re8joymod.entity.model.ModelPesanta;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class RenderPesanta extends GeoEntityRenderer<EntityPesanta> {

    public RenderPesanta(EntityRendererProvider.Context renderManager) {
        super(renderManager, new ModelPesanta());
        this.shadowRadius = 0.7f;
        // 如果需要，可以在这里加发光图层 (addLayer)
    }

    @Override
    public ResourceLocation getTextureLocation(EntityPesanta instance) {
        // 确保你的贴图文件在 assets/re8joymod/textures/entity/pesanta.png
        return new ResourceLocation(Main.MOD_ID, "textures/entity/verdugo.png");
    }

    @Override
    public void render(EntityPesanta animatable, float entityYaw, float partialTick, PoseStack stack, MultiBufferSource bufferSource, int packedLight) {
        // 如果模型大小不合适，可以在这里调整缩放，比如 stack.scale(1.2F, 1.2F, 1.2F);
        stack.scale(1F, 1F, 1F);

        this.animatable = animatable;
        defaultRender(stack, animatable, bufferSource, null, null, entityYaw, partialTick, packedLight);
    }
}