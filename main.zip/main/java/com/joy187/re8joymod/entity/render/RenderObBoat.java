//package com.joy187.re8joymod.entity.render;
//
//import java.util.Map;
//import java.util.stream.Stream;
//
//import com.google.common.collect.ImmutableMap;
//import com.joy187.re8joymod.Main;
//import com.joy187.re8joymod.entity.EntityObBoat;
//import com.joy187.re8joymod.entity.model.ModelObBoat;
//import com.mojang.datafixers.util.Pair;
//
//import net.minecraft.client.model.BoatModel;
//import net.minecraft.client.model.ListModel;
//import net.minecraft.client.model.geom.ModelLayerLocation;
//import net.minecraft.client.renderer.entity.BoatRenderer;
//import net.minecraft.client.renderer.entity.EntityRendererProvider;
//import net.minecraft.resources.ResourceLocation;
//import net.minecraft.world.entity.vehicle.Boat;
//import net.minecraftforge.api.distmarker.Dist;
//import net.minecraftforge.api.distmarker.OnlyIn;
//
//@OnlyIn(Dist.CLIENT)
//public class RenderObBoat extends BoatRenderer {
//
//    private final Map<EntityObBoat.Type, Pair<ResourceLocation, ListModel<Boat>>> boatResources;
//
//    public RenderObBoat(EntityRendererProvider.Context context, boolean chestBoat) {
//        super(context, chestBoat);
//
//        this.boatResources = Stream.of(EntityObBoat.Type.values())
//                .collect(ImmutableMap.toImmutableMap(
//                        type -> type,
//                        type -> Pair.of(
//                                new ResourceLocation(Main.MOD_ID, getTexturePath(type, chestBoat)),
//                                this.createBoatModel(context, type, chestBoat)
//                        )
//                ));
//    }
//
//    private static String getTexturePath(EntityObBoat.Type type, boolean chestBoat) {
//        return chestBoat
//                ? "textures/entity/chest_boat/obboat1.png"
//                : "textures/entity/boat/obboat1.png";
//    }
//
//    /**
//     * 用你自己的模型层（ModelObBoat.LAYER_LOCATION）创建模型。
//     * 如果你还没有 ModelObBoat，就先用原版 OAK 的模型层：
//     *   ModelLayers.createBoatModelName(Boat.Type.OAK)
//     */
//    private ListModel<Boat> createBoatModel(EntityRendererProvider.Context context,
//                                            EntityObBoat.Type type,
//                                            boolean chestBoat) {
//        ModelLayerLocation layer = chestBoat
//                ? ModelObBoat.LAYER_LOCATION_CHEST   // 若你定义了 chest 版本
//                : ModelObBoat.LAYER_LOCATION;
//        return new BoatModel(context.bakeLayer(layer));
//    }
//
//    @Override
//    public Pair<ResourceLocation, ListModel<Boat>> getModelWithLocation(Boat boat) {
//        if (boat instanceof EntityObBoat modBoat) {
//            return this.boatResources.get(modBoat.getModVariant());
//        }
//        return super.getModelWithLocation(boat);
//    }
//}