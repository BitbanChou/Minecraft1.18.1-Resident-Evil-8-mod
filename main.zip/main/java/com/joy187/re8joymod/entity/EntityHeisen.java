package com.joy187.re8joymod.entity;

import java.util.List;
import java.util.Random;
import java.util.function.Predicate;

import javax.annotation.Nullable;

import com.joy187.re8joymod.init.BlockInit;
import com.joy187.re8joymod.init.EntityInit;
import com.joy187.re8joymod.init.ParticleInit;
import com.joy187.re8joymod.init.SoundInit;
import com.joy187.re8joymod.util.CommonFunctions;
import com.mojang.blaze3d.vertex.PoseStack.Pose;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreakDoorGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ToolActions;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;

public class EntityHeisen extends Ravager implements GeoEntity {

    private final AnimatableInstanceCache factory = GeckoLibUtil.createInstanceCache(this);

    // ===== 动画名 =====
    private static final String ANIM_WALK = "animation.heisen.walk";
    private static final String ANIM_IDLE = "animation.heisen.idle";
    private static final String ANIM_ATK1 = "animation.heisen.attack";
    private static final String ANIM_ATK2 = "animation.heisen.attack2";
    private static final String ANIM_ATK3 = "animation.heisen.attack3";
    private static final String ANIM_HURT = "animation.heisen.hurt";

    // ===== 基础 =====
    private final ServerBossEvent bossInfo = (ServerBossEvent) (new ServerBossEvent(
            this.getDisplayName(), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS)).setDarkenScreen(true);
    public static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(EntityHeisen.class, EntityDataSerializers.INT);
    public static final EntityDataAccessor<Integer> DEFENDSTATE = SynchedEntityData.defineId(EntityHeisen.class, EntityDataSerializers.INT);
    private static final Predicate<Difficulty> DOOR_BREAKING_PREDICATE = (mode) -> mode == Difficulty.HARD || mode == Difficulty.NORMAL;
    private final BreakDoorGoal breakDoorGoal = new BreakDoorGoal(this, DOOR_BREAKING_PREDICATE);

    // ===== 硬直 =====
    private static final int STUN_TICKS = 20;
    private int stunTicks = 0;

    // ===== 出招计数 → 强制硬直 =====
    private int attacksSinceStun = 0;
    private int nextStunThreshold = 3;

    // ===== 磁场/悬浮 =====
    private static final double BASE_SPEED = 0.29D;
    private static final double MAGNET_SPEED = 0.18D;
    private static final double MAGNET_RADIUS = 6.0D;
    private static final double MAGNET_STRENGTH = 0.35D;
    private static final double MAGNET_AIR_HEIGHT = 2.0D;

    // 包内可见，供 AttackGoal 访问
    boolean magnetAirborne = false;
    double magnetBaseY = -1;

    // ===== 雷击 =====
    private static final float LIGHTNING_SPLASH_DAMAGE = 6.0F;

    public EntityHeisen(EntityType<? extends Ravager> type, Level worldIn) {
        super(type, worldIn);
        this.isNonBoss();
        this.xpReward = 350;
    }

    // ==================== Goals ====================

    protected void registerGoals() {
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, IronGolem.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.addBehaviourGoals();
    }

    protected void addBehaviourGoals() {
        this.goalSelector.addGoal(1, new AttackGoal(this));
        this.goalSelector.addGoal(2, new HeisenAttackGoal(this, 1.0D, false));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 1.0D) {
            @Override
            public boolean canUse() {
                return EntityHeisen.this.getAttckingState() == 0
                        && EntityHeisen.this.getStunTicks() <= 0
                        && !EntityHeisen.this.isMagnetAirborne()
                        && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return EntityHeisen.this.getAttckingState() == 0
                        && EntityHeisen.this.getStunTicks() <= 0
                        && !EntityHeisen.this.isMagnetAirborne()
                        && super.canContinueToUse();
            }
        });
        this.targetSelector.addGoal(1, (new HurtByTargetGoal(this)).setAlertOthers(ZombifiedPiglin.class));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractVillager.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
    }

    public static AttributeSupplier.Builder prepareAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 200.0D).
                add(Attributes.MOVEMENT_SPEED, BASE_SPEED).
                add(Attributes.FOLLOW_RANGE, 48.0D).
                add(Attributes.ARMOR, 20.0D).
                add(Attributes.ARMOR_TOUGHNESS, 15.0D).
                add(Attributes.KNOCKBACK_RESISTANCE, 1.0D).
                add(Attributes.ATTACK_DAMAGE, 9.0D);
    }

    // ==================== 状态存取 ====================

    public int getAttckingState() {
        return this.entityData.get(STATE);
    }

    /**
     * 设置攻击状态并触发对应的一次性动画（triggerableAnim）。
     * STATE 只用于逻辑判断，动画由 triggerAnim 一次性播放，播完自然停。
     */
    public void setAttackingState(int time) {
        int prev = this.entityData.get(STATE);
        this.entityData.set(STATE, time);
        if (time != prev) {
            if (time == 1) {
                this.triggerAnim("controller1", "slash");
            } else if (time == 2) {
                this.triggerAnim("controller1", "heavy");
            } else if (time == 3) {
                this.triggerAnim("controller1", "charge");
            }
        }
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(STATE, 0);
        this.entityData.define(DEFENDSTATE, 0);
    }

    public int getDefendingState() {
        return this.entityData.get(DEFENDSTATE);
    }

    public void setDefendingState(int time) {
        this.entityData.set(DEFENDSTATE, time);
    }

    public int getStunTicks() {
        return this.stunTicks;
    }

    public boolean isMagnetAirborne() {
        return this.magnetAirborne;
    }

    public double getMagnetBaseY() {
        return this.magnetBaseY;
    }

    void setMagnetAirborne(boolean airborne, double baseY) {
        this.magnetAirborne = airborne;
        this.magnetBaseY = airborne ? baseY : -1;
    }

    // ==================== 受击：概率硬直 ====================

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !this.level().isClientSide) {
            // 受击硬直概率 1/5，主要硬直来源是出招计数
            if (amount >= 4.0F && this.random.nextInt(3) == 0) {
                this.stunTicks = Math.max(this.stunTicks, STUN_TICKS);
                if (this.getAttckingState() != 0) {
                    this.setAttackingState(0);
                }
                this.triggerAnim("controller1", "hurt");
                this.forceLandIfAirborne();
            }
        }
        return hurt;
    }

    /** 出招 3~5 次后强制触发硬直，视觉/音效更明显。 */
    public void triggerForcedStun() {
        this.stunTicks = Math.max(this.stunTicks, STUN_TICKS);
        if (this.getAttckingState() != 0) {
            this.setAttackingState(0);
        }
        this.triggerAnim("controller1", "hurt");
        this.forceLandIfAirborne();
        this.removeEffect(MobEffects.LEVITATION);
        this.playSound(SoundEvents.ANVIL_LAND, 1.0F, 0.8F);
        if (this.level() instanceof ServerLevel server) {
            for (int i = 0; i < 10; i++) {
                double dx = (this.random.nextDouble() - 0.5) * 2.0;
                double dz = (this.random.nextDouble() - 0.5) * 2.0;
                server.sendParticles(ParticleTypes.CRIT,
                        this.getX() + dx, this.getY() + 1.0, this.getZ() + dz,
                        1, 0, 0, 0, 0.1);
            }
        }
    }

    protected void customServerAiStep() {
        super.customServerAiStep();
        if (this.getHealth() >= 0.1F && this.getHealth() <= 7.0F) {
            this.convertTo(EntityInit.MUHEISEN.get(), true);
        }
        this.bossInfo.setProgress(this.getHealth() / this.getMaxHealth());
    }

    private void defend() {
        if (this.isAlive()) {
            Vec3 vec3 = this.getBoundingBox().getCenter();
            for (int j = 0; j < 3; j++) {
                for (int i = 0; i < 10; i++) {
                    float deltaOmega = 1.0f * i;
                    Vec3 pos = new Vec3(vec3.x + 1 * Math.sin(0 + deltaOmega), vec3.y + j, vec3.z + 1 * Math.cos(0 + deltaOmega));
                    this.level().addParticle(ParticleInit.DEFEND_PARTICLE.get(), pos.x, pos.y, pos.z, 0, 0, 0);
                }
            }
            this.level().gameEvent(this, GameEvent.ENTITY_ROAR, this.getEyePosition());
        }
    }

    public boolean isNonBoss() {
        return false;
    }

    public void startSeenByPlayer(ServerPlayer p_184178_1_) {
        super.startSeenByPlayer(p_184178_1_);
        this.bossInfo.addPlayer(p_184178_1_);
    }

    public void stopSeenByPlayer(ServerPlayer p_184203_1_) {
        super.stopSeenByPlayer(p_184203_1_);
        this.bossInfo.removePlayer(p_184203_1_);
    }

    @Override
    protected void updateControlFlags() {
        if (this.stunTicks > 0) {
            this.goalSelector.setControlFlag(Goal.Flag.MOVE, false);
            this.goalSelector.setControlFlag(Goal.Flag.JUMP, false);
            this.goalSelector.setControlFlag(Goal.Flag.LOOK, false);
            return;
        }
        boolean flag = this.getTarget() != null && this.hasLineOfSight(this.getTarget());
        this.goalSelector.setControlFlag(Goal.Flag.LOOK, flag);
        super.updateControlFlags();
    }

    // ==================== 动画控制器（triggerableAnim 版） ====================

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar data) {
        // controller1：一次性触发动画（slash/heavy/charge/hurt），默认 STOP
        data.add(new AnimationController<>(this, "controller1", 3, state -> PlayState.STOP)
                .triggerableAnim("slash", RawAnimation.begin().thenPlay(ANIM_ATK1))
                .triggerableAnim("heavy", RawAnimation.begin().thenPlay(ANIM_ATK2))
                .triggerableAnim("charge", RawAnimation.begin().thenPlay(ANIM_ATK3))
                .triggerableAnim("hurt", RawAnimation.begin().thenPlay(ANIM_HURT)));

        // controller：locomotion（walk/idle），攻击/硬直/悬浮时 STOP
        data.add(new AnimationController(this, "controller", 4, this::predicate));
    }

    private <E extends GeoAnimatable> PlayState predicate(AnimationState<E> event) {
        // 硬直、攻击、悬浮 → locomotion 停止，让 controller1 独占骨骼
        if (this.stunTicks > 0) return PlayState.STOP;
        if (this.getAttckingState() != 0) return PlayState.STOP;
        if (this.magnetAirborne) return PlayState.STOP;

        if (event.isMoving()) {
            event.setAndContinue(RawAnimation.begin().thenLoop(ANIM_WALK));
            return PlayState.CONTINUE;
        }
        event.setAndContinue(RawAnimation.begin().thenLoop(ANIM_IDLE));
        return PlayState.CONTINUE;
    }

    protected float getStandingEyeHeight(Pose p_213348_1_, EntityDimensions p_213348_2_) {
        return 1.5F;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.factory;
    }

    // ==================== tick / aiStep ====================

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;

        if (this.stunTicks > 0) {
            --this.stunTicks;
            this.getNavigation().stop();
            this.setSpeed(0.0F);
            Vec3 m = this.getDeltaMovement();
            this.setDeltaMovement(0.0D, m.y, 0.0D);
            if (this.getAttckingState() != 0) {
                this.setAttackingState(0);
            }
            // ★ 添加这行：硬直期间每 tick 散发灰烬/眩晕粒子
            CommonFunctions.spawnStunParticles(this);
            return;
        }
    }

    public void aiStep() {
        super.aiStep();

        if (this.entityData.get(DEFENDSTATE) == 1) {
            this.defend();
        }

        boolean magnet = this.getAttckingState() == 2;
        double target = magnet ? MAGNET_SPEED : BASE_SPEED;
        if (this.getAttribute(Attributes.MOVEMENT_SPEED).getBaseValue() != target) {
            this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(target);
        }
    }

    // ==================== 雷击 ====================

    public void strikeLightningOnTarget(@Nullable LivingEntity target, double radius) {
        if (this.level().isClientSide) return;
        if (target == null || !target.isAlive()) return;

        BlockPos pos = target.blockPosition();

        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(this.level());
        if (bolt != null) {
            bolt.moveTo(Vec3.atBottomCenterOf(pos));
            this.level().addFreshEntity(bolt);
        }

        for (LivingEntity living : this.level().getEntitiesOfClass(LivingEntity.class,
                new AABB(pos).inflate(radius), PIGEON_AREA)) {
            if (living == this || living == target) continue;
            if (this.isAlliedTo(living) || living instanceof EntityHeisen) continue;
            living.hurt(this.damageSources().mobAttack(this), LIGHTNING_SPLASH_DAMAGE + this.random.nextFloat() * 2.0F);
        }

        if (this.level() instanceof ServerLevel server) {
            for (int i = 0; i < 12; i++) {
                double dx = (this.random.nextDouble() - 0.5) * 2.0;
                double dz = (this.random.nextDouble() - 0.5) * 2.0;
                server.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                        pos.getX() + 0.5 + dx, pos.getY() + 0.5 + this.random.nextDouble(), pos.getZ() + 0.5 + dz,
                        1, 0, 0, 0, 0);
            }
        }
        this.playSound(SoundEvents.LIGHTNING_BOLT_THUNDER, 2.0F, 1.0F);
    }

    // ==================== 磁场吸引 ====================

    public void magnetPull(double radius, double strength) {
        if (this.level().isClientSide) return;

        AABB area = this.getBoundingBox().inflate(radius);
        for (LivingEntity living : this.level().getEntitiesOfClass(LivingEntity.class, area, PIGEON_AREA)) {
            if (living == this || living instanceof EntityHeisen) continue;
            if (this.isAlliedTo(living)) continue;

            if (living instanceof Player player && player.isBlocking()
                    && player.getUseItem().canPerformAction(ToolActions.SHIELD_BLOCK)) {
                if (this.random.nextInt(10) == 0) {
                    disableShield(player, 40);
                } else {
                    player.getUseItem().hurtAndBreak(1, player,
                            p -> p.broadcastBreakEvent(player.getUsedItemHand()));
                }
                continue;
            }

            Vec3 to = this.position().subtract(living.position());
            Vec3 flat = new Vec3(to.x, 0.0D, to.z);
            double dist = flat.length();
            if (dist < 0.5D) continue;
            Vec3 dir = flat.normalize().scale(strength);
            living.setDeltaMovement(living.getDeltaMovement().add(dir.x, 0.0D, dir.z));
            living.hurtMarked = true;

            if (this.level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                        living.getX(), living.getY() + 1.0D, living.getZ(),
                        2, 0.1, 0.1, 0.1, 0.02);
            }
        }

        if (this.level() instanceof ServerLevel server) {
            for (int i = 0; i < 6; i++) {
                double angle = this.random.nextDouble() * Math.PI * 2;
                double r = 1.5 + this.random.nextDouble() * 3.0;
                double px = this.getX() + Math.cos(angle) * r;
                double pz = this.getZ() + Math.sin(angle) * r;
                server.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                        px, this.getY() + 0.5 + this.random.nextDouble() * 1.5, pz,
                        1, 0, 0, 0, 0);
            }
        }
    }

    // ==================== 腾空 / 落地 ====================

    private void forceLandIfAirborne() {
        if (this.level().isClientSide) return;
        if (!this.magnetAirborne) return;
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos(this.getX(), this.getY(), this.getZ());
        while (mp.getY() > this.level().getMinBuildHeight() && !this.level().getBlockState(mp.below()).blocksMotion()) {
            mp.move(0, -1, 0);
        }
        this.landFromMagnet(mp.getY());
    }

    public void landFromMagnet(double baseY) {
        if (this.level().isClientSide) {
            this.setMagnetAirborne(false, -1);
            return;
        }
        double x = this.getX();
        double z = this.getZ();
        this.setMagnetAirborne(false, -1);
        this.removeEffect(MobEffects.LEVITATION);

        this.setPos(x, baseY, z);
        this.setDeltaMovement(0, -0.3, 0);
        if (!this.isCollidingWithSolid()) {
            return;
        }

        for (int r = 1; r <= 4; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.abs(dx) != r && Math.abs(dz) != r) continue;
                    double nx = x + dx;
                    double nz = z + dz;
                    for (int dy = 3; dy >= -3; dy--) {
                        double ny = baseY + dy;
                        this.setPos(nx, ny, nz);
                        if (!this.isCollidingWithSolid() && this.onGround()) {
                            this.setDeltaMovement(0, 0, 0);
                            return;
                        }
                    }
                }
            }
        }

        this.setPos(x, baseY, z);
        this.setDeltaMovement(0, -0.3, 0);
    }

    private boolean isCollidingWithSolid() {
        AABB box = this.getBoundingBox();
        for (BlockPos pos : BlockPos.betweenClosed(
                Mth.floor(box.minX), Mth.floor(box.minY), Mth.floor(box.minZ),
                Mth.floor(box.maxX), Mth.floor(box.maxY), Mth.floor(box.maxZ))) {
            BlockState state = this.level().getBlockState(pos);
            if (state.blocksMotion() && !state.getCollisionShape(this.level(), pos).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    // ==================== AttackGoal ====================

    static class AttackGoal extends Goal {
        private final EntityHeisen parentEntity;
        protected int attackTimer = 0;

        public AttackGoal(EntityHeisen mob) {
            this.parentEntity = mob;
        }

        public boolean canUse() {
            return this.parentEntity.getTarget() != null;
        }

        public void start() {
            super.start();
            this.parentEntity.setAggressive(true);
        }

        @Override
        public void stop() {
            super.stop();
            this.parentEntity.setAggressive(false);
            this.parentEntity.setAttackingState(0);
            this.attackTimer = -1;
            if (this.parentEntity.isMagnetAirborne()) {
                this.parentEntity.forceLandIfAirborne();
            }
        }

        public void tick() {
            if (this.parentEntity.getStunTicks() > 0) {
                this.parentEntity.setAttackingState(0);
                return;
            }

            LivingEntity livingentity = this.parentEntity.getTarget();
            if (livingentity != null && this.parentEntity.hasLineOfSight(livingentity)) {
                ++this.attackTimer;
                Random rand = new Random();
                float f = (float) Mth.atan2(livingentity.getZ() - parentEntity.getZ(),
                        livingentity.getX() - parentEntity.getX());

                int state = this.parentEntity.getAttckingState();

                if (this.attackTimer == 5) {
                    if ((parentEntity.getHealth() >= (parentEntity.getMaxHealth() * 0.80) && parentEntity.getHealth() <= (parentEntity.getMaxHealth() * 0.93))
                            || (parentEntity.getHealth() >= (parentEntity.getMaxHealth() * 0.62) && parentEntity.getHealth() <= (parentEntity.getMaxHealth() * 0.72))
                            || (parentEntity.getHealth() >= (parentEntity.getMaxHealth() * 0.35) && parentEntity.getHealth() <= (parentEntity.getMaxHealth() * 0.47))) {
                        this.parentEntity.setAttackingState(2);
                        this.parentEntity.getNavigation().stop();
                        double baseY = this.parentEntity.getY();
                        this.parentEntity.setMagnetAirborne(true, baseY);
                    } else if ((parentEntity.getHealth() <= (parentEntity.getMaxHealth() * 0.15D))
                            || (parentEntity.getHealth() >= (parentEntity.getMaxHealth() * 0.48) && parentEntity.getHealth() <= (parentEntity.getMaxHealth() * 0.6))
                            || (parentEntity.getHealth() >= (parentEntity.getMaxHealth() * 0.23) && parentEntity.getHealth() <= (parentEntity.getMaxHealth() * 0.32))) {
                        this.parentEntity.setAttackingState(1);
                        this.parentEntity.getNavigation().moveTo(livingentity, 1.2D);
                    } else {
                        this.parentEntity.setAttackingState(3);
                    }
                }

                state = this.parentEntity.getAttckingState();

                // ===== STATE 2：悬浮 + 吸怪 =====
                if (state == 2) {
                    this.parentEntity.getNavigation().stop();
                    if (this.parentEntity.getMagnetBaseY() >= 0) {
                        double targetY = this.parentEntity.getMagnetBaseY() + MAGNET_AIR_HEIGHT;
                        this.parentEntity.setPos(this.parentEntity.getX(), targetY, this.parentEntity.getZ());
                        this.parentEntity.setDeltaMovement(0, 0, 0);
                        this.parentEntity.hurtMarked = true;
                        if (!this.parentEntity.hasEffect(MobEffects.LEVITATION)) {
                            this.parentEntity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 60, 0, false, false, false));
                        }
                    }
                    this.parentEntity.magnetPull(MAGNET_RADIUS, MAGNET_STRENGTH);
                }

                // ===== STATE 3：持续吸引 + 绕圈 + 雷击 =====
                if (state == 3) {
                    this.parentEntity.getNavigation().stop();

                    if (this.attackTimer >= 5 && this.attackTimer <= 43) {
                        double progress = (this.attackTimer - 5) / 38.0D;
                        double strength = 0.15D + progress * 0.35D;
                        double radius = 6.0D + progress * 4.0D;
                        this.parentEntity.magnetPull(radius, strength);
                    }

                    if (this.attackTimer >= 5 && this.attackTimer <= 43) {
                        double angle = (this.attackTimer - 5) * 0.15D;
                        double radius = 3.0D;
                        double tx = this.parentEntity.getX() + Math.cos(angle) * radius;
                        double tz = this.parentEntity.getZ() + Math.sin(angle) * radius;
                        Vec3 dir = new Vec3(tx - this.parentEntity.getX(), 0, tz - this.parentEntity.getZ());
                        if (dir.lengthSqr() > 1e-4) {
                            Vec3 n = dir.normalize().scale(0.2D);
                            this.parentEntity.setDeltaMovement(n.x, this.parentEntity.getDeltaMovement().y, n.z);
                            this.parentEntity.hurtMarked = true;
                        }
                    }

                    if (this.attackTimer == 35) {
                        this.parentEntity.spawnGroundEffects();
                        for (Entity entity : this.parentEntity.level().getEntitiesOfClass(LivingEntity.class,
                                this.parentEntity.getBoundingBox().inflate(2.0D))) {
                            if (!this.parentEntity.isAlliedTo(entity) && !(entity instanceof EntityHeisen) && entity != this.parentEntity) {
                                entity.hurt(entity.damageSources().mobAttack(this.parentEntity), 8.0F + rand.nextFloat());
                                this.parentEntity.launch(entity, true);
                            }
                        }
                        this.parentEntity.strikeLightningOnTarget(livingentity, 2.0D);
                    }

                    if (this.attackTimer == 43) {
                        this.parentEntity.spawnGroundEffects();
                        for (Entity entity : this.parentEntity.level().getEntitiesOfClass(LivingEntity.class,
                                this.parentEntity.getBoundingBox().inflate(2.0D))) {
                            if (!this.parentEntity.isAlliedTo(entity) && !(entity instanceof EntityHeisen) && entity != this.parentEntity) {
                                entity.hurt(entity.damageSources().mobAttack(this.parentEntity),
                                        livingentity.getMaxHealth() * 0.25f + rand.nextFloat());
                                this.parentEntity.launch(entity, true);
                            }
                        }
                        for (int i = 0; i < 5; ++i) {
                            float f1 = f + (float) i * (float) Math.PI * 0.4F;
                            EntityFallingBlock fb = new EntityFallingBlock(this.parentEntity.level(),
                                    this.parentEntity.getX() + (double) Mth.cos(f1) * 1.5D,
                                    this.parentEntity.getY() + this.parentEntity.random.nextDouble(),
                                    this.parentEntity.getZ() + (double) Mth.sin(f1) * 1.5D,
                                    BlockInit.FACT_IRON_BLOCK.get().defaultBlockState(), 10);
                            this.parentEntity.level().addFreshEntity(fb);
                        }
                        for (int k = 0; k < 8; ++k) {
                            float f2 = f + (float) k * (float) Math.PI * 2.0F / 8.0F + 1.2566371F;
                            EntityFallingBlock fb = new EntityFallingBlock(this.parentEntity.level(),
                                    this.parentEntity.getX() + (double) Mth.cos(f2) * 1.5D,
                                    this.parentEntity.getY() + this.parentEntity.random.nextDouble(),
                                    this.parentEntity.getZ() + (double) Mth.sin(f2) * 1.5D,
                                    BlockInit.FACT_IRON_BLOCK.get().defaultBlockState(), 10);
                            this.parentEntity.level().addFreshEntity(fb);
                        }
                        this.parentEntity.strikeLightningOnTarget(livingentity, 3.0D);
                    }
                }

                // ===== STATE 1：近战锤击 =====
                if (state == 1) {
                    if (this.attackTimer == 25 && this.parentEntity.distanceTo(livingentity) < 3F) {
                        livingentity.hurt(livingentity.damageSources().onFire(), 9.0F);
                    }
                    if (this.attackTimer == 42 && this.parentEntity.distanceTo(livingentity) < 3F) {
                        this.parentEntity.ironQuake(4.25f, 2);
                        this.parentEntity.ironQuakeParticle();
                    }
                }

                // ===== STATE 2 砸地 + 落地 =====
                if (state == 2 && this.attackTimer == 40) {
                    for (int l = 1; l < 10; l++) {
                        this.parentEntity.blockSmashAttack(l, 3F, 1.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, -1.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, 2.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, -2.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, 3.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, -3.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, 4.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, -4.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, 5.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, -5.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, 6.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, -6.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, 7.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, -7.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, 8.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, -8.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, 9.5F, 150, 1.5F, 0.15F, 1.0F);
                        this.parentEntity.blockSmashAttack(l, 3F, -9.5F, 150, 1.5F, 0.15F, 1.0F);
                    }
                    double base = this.parentEntity.getMagnetBaseY() >= 0
                            ? this.parentEntity.getMagnetBaseY()
                            : this.parentEntity.getY();
                    this.parentEntity.landFromMagnet(base);
                }

                // 收尾 + 出招计数 → 强制硬直
                if (this.attackTimer == 45) {
                    this.parentEntity.setAttackingState(0);
                    this.parentEntity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 3, 10, true, true));
                    this.parentEntity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 20 * 3, 10, true, true));
                    this.attackTimer = -5;

                    this.parentEntity.attacksSinceStun++;
                    if (this.parentEntity.attacksSinceStun >= this.parentEntity.nextStunThreshold) {
                        this.parentEntity.attacksSinceStun = 0;
                        this.parentEntity.nextStunThreshold = 3 + this.parentEntity.random.nextInt(3);
                        this.parentEntity.triggerForcedStun();
                    }
                }

                if (this.parentEntity.getAttckingState() != 3) {
                    this.parentEntity.lookAt(livingentity, 30.0F, 30.0F);
                }
            } else if (this.attackTimer > 0) {
                --this.attackTimer;
            }
        }
    }

    // ==================== 重写近战 Goal ====================

    static class HeisenAttackGoal extends MeleeAttackGoal {
        private final EntityHeisen heisen;

        public HeisenAttackGoal(EntityHeisen entity, double speed, boolean useLongMemory) {
            super(entity, speed, useLongMemory);
            this.heisen = entity;
        }

        @Override
        public boolean canUse() {
            if (this.heisen.getAttckingState() != 0) return false;
            if (this.heisen.getStunTicks() > 0) return false;
            if (this.heisen.isMagnetAirborne()) return false;
            return super.canUse();
        }

        @Override
        public boolean canContinueToUse() {
            if (this.heisen.getAttckingState() != 0) return false;
            if (this.heisen.getStunTicks() > 0) return false;
            if (this.heisen.isMagnetAirborne()) return false;
            return super.canContinueToUse();
        }

        @Override
        public void stop() {
            super.stop();
            if (this.heisen.getAttckingState() == 0) {
                this.heisen.getNavigation().stop();
            }
        }
    }

    // ==================== 原有辅助方法 ====================

    private static final Predicate<Entity> PIGEON_AREA = (entity) -> {
        return entity.isAlive() && !(entity instanceof EntityHeisen);
    };

    public void spawnGroundEffects() {
        float radius = 2.3F;
        for (int i = 0; i < 4; i++) {
            for (int i1 = 0; i1 < 20 + random.nextInt(12); i1++) {
                double motionX = getRandom().nextGaussian() * 0.07D;
                double motionY = getRandom().nextGaussian() * 0.07D;
                double motionZ = getRandom().nextGaussian() * 0.07D;
                float angle = (0.01745329251F * this.yBodyRot) + i1;
                double extraX = radius * Mth.sin((float) (Math.PI + angle));
                double extraY = 0.8F;
                double extraZ = radius * Mth.cos(angle);
                BlockPos ground = getGround(new BlockPos(Mth.floor(this.getX() + extraX), Mth.floor(this.getY() + extraY) - 1, Mth.floor(this.getZ() + extraZ)));
                BlockState blockState = this.level().getBlockState(ground);
                if (blockState.getBlock() instanceof AirBlock) {
                    if (level().isClientSide) {
                        level().addParticle(new BlockParticleOption(ParticleTypes.BLOCK, blockState), true,
                                this.getX() + extraX, ground.getY() + extraY, this.getZ() + extraZ,
                                motionX, motionY, motionZ);
                    }
                }
            }
        }
    }

    public void launch(Entity e, boolean huge) {
        if (e.onGround()) {
            double d0 = e.getX() - this.getX();
            double d1 = e.getZ() - this.getZ();
            double d2 = Math.max(d0 * d0 + d1 * d1, 0.001D);
            float f = huge ? 2F : 0.5F;
            e.push(d0 / d2 * f, huge ? 0.5D : 0.2F, d1 / d2 * f);
        }
    }

    private BlockPos getGround(BlockPos in) {
        BlockPos position = new BlockPos(in.getX(), this.getBlockY(), in.getZ());
        while (position.getY() > -62 && !level().getBlockState(position).isSolid() && level().getFluidState(position).isEmpty()) {
            position = position.below();
        }
        return position;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        int co = this.random.nextInt(3);
        if (co == 0) return SoundInit.ENTITY_HESEN_AMBIENT1.get();
        if (co == 1) return SoundInit.ENTITY_HESEN_AMBIENT2.get();
        return SoundInit.ENTITY_HESEN_AMBIENT3.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        Random ran = new Random();
        int co = ran.nextInt(2);
        if (co == 0) return SoundInit.ENTITY_HESEN_HURT1.get();
        return SoundInit.ENTITY_HESEN_HURT2.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundInit.ENTITY_HESEN_DEATH.get();
    }

    private void ironQuakeParticle() {
        if (this.level().isClientSide) {
            for (int i1 = 0; i1 < 20 + this.random.nextInt(12); ++i1) {
                double dmX = this.getRandom().nextGaussian() * 0.07;
                double dmY = this.getRandom().nextGaussian() * 0.07;
                double dmZ = this.getRandom().nextGaussian() * 0.07;
                float angle = (float) Math.PI / 180 * this.yBodyRot + (float) i1;
                double extraX = 4.0f * Mth.sin(((float) (Math.PI + (double) angle)));
                double extraY = 0.3f;
                double extraZ = 4.0f * Mth.cos(angle);
                this.level().addParticle(ParticleTypes.FLAME, this.getX() + extraX, this.getY() + extraY, this.getZ() + extraZ,
                        dmX, dmY, dmZ);
            }
        }
    }

    public void ironQuake(float grow, int damage) {
        this.playSound(SoundEvents.METAL_BREAK, 1.5f, 1.0f + this.getRandom().nextFloat() * 0.1f);
        for (LivingEntity entity : this.level().getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate((double) grow))) {
            if (this.isAlliedTo(entity) || entity instanceof EntityHeisen || entity == this) continue;
            entity.hurt(damageSources().mobAttack(this), entity.getMaxHealth() * 0.3f + (float) this.random.nextInt(damage));
            this.launch(entity, true);
        }
    }

    public void blockSmashAttack(int distance, float mxy, float math, int shieldbreakticks, float damage, float hpdamage, float airborne) {
        int hitY = Mth.floor((double) (this.getBoundingBox().minY - 0.5));
        double minY = this.getY() - 2.0;
        double maxY = this.getY() + (double) mxy;
        float angle = (float) Math.PI / 180 * this.yBodyRot;
        float f = Mth.cos((float) (this.getYRot() * ((float) Math.PI / 180)));
        float f1 = Mth.sin((float) (this.getYRot() * ((float) Math.PI / 180)));
        double extraX = (float) distance * Mth.sin((float) ((float) (Math.PI + (double) angle)));
        double extraZ = (float) distance * Mth.cos((float) angle);
        double px = this.getX() + extraX + (double) (f * math);
        double pz = this.getZ() + extraZ + (double) (f1 * math);
        int hitX = Mth.floor(px);
        int hitZ = Mth.floor(pz);
        BlockPos pos = new BlockPos(hitX, hitY, hitZ);
        BlockPos abovePos = pos.above();
        BlockState block = this.level().getBlockState(pos);
        BlockState blockAbove = this.level().getBlockState(abovePos);
        if (block.getBlock() != Blocks.AIR && !block.hasBlockEntity() && !blockAbove.blocksMotion()) {
            EntityFallingBlock fb = new EntityFallingBlock(this.level(), (double) hitX + 0.5,
                    (double) hitY + 1.0, (double) hitZ + 0.5,
                    BlockInit.FACT_IRON_BLOCK.get().defaultBlockState(), 10);
            fb.push(0.0, 0.2 + this.getRandom().nextGaussian() * 0.15, 0.0);
            this.level().addFreshEntity(fb);
        }
        AABB selection = new AABB(px - 0.5, minY, pz - 0.5, px + 0.5, maxY, pz + 0.5);
        List<LivingEntity> hit = this.level().getEntitiesOfClass(LivingEntity.class, selection);
        for (LivingEntity entity : hit) {
            if (this.isAlliedTo(entity) || entity instanceof EntityHeisen || entity == this) continue;
            if (entity instanceof Player && ((Player) entity).getUseItem().canPerformAction(ToolActions.SHIELD_BLOCK) && shieldbreakticks > 0) {
                this.disableShield(entity, shieldbreakticks);
            } else {
                boolean flag = entity.hurt(damageSources().mobAttack(this),
                        (float) (this.getAttributeValue(Attributes.ATTACK_DAMAGE) * (double) damage + (double) (entity.getMaxHealth() * hpdamage)));
                if (flag)
                    entity.setDeltaMovement(entity.getDeltaMovement().add(0.0, (double) airborne + 0.5, 0.0));
            }
        }
    }

    public static void disableShield(LivingEntity livingEntity, int ticks) {
        ((Player) livingEntity).getCooldowns().addCooldown(livingEntity.getUseItem().getItem(), ticks);
        livingEntity.getUseItem().hurtAndBreak(4 + livingEntity.getRandom().nextInt(2), livingEntity, (p_220009_1_) -> {
            p_220009_1_.broadcastBreakEvent(livingEntity.getUsedItemHand());
        });
        livingEntity.stopUsingItem();
        livingEntity.level().broadcastEntityEvent(livingEntity, (byte) 30);
    }
}