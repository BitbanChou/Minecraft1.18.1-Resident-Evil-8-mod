package com.joy187.re8joymod.entity.model;

import com.joy187.re8joymod.Main;
import com.joy187.re8joymod.entity.EntityPesanta;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class ModelPesanta extends GeoModel<EntityPesanta> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation(Main.MOD_ID, "pesanta"), "main");

    @Override
    public ResourceLocation getModelResource(EntityPesanta object) {
        return new ResourceLocation(Main.MOD_ID, "geo/pesanta.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(EntityPesanta object) {
        return new ResourceLocation(Main.MOD_ID, "textures/entity/verdugo.png");
    }

    @Override
    public ResourceLocation getAnimationResource(EntityPesanta animatable) {
        return new ResourceLocation(Main.MOD_ID, "animations/pesanta.animation.json");
    }
}