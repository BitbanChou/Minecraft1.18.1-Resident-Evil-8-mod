package com.joy187.re8joymod.entity;

import net.minecraft.world.entity.FlyingMob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.FlyingAnimal;
import net.minecraft.world.entity.monster.Ghast;
import net.minecraft.world.entity.monster.Phantom;
import net.minecraft.world.entity.monster.Vex;
import net.minecraft.world.phys.Vec3;

import software.bernie.geckolib.animatable.GeoEntity;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/**
 * Shared anti-air behaviour for gun-capable allies (Hank / Leon / Ada):
 * detect aerial targets, hold a shoot band, keep shoot anim playing, stop chasing.
 *
 * <p>Animation note: do <b>not</b> pulse STATE {@code 0 → shoot} in the same tick to
 * restart anims — the client often only receives the final value. Prefer
 * {@code thenLoop(shootAnim)} on the combat controller, or call
 * {@link #triggerShootAnim} each volley for triggerAnim-based entities.
 */
public final class AerialCombatHelper {
    public static final double MIN_SHOOT_DIST = 7.0D;
    public static final double IDEAL_SHOOT_DIST = 10.0D;
    public static final double MAX_SHOOT_DIST = 14.0D;

    private AerialCombatHelper() {
    }

    public static boolean isAerialTarget(LivingEntity self, LivingEntity target) {
        if (target == null || self == null) {
            return false;
        }
        if (target instanceof FlyingMob
                || target instanceof FlyingAnimal
                || target instanceof Ghast
                || target instanceof Phantom
                || target instanceof Vex) {
            return true;
        }
        double dy = (target.getY() + target.getBbHeight() * 0.5D) - self.getY();
        return dy > 2.25D
                && !target.onGround()
                && !target.isInWater()
                && !target.onClimbable();
    }

    /**
     * Stop pathfinding; back off if too close, ease in if too far, damp motion in the ideal band.
     * Looks upward at the target so gun pitch can track air units.
     */
    public static void holdShootDistance(Mob self, LivingEntity target) {
        self.getNavigation().stop();
        self.getLookControl().setLookAt(target, 40.0F, 85.0F);

        double dist = self.distanceTo(target);
        Vec3 away = self.position().subtract(target.position());
        Vec3 flat = new Vec3(away.x, 0.0D, away.z);
        if (flat.lengthSqr() < 1.0E-4D) {
            Vec3 look = self.getLookAngle();
            flat = new Vec3(look.x, 0.0D, look.z);
        }
        if (flat.lengthSqr() < 1.0E-4D) {
            return;
        }
        flat = flat.normalize();

        if (dist < MIN_SHOOT_DIST) {
            Vec3 push = flat.scale(0.38D);
            self.setDeltaMovement(push.x, self.getDeltaMovement().y, push.z);
            self.hasImpulse = true;
        } else if (dist > MAX_SHOOT_DIST) {
            Vec3 pull = flat.scale(-0.24D);
            self.setDeltaMovement(pull.x, self.getDeltaMovement().y, pull.z);
            self.hasImpulse = true;
        } else {
            Vec3 m = self.getDeltaMovement();
            self.setDeltaMovement(m.x * 0.2D, m.y, m.z * 0.2D);
        }
    }

    /**
     * Keep attacking-state on the shoot value so movement controllers STOP and combat
     * controllers can {@code thenLoop} the shoot anim. Only writes when changed.
     */
    public static void ensureShootState(IntSupplier getState, IntConsumer setState, int shootState) {
        if (getState.getAsInt() != shootState) {
            setState.accept(shootState);
        }
    }

    /**
     * For GeckoLib {@code triggerableAnim} setups (e.g. Leon): fire the shoot trigger
     * so the anim actually starts / restarts on the client.
     */
    public static void triggerShootAnim(GeoEntity geo, String controllerName, String triggerName) {
        if (geo == null || controllerName == null || triggerName == null) {
            return;
        }
        geo.triggerAnim(controllerName, triggerName);
    }

    /** Aim a BOW projectile at the target's upper body (works for air units). */
    public static void aimBowShot(LivingEntity shooter, EntityBOWShoot shot, LivingEntity target,
                                  float speed, float inaccuracy) {
        Vec3 from = shooter.getEyePosition();
        Vec3 to = target.position().add(0.0D, target.getBbHeight() * 0.55D, 0.0D).subtract(from);
        if (to.lengthSqr() < 1.0E-6D) {
            shot.shootFromRotation(shooter, shooter.getXRot(), shooter.getYRot(), 0.0F, speed, inaccuracy);
        } else {
            Vec3 dir = to.normalize();
            shot.shoot(dir.x, dir.y, dir.z, speed, inaccuracy);
        }
    }
}
