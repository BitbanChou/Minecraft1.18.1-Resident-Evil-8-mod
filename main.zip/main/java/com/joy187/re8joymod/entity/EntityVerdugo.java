package com.joy187.re8joymod.entity;

import com.joy187.re8joymod.init.ParticleInit;
import com.joy187.re8joymod.items.ItemCombatKnife;
import com.joy187.re8joymod.util.CommonFunctions;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.raid.Raider;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ToolActions;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.EnumSet;
import java.util.function.Predicate;

public class EntityVerdugo extends Ravager implements GeoEntity {
	private static final Predicate<Entity> VER_AREA = entity -> entity.isAlive() && !(entity instanceof EntityVerdugo);

	/** attack / attack2 动画均为 1.52 秒。 */
	private static final int ATTACK_END = 30;
	/** 尾巴突刺：约 0.32 秒甩到最前。 */
	private static final int TAIL_HIT_TICK = 6;
	/** 扑击落地：约 0.88 秒。 */
	private static final int POUNCE_HIT_TICK = 18;
	private static final int COMBO_COOLDOWN = -10;
	/** 尾巴突刺结束后站定恢复时间：0.5 秒。 */
	private static final int TAIL_RECOVER_TICKS = 10;
	/** 尾巴突刺扇形半角（总 120°）。 */
	private static final double TAIL_CONE_DEGREES = 60.0D;
	/** 尾巴突刺站定期间允许的微小位移容差（防止被击退/水流带走时不纠正）。 */
	private static final double TAIL_HOLD_SPEED = 0.02D;
	/** 状态 4：尾巴突刺后的站定恢复中。 */
	private static final int STATE_TAIL_RECOVER = 4;

	// ===== 甩尾（tailswag）=====
	/** 状态 3：甩尾攻击。 */
	private static final int STATE_TAIL_SWAG = 3;
	/** 甩尾动画 1.0s = 20 tick。 */
	private static final int TAIL_SWAG_END = 20;
	/** 冲侧面阶段：前 8 tick 移动。 */
	private static final int TAIL_SWAG_APPROACH_TICKS = 8;
	/** 甩尾命中判定：动画 0.5s 尾巴甩到最前（20 tick * 0.5 = 10）。 */
	private static final int TAIL_SWAG_HIT_TICK = 10;
	/** 甩尾范围判定半径。 */
	private static final double TAIL_SWAG_RADIUS = 4.5D;
	/** 甩尾扇形半角（总 240°）。 */
	private static final double TAIL_SWAG_CONE_DEGREES = 120.0D;
	/** 甩尾独立冷却（tick），避免连续甩尾。 */
	private static final int TAIL_SWAG_COOLDOWN_TICKS = 80;

	private final AnimatableInstanceCache factory = GeckoLibUtil.createInstanceCache(this);
	public static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(EntityVerdugo.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Integer> DEFENDSTATE = SynchedEntityData.defineId(EntityVerdugo.class, EntityDataSerializers.INT);

	private int attr;
	protected int attackTimer;
	private int phaseStart;
	private boolean pounceHit;
	private boolean tailSwagHit;
	private int tailSwagCooldown;

	public EntityVerdugo(EntityType<? extends Ravager> type, Level worldIn) {
		super(type, worldIn);
		this.xpReward = 70;
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(1, new AttackGoal(this));
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.4D));
		this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
		this.addBehaviourGoals();
	}

	protected void addBehaviourGoals() {
		this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
		this.targetSelector.addGoal(2, (new HurtByTargetGoal(this, Raider.class)).setAlertOthers());
		this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractVillager.class, true));
		this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
		this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, EntityEthan.class, true));
	}

	public static AttributeSupplier.Builder prepareAttributes() {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, 100.0D)
				.add(Attributes.MOVEMENT_SPEED, 0.6D)
				.add(Attributes.FOLLOW_RANGE, 50.0D)
				.add(Attributes.ARMOR, 10.0D)
				.add(Attributes.ARMOR_TOUGHNESS, 5.0D)
				.add(Attributes.KNOCKBACK_RESISTANCE, 0.3D)
				.add(Attributes.ATTACK_DAMAGE, 9.0D);
	}

	public float getAttackDamage() {
		return (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE);
	}

	public void aiStep() {
		super.aiStep();
		if (!this.isAlive()) {
			return;
		}

		if (this.tailSwagCooldown > 0) {
			--this.tailSwagCooldown;
		}

		if (this.horizontalCollision && net.minecraftforge.event.ForgeEventFactory.getMobGriefingEvent(this.level(), this)) {
			boolean flag = false;
			AABB aabb = this.getBoundingBox().inflate(0.2D);
			for (BlockPos blockpos : BlockPos.betweenClosed(
					Mth.floor(aabb.minX), Mth.floor(aabb.minY), Mth.floor(aabb.minZ),
					Mth.floor(aabb.maxX), Mth.floor(aabb.maxY), Mth.floor(aabb.maxZ))) {
				BlockState blockstate = this.level().getBlockState(blockpos);
				Block block = blockstate.getBlock();
				if (block instanceof LeavesBlock) {
					flag = this.level().destroyBlock(blockpos, true, this) || flag;
				}
			}
			if (!flag && this.onGround()) {
				this.jumpFromGround();
			}
		}

		if (this.getHealth() < this.getMaxHealth() * 0.5F
				&& this.getHealth() > this.getMaxHealth() * 0.4F
				&& !this.hasEffect(MobEffects.INVISIBILITY)) {
			this.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 200));
		}
		if (this.entityData.get(STATE) == 2) {
			this.roar();
		}
		if (this.entityData.get(DEFENDSTATE) == 1) {
			this.defend();
		}
	}

	private void roar() {
		if (!this.isAlive()) {
			return;
		}
		Vec3 vec3 = this.getBoundingBox().getCenter();
		for (int i = 0; i < 10; i++) {
			float deltaOmega = 1.0f * i;
			Vec3 pos = new Vec3(vec3.x + Math.sin(deltaOmega), vec3.y, vec3.z + Math.cos(deltaOmega));
			this.level().addParticle(ParticleInit.MUCUS_PARTICLE.get(), pos.x, pos.y, pos.z, 0, 0, 0);
		}
		this.level().gameEvent(this, GameEvent.ENTITY_ROAR, this.getEyePosition());
	}

	private void defend() {
		if (!this.isAlive()) {
			return;
		}
		Vec3 vec3 = this.getBoundingBox().getCenter();
		for (int j = 0; j < 3; j++) {
			for (int i = 0; i < 10; i++) {
				float deltaOmega = 1.0f * i;
				Vec3 pos = new Vec3(vec3.x + Math.sin(deltaOmega), vec3.y + j, vec3.z + Math.cos(deltaOmega));
				this.level().addParticle(ParticleInit.DEFEND_PARTICLE.get(), pos.x, pos.y, pos.z, 0, 0, 0);
			}
		}
		this.level().gameEvent(this, GameEvent.ENTITY_ROAR, this.getEyePosition());
	}

	/** 甩尾灰尘粒子：以自身为中心向外扫出一圈。 */
	private void spawnTailSwagDust() {
		Vec3 center = this.getBoundingBox().getCenter();
		for (int i = 0; i < 24; i++) {
			double angle = (Math.PI * 2.0D) * (i / 24.0D);
			double r = TAIL_SWAG_RADIUS * 0.65D;
			double x = center.x + Math.cos(angle) * r;
			double z = center.z + Math.sin(angle) * r;
			double y = center.y + 0.15D + this.random.nextDouble() * 0.3D;
			// 灰尘主体
			this.level().addParticle(ParticleTypes.CLOUD, x, y, z,
					Math.cos(angle) * 0.08D, 0.02D, Math.sin(angle) * 0.08D);
			if (i % 3 == 0) {
				this.level().addParticle(ParticleTypes.POOF, x, y, z, 0.0D, 0.03D, 0.0D);
			}
		}
		// 中心一团扬尘
		for (int i = 0; i < 8; i++) {
			this.level().addParticle(ParticleTypes.CLOUD,
					center.x + (this.random.nextDouble() - 0.5D) * 2.0D,
					center.y + 0.1D,
					center.z + (this.random.nextDouble() - 0.5D) * 2.0D,
					0.0D, 0.05D, 0.0D);
		}
	}

	private <E extends GeoAnimatable> PlayState predicate(AnimationState<E> event) {
		int atk = this.entityData.get(STATE);
		if (atk == 1 || atk == 2 || atk == STATE_TAIL_SWAG || atk == STATE_TAIL_RECOVER) {
			return PlayState.STOP;
		}
		if (this.isDeadOrDying()) {
			event.setAndContinue(RawAnimation.begin().thenPlay("animation.verdugo.death"));
			return PlayState.CONTINUE;
		}
		if (event.isMoving()) {
			event.setAndContinue(RawAnimation.begin().thenLoop("animation.verdugo.walk"));
			return PlayState.CONTINUE;
		}
		event.setAndContinue(RawAnimation.begin().thenLoop("animation.verdugo.idle"));
		return PlayState.CONTINUE;
	}

	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar data) {
		AnimationController<?> attackController =
				new AnimationController<>(this, "controller1", 5, state -> PlayState.STOP)
						.triggerableAnim("slash", RawAnimation.begin().thenPlay("animation.verdugo.attack"))
						.triggerableAnim("heavy", RawAnimation.begin().thenPlay("animation.verdugo.attack2"))
						.triggerableAnim("tailswag", RawAnimation.begin().thenPlay("animation.verdugo.tailswag"));
		data.add(attackController);
		data.add(new AnimationController<>(this, "controller", 6, this::predicate));
	}

	public int getDefendingState() {
		return this.entityData.get(DEFENDSTATE);
	}

	public void setDefendingState(int time) {
		this.entityData.set(DEFENDSTATE, time);
	}

	public int getAttckingState() {
		return this.entityData.get(STATE);
	}

	protected void startAttackAnim(int state) {
		if (state == 1) {
			this.triggerAnim("controller1", "slash");
		} else if (state == 2) {
			this.triggerAnim("controller1", "heavy");
		} else if (state == STATE_TAIL_SWAG) {
			this.triggerAnim("controller1", "tailswag");
		}
	}

	public void setAttackingState(int time) {
		int prev = this.entityData.get(STATE);
		this.entityData.set(STATE, time);
		if ((time == 1 || time == 2 || time == STATE_TAIL_SWAG) && prev != time) {
			this.startAttackAnim(time);
		}
	}

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(STATE, 0);
		this.entityData.define(DEFENDSTATE, 0);
	}

	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {
		return this.factory;
	}

	private boolean isAttacking() {
		return this.getAttckingState() != 0;
	}

	/** 抓投/扑击：打断刀盾格挡后仍造成全额伤害，无法弹反。 */
	public void hurtUnparryable(LivingEntity target, float damage) {
		if (target instanceof Player player && isKnifeOrShieldBlocking(player)) {
			player.stopUsingItem();
		}
		target.hurt(this.damageSources().mobAttack(this), damage);
	}

	/** 尾巴突刺：可被刀盾弹反（弹反成功则破盾硬直，否则吃高伤）。 */
	private void hurtTailThrust(LivingEntity target, float damage) {
		if (target instanceof Player player && isKnifeOrShieldBlocking(player)) {
			disableShield(player, 80);
			return;
		}
		target.hurt(this.damageSources().mobAttack(this), damage);
	}

	private static boolean isKnifeOrShieldBlocking(Player player) {
		if (!player.isUsingItem()) {
			return false;
		}
		var stack = player.getUseItem();
		return stack.getItem() instanceof ItemCombatKnife
				|| stack.getItem() instanceof ShieldItem
				|| stack.canPerformAction(ToolActions.SHIELD_BLOCK);
	}

	public static void disableShield(LivingEntity livingEntity, int ticks) {
		if (!(livingEntity instanceof Player player)) {
			return;
		}
		player.getCooldowns().addCooldown(livingEntity.getUseItem().getItem(), ticks);
		livingEntity.getUseItem().hurtAndBreak(3 + livingEntity.getRandom().nextInt(2), livingEntity, e -> {
			e.broadcastBreakEvent(livingEntity.getUsedItemHand());
		});
		livingEntity.stopUsingItem();
		livingEntity.level().broadcastEntityEvent(livingEntity, (byte) 30);
	}


	@Override
	public boolean hurt(DamageSource source, float amount) {
		// 1. 计算非玩家减伤后的最终伤害
		float finalDamage = CommonFunctions.applyNonPlayerReduction(this, source, amount);

		// 2. 传递减伤后的数值给原版扣血
		boolean hurt = super.hurt(source, finalDamage);

		// 3. 反击与仇恨逻辑（保持原样，不影响）
		if (hurt && !this.level().isClientSide && source.getEntity() instanceof LivingEntity living && living != this) {
			if (this.getTarget() == null) {
				this.setTarget(living);
			}
		}
		return hurt;
	}

	/** 液氮罐爆炸：减速并造成最大生命 20% 伤害。 */
	public void onLiquidNitrogenBurst() {
		if (this.level().isClientSide || !this.isAlive()) {
			return;
		}
		this.hurt(this.damageSources().magic(), this.getMaxHealth() * 0.2F);
		this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10 * 20, 2, false, true));
		this.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 10 * 20, 1, false, true));
		if (this.isAttacking()) {
			this.setAttackingState(0);
			this.attackTimer = COMBO_COOLDOWN;
			this.attr = 0;
			this.setDefendingState(1);
		}
	}

	static class AttackGoal extends Goal {
		private final EntityVerdugo parentEntity;

		public AttackGoal(EntityVerdugo mob) {
			this.parentEntity = mob;
			this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
		}

		@Override
		public boolean canUse() {
			return this.parentEntity.getTarget() != null;
		}

		@Override
		public void start() {
			this.parentEntity.setAggressive(true);
		}

		@Override
		public void stop() {
			this.parentEntity.setAggressive(false);
			this.parentEntity.setAttackingState(0);
			this.parentEntity.setDefendingState(0);
			this.parentEntity.attr = 0;
			this.parentEntity.attackTimer = -1;
			this.parentEntity.tailSwagHit = false;
		}

		@Override
		public void tick() {
			LivingEntity target = this.parentEntity.getTarget();
			if (target == null || !target.isAlive()) {
				return;
			}
			this.parentEntity.lookAt(target, 30.0F, 30.0F);

			if (this.parentEntity.hasEffect(MobEffects.DAMAGE_RESISTANCE)) {
				this.parentEntity.setDefendingState(0);
				if (!this.parentEntity.isAttacking()) {
					return;
				}
			}

			if (!this.parentEntity.isAttacking()) {
				if (this.parentEntity.attackTimer < 0) {
					++this.parentEntity.attackTimer;
					this.parentEntity.getNavigation().moveTo(target, 1.15D);
					return;
				}
				double dist = this.parentEntity.distanceTo(target);
				if (dist > 12.0D) {
					this.parentEntity.getNavigation().moveTo(target, 1.2D);
					return;
				}
				this.beginAttack(target, dist);
				return;
			}

			++this.parentEntity.attackTimer;
			int elapsed = this.parentEntity.attackTimer - this.parentEntity.phaseStart;
			int state = this.parentEntity.getAttckingState();

			if (state == 2) {
				this.tickTailThrust(target, elapsed);
				if (elapsed >= ATTACK_END) {
					this.finishAttack();
				}
			} else if (state == 1) {
				this.tickPounce(target, elapsed);
				if (elapsed >= ATTACK_END) {
					this.finishAttack();
				}
			} else if (state == STATE_TAIL_SWAG) {
				this.tickTailSwag(target, elapsed);
				if (elapsed >= TAIL_SWAG_END) {
					this.finishAttack();
				}
			} else if (state == STATE_TAIL_RECOVER) {
				this.tickTailRecover();
				if (elapsed >= TAIL_RECOVER_TICKS) {
					this.parentEntity.setAttackingState(0);
					this.parentEntity.attackTimer = COMBO_COOLDOWN;
					this.parentEntity.setDefendingState(0);
				}
			}
		}

		private void beginAttack(LivingEntity target, double dist) {
			this.parentEntity.getNavigation().stop();
			this.parentEntity.phaseStart = 1;
			this.parentEntity.attackTimer = 1;
			this.parentEntity.pounceHit = false;
			this.parentEntity.tailSwagHit = false;

			// 甩尾：中距离、冷却就绪，且随机/血量窗口触发
			boolean canSwag = this.parentEntity.tailSwagCooldown <= 0
					&& dist > 3.0D && dist <= 8.5D
					&& this.parentEntity.getHealth() > this.parentEntity.getMaxHealth() * 0.25F;
			boolean preferSwag = canSwag && this.parentEntity.getRandom().nextFloat() < 0.5F;

			// 近距离优先尾巴突刺；稍远或血量窗口则扑击抓投
			boolean preferPounce = dist > 4.5D
					|| ((this.parentEntity.getHealth() >= this.parentEntity.getMaxHealth() * 0.75F
					&& this.parentEntity.getHealth() <= this.parentEntity.getMaxHealth() * 0.90F)
					|| (this.parentEntity.getHealth() >= this.parentEntity.getMaxHealth() * 0.40F
					&& this.parentEntity.getHealth() <= this.parentEntity.getMaxHealth() * 0.60F)
					|| (this.parentEntity.getHealth() >= this.parentEntity.getMaxHealth() * 0.10F
					&& this.parentEntity.getHealth() <= this.parentEntity.getMaxHealth() * 0.30F));

			if (preferSwag) {
				// 冲侧面：选目标左/右侧后方的落点
				this.parentEntity.tailSwagCooldown = TAIL_SWAG_COOLDOWN_TICKS;
				this.parentEntity.setAttackingState(STATE_TAIL_SWAG);
				this.parentEntity.attr = 3;
				Vec3 side = pickSidePoint(target, this.parentEntity.getRandom().nextBoolean());
				if (side != null) {
					this.parentEntity.getNavigation().moveTo(side.x, side.y, side.z, 1.35D);
				}
			} else if (preferPounce && dist <= 10.0D) {
				this.parentEntity.setAttackingState(1);
				this.parentEntity.attr = 1;
				Vec3 to = target.position().subtract(this.parentEntity.position());
				Vec3 flat = new Vec3(to.x, 0.0D, to.z);
				if (flat.lengthSqr() > 1.0E-4D) {
					flat = flat.normalize();
					this.parentEntity.setDeltaMovement(flat.x * 1.15D, 0.55D, flat.z * 1.15D);
					this.parentEntity.hasImpulse = true;
				}
			} else {
				this.parentEntity.getNavigation().stop();
				this.parentEntity.setDeltaMovement(Vec3.ZERO);
				this.parentEntity.setAttackingState(2);
				this.parentEntity.attr = 2;
			}
		}

		/** 取目标左/右侧方约 2 格、略微靠后的落点。 */
		private Vec3 pickSidePoint(LivingEntity target, boolean rightSide) {
			Vec3 look = target.getLookAngle();
			Vec3 flat = new Vec3(look.x, 0.0D, look.z);
			if (flat.lengthSqr() < 1.0E-4D) {
				return null;
			}
			flat = flat.normalize();
			// 右方向 = forward × up
			Vec3 right = new Vec3(-flat.z, 0.0D, flat.x);
			Vec3 dir = rightSide ? right : right.scale(-1.0D);
			// 侧方 2 格 + 稍微靠后 0.8 格
			Vec3 offset = dir.scale(2.0D).subtract(flat.scale(0.8D));
			return target.position().add(offset);
		}

		protected void tickTailThrust(LivingEntity target, int elapsed) {
			// 站定：每 tick 清导航和水平速度，只允许极小的外力位移
			this.parentEntity.getNavigation().stop();
			Vec3 motion = this.parentEntity.getDeltaMovement();
			if (motion.horizontalDistanceSqr() > TAIL_HOLD_SPEED * TAIL_HOLD_SPEED) {
				this.parentEntity.setDeltaMovement(motion.x * 0.2D, motion.y, motion.z * 0.2D);
			}

			if (elapsed == TAIL_HIT_TICK) {
				float damage = this.parentEntity.getAttackDamage() * 1.8F + target.getMaxHealth() * 0.12F;
				AABB box = this.parentEntity.getBoundingBox().inflate(2.8D, 1.0D, 2.8D);
				Vec3 look = this.parentEntity.getLookAngle();
				Vec3 forward = new Vec3(look.x, 0.0D, look.z);
				if (forward.lengthSqr() > 1.0E-4D) {
					forward = forward.normalize();
				}
				double cosHalf = Math.cos(Math.toRadians(TAIL_CONE_DEGREES)); // 60° 半角 → 总 120°
				for (LivingEntity living : this.parentEntity.level().getEntitiesOfClass(LivingEntity.class, box, VER_AREA)) {
					double dx = living.getX() - this.parentEntity.getX();
					double dz = living.getZ() - this.parentEntity.getZ();
					double dist = Math.sqrt(dx * dx + dz * dz);
					if (dist > 4.0D) {
						continue;
					}
					if (forward.lengthSqr() > 1.0E-4D && dist > 0.001D) {
						Vec3 toward = new Vec3(dx / dist, 0.0D, dz / dist);
						if (forward.dot(toward) < cosHalf) {
							continue; // 落在 120° 扇形外
						}
					}
					this.parentEntity.hurtTailThrust(living, damage);
					this.parentEntity.heal(1.5F);
				}
				this.parentEntity.playSound(SoundEvents.RAVAGER_ATTACK, 1.0F, 1.2F);
			}
		}

		protected void tickPounce(LivingEntity target, int elapsed) {
			if (elapsed >= 4 && elapsed <= 14) {
				Vec3 to = target.position().subtract(this.parentEntity.position());
				Vec3 flat = new Vec3(to.x, 0.0D, to.z);
				if (flat.lengthSqr() > 0.25D) {
					flat = flat.normalize().scale(0.35D);
					Vec3 motion = this.parentEntity.getDeltaMovement();
					this.parentEntity.setDeltaMovement(flat.x, motion.y, flat.z);
				}
			}
			if (!this.parentEntity.pounceHit && elapsed >= POUNCE_HIT_TICK) {
				this.parentEntity.pounceHit = true;
				float damage = this.parentEntity.getAttackDamage() * 1.35F + target.getMaxHealth() * 0.08F;
				AABB box = this.parentEntity.getBoundingBox().inflate(2.2D, 1.2D, 2.2D);
				for (LivingEntity living : this.parentEntity.level().getEntitiesOfClass(LivingEntity.class, box, VER_AREA)) {
					this.parentEntity.hurtUnparryable(living, damage);
					living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
					if (living instanceof Player player) {
						Vec3 pull = this.parentEntity.position().subtract(player.position()).normalize().scale(0.45D);
						player.setDeltaMovement(pull.x, 0.25D, pull.z);
						player.hurtMarked = true;
					}
					this.parentEntity.heal(2.0F);
				}
				this.parentEntity.playSound(SoundEvents.RAVAGER_ATTACK, 1.0F, 0.85F);
			}
		}

		/** 甩尾：前 8 tick 冲向侧面，之后站定面对目标，第 10 tick 判定。 */
		protected void tickTailSwag(LivingEntity target, int elapsed) {
			if (elapsed < TAIL_SWAG_APPROACH_TICKS) {
				// 冲侧面阶段：保持朝目标，允许导航移动
				if (elapsed == 1) {
					Vec3 side = pickSidePoint(target, this.parentEntity.getRandom().nextBoolean());
					if (side != null) {
						this.parentEntity.getNavigation().moveTo(side.x, side.y, side.z, 1.35D);
					}
				}
				return;
			}

			// 站定面对目标
			this.parentEntity.getNavigation().stop();
			this.parentEntity.getLookControl().setLookAt(target, 30.0F, 30.0F);
			Vec3 motion = this.parentEntity.getDeltaMovement();
			if (motion.horizontalDistanceSqr() > TAIL_HOLD_SPEED * TAIL_HOLD_SPEED) {
				this.parentEntity.setDeltaMovement(motion.x * 0.2D, motion.y, motion.z * 0.2D);
			}

			if (!this.parentEntity.tailSwagHit && elapsed >= TAIL_SWAG_HIT_TICK) {
				this.parentEntity.tailSwagHit = true;
				this.doTailSwagHit(target);
			}
		}

		private void doTailSwagHit(LivingEntity target) {
			float damage = this.parentEntity.getAttackDamage() * 1.6F + target.getMaxHealth() * 0.10F;
			AABB box = this.parentEntity.getBoundingBox().inflate(TAIL_SWAG_RADIUS, 1.5D, TAIL_SWAG_RADIUS);
			Vec3 look = this.parentEntity.getLookAngle();
			Vec3 forward = new Vec3(look.x, 0.0D, look.z);
			if (forward.lengthSqr() > 1.0E-4D) {
				forward = forward.normalize();
			}
			double cosHalf = Math.cos(Math.toRadians(TAIL_SWAG_CONE_DEGREES)); // 120° 半角 → 总 240°
			for (LivingEntity living : this.parentEntity.level().getEntitiesOfClass(LivingEntity.class, box, VER_AREA)) {
				double dx = living.getX() - this.parentEntity.getX();
				double dz = living.getZ() - this.parentEntity.getZ();
				double dist = Math.sqrt(dx * dx + dz * dz);
				if (dist > TAIL_SWAG_RADIUS || dist < 0.001D) {
					continue;
				}
				if (forward.lengthSqr() > 1.0E-4D) {
					Vec3 toward = new Vec3(dx / dist, 0.0D, dz / dist);
					if (forward.dot(toward) < cosHalf) {
						continue; // 落在 240° 扇形外
					}
				}
				// 甩尾不可弹反，直接打断格挡
				this.parentEntity.hurtUnparryable(living, damage);

				// 击飞：沿自身->目标方向强力推开，带垂直分量
				Vec3 push = new Vec3(dx / dist, 0.0D, dz / dist).scale(1.6D);
				double up = 0.75D;
				living.setDeltaMovement(push.x, up, push.z);
				living.hurtMarked = true;
				living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 0));
				if (living instanceof Player player) {
					player.hurtMarked = true;
				}
				this.parentEntity.heal(1.5F);
			}
			this.parentEntity.spawnTailSwagDust();
			this.parentEntity.playSound(SoundEvents.RAVAGER_ATTACK, 1.2F, 0.7F);
		}

		protected void tickTailRecover() {
			this.parentEntity.getNavigation().stop();
			Vec3 motion = this.parentEntity.getDeltaMovement();
			if (motion.horizontalDistanceSqr() > TAIL_HOLD_SPEED * TAIL_HOLD_SPEED) {
				this.parentEntity.setDeltaMovement(motion.x * 0.2D, motion.y, motion.z * 0.2D);
			}
		}

		private void finishAttack() {
			int state = this.parentEntity.getAttckingState();
			if (state == STATE_TAIL_SWAG) {
				// 甩尾 → 站定恢复 0.5s
				this.parentEntity.setAttackingState(STATE_TAIL_RECOVER);
				this.parentEntity.attackTimer = 0;
				this.parentEntity.phaseStart = 0;
				this.parentEntity.attr = 0;
				this.parentEntity.tailSwagHit = false;
				this.parentEntity.getNavigation().stop();
				this.parentEntity.setDeltaMovement(Vec3.ZERO);
				this.parentEntity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, TAIL_RECOVER_TICKS, 1, true, true));
				this.parentEntity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, TAIL_RECOVER_TICKS, 4, true, true));
				this.parentEntity.setDefendingState(1);
				return;
			}
			if (state == 2) {
				// 尾巴突刺 → 进入站定恢复
				this.parentEntity.setAttackingState(STATE_TAIL_RECOVER);
				this.parentEntity.attackTimer = 0;
				this.parentEntity.phaseStart = 0;
				this.parentEntity.attr = 0;
				this.parentEntity.pounceHit = false;
				this.parentEntity.getNavigation().stop();
				this.parentEntity.setDeltaMovement(Vec3.ZERO);
				this.parentEntity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, TAIL_RECOVER_TICKS, 1, true, true));
				this.parentEntity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, TAIL_RECOVER_TICKS, 4, true, true));
				this.parentEntity.setDefendingState(1);
				return;
			}
			// 扑击保持原逻辑
			this.parentEntity.setAttackingState(0);
			this.parentEntity.attackTimer = COMBO_COOLDOWN;
			this.parentEntity.attr = 0;
			this.parentEntity.pounceHit = false;
			this.parentEntity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 30, 1, true, true));
			this.parentEntity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 30, 4, true, true));
			this.parentEntity.setDefendingState(1);
		}
	}

	@Override
	public boolean doHurtTarget(Entity entityIn) {
		if (entityIn instanceof LivingEntity target) {
			float sizeMult = CommonFunctions.getSizeDamageMultiplier(this, target);

			// 如果倍率 > 1，额外补一发真实伤害（不影响原版击退和动画）
			if (sizeMult > 1.0F) {
				float baseDamage = (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE);
				float extraDamage = baseDamage * (sizeMult - 1.0F);
				target.hurt(target.damageSources().mobAttack(this), extraDamage);
			}
		}
		return super.doHurtTarget(entityIn);
	}
}