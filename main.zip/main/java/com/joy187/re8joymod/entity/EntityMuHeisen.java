package com.joy187.re8joymod.entity;

import java.util.List;
import java.util.Random;
import java.util.function.Predicate;

import javax.annotation.Nullable;

import com.joy187.re8joymod.init.BlockInit;
import com.joy187.re8joymod.init.ParticleInit;
import com.joy187.re8joymod.init.SoundInit;
import com.mojang.blaze3d.vertex.PoseStack.Pose;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.pathfinder.BlockPathTypes;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ToolActions;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;

/**
 * MuHeisen：Heisen 的变异版。使用 triggerableAnim 驱动一次性攻击动画，
 * 攻击期间冻结移动，连招结束后进入 recover 后摇。
 *
 * 技能：
 *  - STATE 1：巨臂挥击（超目标冲刺 + 近战挥击）
 *  - STATE 2：金属板防御与投掷（召唤金属板护盾 + 投掷 + 弱点）
 *  - STATE 3：铁板飓风（旋转 + 扇形缺口伤害）
 *  - STATE 4：AOE 药水（保留原逻辑）
 */
public class EntityMuHeisen extends Ravager implements GeoEntity {

	private final AnimatableInstanceCache factory = GeckoLibUtil.createInstanceCache(this);

	// ===== 动画名 =====
	private static final String ANIM_WALK   = "animation.muheisen.walk";
	private static final String ANIM_IDLE   = "animation.muheisen.idle";
	private static final String ANIM_ATK1   = "animation.muheisen.attack";   // 巨臂挥击
	private static final String ANIM_ATK2   = "animation.muheisen.aoe";      // AOE 药水
	private static final String ANIM_ATK3   = "animation.muheisen.attack2";  // 金属板防御与投掷
	private static final String ANIM_ATK4   = "animation.muheisen.attack3";  // 铁板飓风
	private static final String ANIM_RECOVER = "animation.muheisen.recover"; // 后摇（需补）

	// ===== 状态同步 =====
	public static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(EntityMuHeisen.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Integer> DEFENDSTATE = SynchedEntityData.defineId(EntityMuHeisen.class, EntityDataSerializers.INT);
	public static final EntityDataAccessor<Boolean> SHIELD_ACTIVE = SynchedEntityData.defineId(EntityMuHeisen.class, EntityDataSerializers.BOOLEAN);
	private final List<EntityFallingBlock> thrownPlates = new java.util.ArrayList<>();
	private final java.util.Map<java.util.UUID, Integer> plateHitCooldown = new java.util.HashMap<>();

	// ===== 基础 =====
	private final ServerBossEvent bossInfo = (ServerBossEvent) (new ServerBossEvent(
			this.getDisplayName(), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS)).setDarkenScreen(true);

	public int explosionPower = 5, attr = 0, pre = 0;
	public boolean isaoe = false;

	private int attackTimer = 0;
	private int aoeSkillCooldown = 120;

	// ===== 硬直 / recover =====
	private static final int RECOVER_TICKS = 30;   // 2 秒
	private int recoverTimer = 0;
	private static final int STUN_TICKS = 20;
	private int stunTicks = 0;

	// ===== 金属板护盾 =====
	private int shieldTicks = 0;
	private static final int SHIELD_MAX_HITS = 5;
	private int shieldHits = 0;

	// ===== 冲刺 =====
	private boolean dashing = false;
	private double dashTargetX, dashTargetZ;
	private int dashTicks = 0;
	private static final int DASH_MAX_TICKS = 12;

	// ===== 铁板飓风缺口 =====
	private float vortexGapAngle = 0.0F;
	private static final float VORTEX_GAP_HALF = 50.0F; // 缺口半角（度）

	private static final Predicate<LivingEntity> LIVING_ENTITY_SELECTOR = (p) ->
			p.getMobType() != MobType.UNDEAD && p.attackable();

	public EntityMuHeisen(EntityType<? extends Ravager> type, Level worldIn) {
		super(type, worldIn);
		this.xpReward = 750;
		this.isNonBoss();
		this.isSunSensitive();
		this.attackTimer = 0;
		this.aoeSkillCooldown = 120;
		this.setPathfindingMalus(BlockPathTypes.LAVA, 8.0F);
	}

	protected boolean isSunSensitive() { return true; }

	// ==================== 属性 ====================

	public static AttributeSupplier.Builder prepareAttributes() {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, 500.0D)
				.add(Attributes.MOVEMENT_SPEED, 0.29D)
				.add(Attributes.KNOCKBACK_RESISTANCE, 0.90D)
				.add(Attributes.ATTACK_DAMAGE, 7.0D);
	}

	// ==================== Goals ====================

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(1, new FloatGoal(this));
		this.goalSelector.addGoal(2, new MuAttackGoal(this));
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D) {
			@Override
			public boolean canUse() {
				return EntityMuHeisen.this.getAttckingState() == 0
						&& EntityMuHeisen.this.recoverTimer <= 0
						&& EntityMuHeisen.this.stunTicks <= 0
						&& super.canUse();
			}
			@Override
			public boolean canContinueToUse() {
				return EntityMuHeisen.this.getAttckingState() == 0
						&& EntityMuHeisen.this.recoverTimer <= 0
						&& EntityMuHeisen.this.stunTicks <= 0
						&& super.canContinueToUse();
			}
		});
		this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
		this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
		this.targetSelector.addGoal(1, (new HurtByTargetGoal(this)).setAlertOthers(ZombifiedPiglin.class));
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
		this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, AbstractVillager.class, true));
		this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 0, false, false, LIVING_ENTITY_SELECTOR));
	}

	// ==================== 状态存取 ====================

	public int getAttckingState() { return this.entityData.get(STATE); }

	public void setAttackingState(int time) {
		int prev = this.entityData.get(STATE);
		this.entityData.set(STATE, time);
		if (time != prev) {
			if (time == 1) this.triggerAnim("controller1", "atk1");
			else if (time == 2) this.triggerAnim("controller1", "atk3");
			else if (time == 3) this.triggerAnim("controller1", "atk4");
			else if (time == 4) this.triggerAnim("controller1", "atk2");
		}
	}

	public int getDefendingState() { return this.entityData.get(DEFENDSTATE); }
	public void setDefendingState(int time) { this.entityData.set(DEFENDSTATE, time); }

	public boolean isShieldActive() { return this.entityData.get(SHIELD_ACTIVE); }
	public void setShieldActive(boolean b) { this.entityData.set(SHIELD_ACTIVE, b); }

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(STATE, 0);
		this.entityData.define(DEFENDSTATE, 0);
		this.entityData.define(SHIELD_ACTIVE, false);
	}

	// ==================== NBT ====================

	@Override
	public void readAdditionalSaveData(CompoundTag tag) {
		super.readAdditionalSaveData(tag);
		if (this.hasCustomName()) this.bossInfo.setName(this.getDisplayName());
	}

	@Override
	public void addAdditionalSaveData(CompoundTag tag) { super.addAdditionalSaveData(tag); }

	public void setCustomName(@Nullable Component name) {
		super.setCustomName(name);
		this.bossInfo.setName(this.getDisplayName());
	}

	// ==================== BossBar ====================

	public boolean isNonBoss() { return false; }

	@Override
	public void startSeenByPlayer(ServerPlayer p) {
		super.startSeenByPlayer(p);
		this.bossInfo.addPlayer(p);
	}

	@Override
	public void stopSeenByPlayer(ServerPlayer p) {
		super.stopSeenByPlayer(p);
		this.bossInfo.removePlayer(p);
	}

	// ==================== 声音 ====================

	@Override
	protected SoundEvent getAmbientSound() {
		int co = this.random.nextInt(3);
		if (co == 0) return SoundInit.ENTITY_HESEN_AMBIENT1.get();
		if (co == 1) return SoundInit.ENTITY_HESEN_AMBIENT2.get();
		return SoundInit.ENTITY_HESEN_AMBIENT3.get();
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource src) {
		return this.random.nextInt(2) == 0 ? SoundInit.ENTITY_HESEN_HURT1.get() : SoundInit.ENTITY_HESEN_HURT2.get();
	}

	@Override
	protected SoundEvent getDeathSound() { return SoundInit.ENTITY_HESEN_DEATH.get(); }

	protected float getStandingEyeHeight(Pose pose, EntityDimensions dims) { return 1.5F; }

	// ==================== AI Step ====================

	@Override
	public void aiStep() {
		super.aiStep();
		Random ran = new Random();
		if (ran.nextInt(4) == 1 && this.attr != 2 && this.attr != 3) {
			for (int i = 0; i < 30; i++) {
				float deltaOmega = 1.0f * i;
				Vec3 pos = new Vec3(this.position().x + Math.sin(deltaOmega),
						this.position().y + 0.1f * this.random.nextFloat(),
						this.position().z + Math.cos(deltaOmega));
				this.level().addParticle(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 0, 0, 0);
			}
		}
		if (this.getDefendingState() == 1) this.defend();
	}

	protected void customServerAiStep() {
		super.customServerAiStep();
		Random ran = new Random();
		if (this.isOnFire()) this.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 300, 0, false, false));
		if (this.getHealth() < 300F) {
			this.level().addParticle(ParticleTypes.SMOKE,
					this.position().x + this.random.nextGaussian() * 0.3F,
					this.position().y + this.random.nextGaussian() * 0.3F,
					this.position().z + this.random.nextGaussian() * 0.3F, 0, 0, 0);
		}
		if (this.getHealth() >= 20F && this.getHealth() <= 30F) {
			for (int i = 0; i < 5; i++) this.heal(1.0F * ran.nextFloat());
		}
		if (this.getHealth() >= 160F && this.getHealth() <= 165F) {
			for (int i = 0; i < 4; i++) this.heal(2F * ran.nextFloat());
		}
		if (this.getHealth() > 1F && this.getHealth() < 5F) {
			this.level().explode(null, this.getX(), this.getY(), this.getZ(), this.explosionPower, true, Level.ExplosionInteraction.BLOCK);
		}
		this.bossInfo.setProgress(this.getHealth() / this.getMaxHealth());
	}

	private void defend() {
		if (!this.isAlive()) return;
		Vec3 c = this.getBoundingBox().getCenter();
		for (int j = 0; j < 3; j++)
			for (int i = 0; i < 10; i++) {
				float d = 1.0f * i;
				Vec3 p = new Vec3(c.x + 3 * Math.sin(d), c.y + j, c.z + 3 * Math.cos(d));
				this.level().addParticle(ParticleInit.DEFEND_PARTICLE.get(), p.x, p.y, p.z, 0, 0, 0);
			}
		this.level().gameEvent(this, GameEvent.ENTITY_ROAR, this.getEyePosition());
	}

	// ==================== 动画控制器（triggerableAnim） ====================

	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar data) {
		data.add(new AnimationController<>(this, "controller1", 3, state -> PlayState.STOP)
				.triggerableAnim("atk1", RawAnimation.begin().thenPlay(ANIM_ATK1))
				.triggerableAnim("atk2", RawAnimation.begin().thenPlay(ANIM_ATK2))
				.triggerableAnim("atk3", RawAnimation.begin().thenPlay(ANIM_ATK3))
				.triggerableAnim("atk4", RawAnimation.begin().thenPlay(ANIM_ATK4))
				.triggerableAnim("recover", RawAnimation.begin().thenPlay(ANIM_RECOVER)));
		data.add(new AnimationController(this, "controller", 4, this::predicate));
	}

	private <E extends GeoAnimatable> PlayState predicate(AnimationState<E> event) {
		if (this.stunTicks > 0 || this.recoverTimer > 0) return PlayState.STOP;
		if (this.getAttckingState() != 0) return PlayState.STOP;
		if (event.isMoving()) {
			event.setAndContinue(RawAnimation.begin().thenLoop(ANIM_WALK));
			return PlayState.CONTINUE;
		}
		event.setAndContinue(RawAnimation.begin().thenLoop(ANIM_IDLE));
		return PlayState.CONTINUE;
	}

	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() { return this.factory; }

	// ==================== tick ====================

	@Override
	public void tick() {
		super.tick();
		this.setYRot(this.yBodyRot);
		this.bossInfo.setProgress(this.getHealth() / this.getMaxHealth());

		if (this.level().isClientSide) return;

		// 硬直优先
		if (this.stunTicks > 0) {
			--this.stunTicks;
			this.getNavigation().stop();
			this.setDeltaMovement(this.getDeltaMovement().multiply(0.1, 1, 0.1));
			if (this.getAttckingState() != 0) this.setAttackingState(0);
			return;
		}

		// recover 后摇：冻结移动，播 recover 动画
		if (this.recoverTimer > 0) {
			--this.recoverTimer;
			this.getNavigation().stop();
			this.setDeltaMovement(0, this.getDeltaMovement().y, 0);
			if (this.getAttckingState() != 0) this.setAttackingState(0);
			if (this.recoverTimer == 0) this.setDefendingState(0);
			return;
		}

		if (this.aoeSkillCooldown > 0) --this.aoeSkillCooldown;

		// 护盾计时
		if (this.shieldTicks > 0) {
			--this.shieldTicks;
			if (this.shieldTicks == 0) {
				this.setShieldActive(false);
				this.shieldHits = 0;
			}
		}

		// 冲刺
		if (this.dashing) this.tickDash();

		//金属板撞
		if (!this.thrownPlates.isEmpty()) {
			this.tickThrownPlates();
		}
	}

	// ==================== 冲刺 ====================

	private void startDash(LivingEntity target) {
		if (target == null) return;
		this.dashing = true;
		this.dashTicks = 0;
		this.dashTargetX = target.getX();
		this.dashTargetZ = target.getZ();
	}

	private void tickDash() {
		this.dashTicks++;
		Vec3 to = new Vec3(this.dashTargetX - this.getX(), 0, this.dashTargetZ - this.getZ());
		double dist = to.length();
		if (dist < 1.5 || this.dashTicks > DASH_MAX_TICKS) {
			this.dashing = false;
			this.setDeltaMovement(0, this.getDeltaMovement().y, 0);
			return;
		}
		Vec3 dir = to.normalize().scale(0.6);
		this.setDeltaMovement(dir.x, this.getDeltaMovement().y, dir.z);
		this.hurtMarked = true;
	}

	/**
	 * 每 tick 检测已投掷的金属板是否碰到生物。
	 * 碰到 → 造成伤害 + 挂虚弱 + 移除金属板（或让它继续飞）。
	 */
	private void tickThrownPlates() {
		if (this.level().isClientSide) return;

		// 清理已失效的金属板
		this.thrownPlates.removeIf(fb -> !fb.isAlive() || fb.isRemoved());

		// 冷却递减
		this.plateHitCooldown.entrySet().removeIf(e -> {
			int v = e.getValue() - 1;
			if (v <= 0) return true;
			e.setValue(v);
			return false;
		});

		for (EntityFallingBlock plate : this.thrownPlates) {
			if (!plate.isAlive()) continue;

			AABB plateBox = plate.getBoundingBox().inflate(0.5);
			List<LivingEntity> hits = this.level().getEntitiesOfClass(LivingEntity.class, plateBox, PIGEON_AREA);

			for (LivingEntity living : hits) {
				if (living == this || this.isAlliedTo(living)) continue;

				// 同一生物冷却内只挂一次
				if (this.plateHitCooldown.containsKey(living.getUUID())) continue;

				// 伤害：基于 Boss 攻击力
				float damage = (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE) * 0.8F;
				living.hurt(this.damageSources().mobAttack(this), damage);

				// 虚弱效果
				living.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1, true, true));

				// 击退
				Vec3 knock = living.position().subtract(plate.position()).normalize().scale(0.5);
				living.setDeltaMovement(living.getDeltaMovement().add(knock.x, 0.2, knock.z));
				living.hurtMarked = true;

				// 冷却
				this.plateHitCooldown.put(living.getUUID(), 100);

				// 粒子 + 音效
				if (this.level() instanceof ServerLevel server) {
					server.sendParticles(ParticleTypes.CRIT,
							living.getX(), living.getY() + 1.0, living.getZ(),
							8, 0.2, 0.2, 0.2, 0.1);
				}
				this.playSound(SoundEvents.ANVIL_LAND, 0.8F, 1.2F);

				// 金属板命中后消失（可选：不消失让它继续飞）
				plate.discard();
				break;
			}
		}
	}

	// ==================== 金属板护盾 ====================

	private void spawnMetalShield(LivingEntity target) {
		this.setShieldActive(true);
		this.shieldTicks = 60;
		this.shieldHits = 0;
		if (this.level() instanceof ServerLevel server) {
			for (int i = 0; i < 8; i++) {
				double angle = i * Math.PI / 4;
				double px = this.getX() + Math.cos(angle) * 3.0;
				double pz = this.getZ() + Math.sin(angle) * 3.0;
				EntityFallingBlock fb = new EntityFallingBlock(this.level(), px, this.getY() + 2.0, pz,
						BlockInit.FACT_IRON_BLOCK.get().defaultBlockState(), 20);
				server.addFreshEntity(fb);
			}
		}
		this.playSound(SoundEvents.IRON_GOLEM_HURT, 1.5F, 0.6F);
	}

	private void throwMetalPlates(LivingEntity target) {
		if (target == null) return;
		if (this.level() instanceof ServerLevel server) {
			this.thrownPlates.clear();  // 清掉上一轮的
			for (int i = 0; i < 8; i++) {
				double angle = i * Math.PI / 4;
				double px = this.getX() + Math.cos(angle) * 3.0;
				double pz = this.getZ() + Math.sin(angle) * 3.0;
				EntityFallingBlock fb = new EntityFallingBlock(this.level(), px, this.getY() + 4.0, pz,
						BlockInit.FACT_IRON_BLOCK.get().defaultBlockState(), 20);
				Vec3 dir = target.position().subtract(px, this.getY() + 4.0, pz).normalize().scale(1.2);
				fb.setDeltaMovement(dir.x, 0.5, dir.z);
				server.addFreshEntity(fb);
				this.thrownPlates.add(fb);
			}
		}
		this.playSound(SoundEvents.ARROW_SHOOT, 1.5F, 0.7F);
	}

	// ==================== 铁板飓风 ====================

	private void tickVortex(LivingEntity target) {
		this.vortexGapAngle = (this.vortexGapAngle + 12.0F) % 360.0F;
		if (this.level() instanceof ServerLevel server) {
			for (int i = 0; i < 6; i++) {
				double angle = Math.toRadians(this.vortexGapAngle + i * 60);
				double px = this.getX() + Math.cos(angle) * 4.0;
				double pz = this.getZ() + Math.sin(angle) * 4.0;
				server.sendParticles(ParticleTypes.SWEEP_ATTACK, px, this.getY() + 1.0, pz, 1, 0, 0, 0, 0);
			}
		}
	}

	private void vortexDamage(LivingEntity target) {
		for (LivingEntity living : this.level().getEntitiesOfClass(LivingEntity.class,
				this.getBoundingBox().inflate(5.0), PIGEON_AREA)) {
			if (living == this || this.isAlliedTo(living)) continue;
			Vec3 to = living.position().subtract(this.position());
			double angle = Math.toDegrees(Math.atan2(to.z, to.x));
			double diff = Math.abs(Mth.wrapDegrees((float) (angle - this.vortexGapAngle)));
			if (diff < VORTEX_GAP_HALF) continue; // 在缺口内，不受伤
			living.hurt(this.damageSources().mobAttack(this), living.getMaxHealth() * 0.25F + 4.0F);
		}
	}

	// ==================== 弱点 ====================

	@Override
	public boolean hurt(DamageSource source, float amount) {
		boolean hurt = super.hurt(source, amount);
		if (!hurt || this.level().isClientSide) return hurt;

		// 护盾期间：只有命中"弱点"才能破盾
		if (this.isShieldActive() && source.getEntity() instanceof LivingEntity living) {
			if (isWeakPointHit(living)) {
				this.shieldHits++;
				if (this.shieldHits >= SHIELD_MAX_HITS) {
					this.setShieldActive(false);
					this.shieldTicks = 0;
					this.shieldHits = 0;
					this.playSound(SoundEvents.ANVIL_BREAK, 1.5F, 0.7F);
				}
			}
		}

		// 受击概率硬直
		if (amount >= 8.0F && this.random.nextInt(4) == 0 && this.getAttckingState() == 0) {
			this.stunTicks = STUN_TICKS;
			this.triggerAnim("controller1", "recover");
		}
		return hurt;
	}

	/** 弱点：模型 Head 下方、Body 前侧。这里用"玩家在正前方且高度接近"近似。 */
	private boolean isWeakPointHit(LivingEntity attacker) {
		Vec3 look = this.getLookAngle();
		Vec3 to = attacker.position().subtract(this.position());
		to = new Vec3(to.x, 0, to.z);
		if (to.lengthSqr() < 1e-4) return false;
		Vec3 flatLook = new Vec3(look.x, 0, look.z);
		if (flatLook.lengthSqr() < 1e-4) return false;
		double dot = flatLook.normalize().dot(to.normalize());
		// 正前方 60° 内算命中弱点
		return dot > 0.5;
	}

	// ==================== 攻击 Goal（triggerableAnim + 时间轴对齐） ====================

	static class MuAttackGoal extends Goal {
		private final EntityMuHeisen mob;
		private int timer = 0;

		MuAttackGoal(EntityMuHeisen mob) { this.mob = mob; }

		@Override
		public boolean canUse() { return this.mob.getTarget() != null; }

		@Override
		public void start() { this.mob.setAggressive(true); }

		@Override
		public void stop() {
			this.mob.setAggressive(false);
			this.mob.setAttackingState(0);
			this.mob.dashing = false;
			this.timer = -5;
		}

		@Override
		public void tick() {
			if (this.mob.stunTicks > 0 || this.mob.recoverTimer > 0) {
				this.mob.setAttackingState(0);
				return;
			}

			LivingEntity target = this.mob.getTarget();
			if (target == null) { this.mob.setAttackingState(0); return; }

			++this.timer;
			int state = this.mob.getAttckingState();
			Random rand = new Random();
			float f = (float) Mth.atan2(target.getZ() - this.mob.getZ(), target.getX() - this.mob.getX());

			// ===== 选招 =====
			if (this.timer == 5) {
				int roll = rand.nextInt(100);
				if (roll < 35) {
					// 巨臂挥击：冲刺 + 挥击
					this.mob.setAttackingState(1);
					this.mob.startDash(target);
				} else if (roll < 65) {
					// 金属板防御与投掷
					this.mob.setAttackingState(2);
					this.mob.spawnMetalShield(target);
				} else if (roll < 85) {
					// 铁板飓风
					this.mob.setAttackingState(3);
					this.mob.vortexGapAngle = 0;
				} else {
					// AOE 药水
					if (this.mob.aoeSkillCooldown <= 0) {
						this.mob.setAttackingState(4);
						this.mob.aoeSkillCooldown = 120;
					} else {
						this.mob.setAttackingState(1);
						this.mob.startDash(target);
					}
				}
			}

			state = this.mob.getAttckingState();

			// ===== STATE 1：巨臂挥击 =====
			if (state == 1) {
				// 冲刺中不冻结
				if (!this.mob.dashing) {
					this.mob.getNavigation().stop();
					this.mob.setDeltaMovement(0, this.mob.getDeltaMovement().y, 0);
				}
				// 动画 attack 长度 3.5s = 70 tick；命中帧在 2.0s = 40 tick
				if (this.timer == 40) {
					for (LivingEntity lvt : this.mob.level().getEntitiesOfClass(LivingEntity.class,
							this.mob.getBoundingBox().inflate(3.0), PIGEON_AREA)) {
						if (lvt == this.mob || this.mob.isAlliedTo(lvt)) continue;
						if (lvt instanceof Player p && p.isBlocking()) continue; // 格挡免伤
						lvt.hurt(this.mob.damageSources().mobAttack(this.mob),
								(float) this.mob.getAttributeValue(Attributes.ATTACK_DAMAGE) * 1.8F);
						lvt.knockback(0.8, this.mob.getX() - lvt.getX(), this.mob.getZ() - lvt.getZ());
					}
				}
			}

			// ===== STATE 2：金属板防御与投掷 =====
			if (state == 2) {
				this.mob.getNavigation().stop();
				this.mob.setDeltaMovement(0, this.mob.getDeltaMovement().y, 0);
				// attack2 动画 3.5s = 70 tick；投掷帧在 2.0s = 40 tick
				if (this.timer == 40) {
					this.mob.throwMetalPlates(target);
				}
			}

			// ===== STATE 3：铁板飓风 =====
			if (state == 3) {
				this.mob.getNavigation().stop();
				this.mob.setDeltaMovement(0, this.mob.getDeltaMovement().y, 0);
				this.mob.tickVortex(target);
				// attack3 动画 4.5s = 90 tick；伤害帧 1.5s~3.5s = 30~70 tick
				if (this.timer >= 30 && this.timer <= 70 && this.timer % 5 == 0) {
					this.mob.vortexDamage(target);
				}
			}

			// ===== STATE 4：AOE 药水 =====
			if (state == 4) {
				this.mob.getNavigation().stop();
				// aoe 动画 5s = 100 tick；火焰帧 2.0s = 40 tick，吸引帧 3.0s = 60 tick
				if (this.timer == 40) {
					for (int l = 0; l < 16; l++) {
						float f1 = f + l * (float) Math.PI * 0.4F;
						for (int y = 0; y < 5; y++) this.mob.performRangedAttack(target, f);
						this.mob.level().playLocalSound(this.mob.getX(), this.mob.getY(), this.mob.getZ(),
								SoundInit.ENTITY_HESEN_AMBIENT3.get(), SoundSource.HOSTILE, 1.0F, 1.0F, true);
					}
				}
				if (this.timer == 60) {
					for (LivingEntity lvt : this.mob.level().getEntitiesOfClass(LivingEntity.class,
							this.mob.getBoundingBox().inflate(10.0), PIGEON_AREA)) {
						if (lvt == this.mob || this.mob.isAlliedTo(lvt)) continue;
						lvt.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 60, 1));
						Vec3 dir = new Vec3(this.mob.getX() - lvt.getX(), this.mob.getY() - lvt.getY(), this.mob.getZ() - lvt.getZ()).normalize();
						lvt.push(dir.x * 0.15, dir.y * 0.15, dir.z * 0.15);
					}
				}
			}

			// ===== 收尾：进入 recover 后摇 =====
			int endTick = switch (state) {
				case 1 -> 70;   // attack 3.5s
				case 2 -> 70;   // attack2 3.5s
				case 3 -> 90;   // attack3 4.5s
				case 4 -> 100;  // aoe 5s
				default -> 0;
			};
			if (endTick > 0 && this.timer >= endTick) {
				this.mob.setAttackingState(0);
				this.mob.recoverTimer = RECOVER_TICKS;
				this.mob.triggerAnim("controller1", "recover");
				this.timer = -5;
			}

			if (state != 3) this.mob.lookAt(target, 30.0F, 30.0F);
		}
	}

	// ==================== 原有辅助方法 ====================

	private static final Predicate<Entity> PIGEON_AREA = (e) -> e.isAlive() && !(e instanceof EntityMuHeisen);

	public void performRangedAttack(LivingEntity target, float yaw) {
		Vec3 v = target.getDeltaMovement();
		double d0 = target.getX() + v.x - this.getX();
		double d1 = target.getEyeY() - 3.1F - this.getY();
		double d2 = target.getZ() + v.z - this.getZ();
		double d3 = Math.sqrt(d0 * d0 + d2 * d2);
		net.minecraft.world.entity.projectile.ThrownPotion potion =
				new net.minecraft.world.entity.projectile.ThrownPotion(this.level(), this);
		potion.setItem(net.minecraft.world.item.alchemy.PotionUtils.setPotion(
				new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.SPLASH_POTION),
				com.joy187.re8joymod.init.PotionInit.DEADLY_POTION.get()));
		potion.setXRot(potion.getXRot() + 20.0F);
		potion.shoot(d0, d1 + d3 * 0.2D, d2, 0.75F, 8.0F);
		if (!this.isSilent()) this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
				SoundInit.ENTITY_HESEN_AMBIENT3.get(), this.getSoundSource(), 1.0F, 0.8F + this.random.nextFloat() * 0.4F);
		this.level().addFreshEntity(potion);
	}

	@Override
	public boolean doHurtTarget(Entity target) {
		Random ran = new Random();
		int co = ran.nextInt(4);
		this.level().broadcastEntityEvent(this, (byte) 4);
		float f = (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE);
		float f1 = (int) f > 0 ? f / 2.0F + this.random.nextInt((int) f) : f;
		boolean flag = target.hurt(this.damageSources().mobAttack(this), f1);
		if (flag) {
			target.setDeltaMovement(target.getDeltaMovement().add(0, 0.4, 0));
			this.doEnchantDamageEffects(this, target);
		}
		this.playSound(SoundEvents.IRON_GOLEM_ATTACK, 1.0F, 1.0F);
		return flag;
	}
}