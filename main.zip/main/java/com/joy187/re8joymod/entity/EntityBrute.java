package com.joy187.re8joymod.entity;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.level.Level;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationState;;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;

public class EntityBrute extends EntityUrias implements GeoEntity{
	private AnimatableInstanceCache factory = GeckoLibUtil.createInstanceCache(this);
	public static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(EntityBrute.class,
			EntityDataSerializers.INT);

	public EntityBrute(EntityType<? extends Ravager> type, Level worldIn) {
		super(type, worldIn);
		this.xpReward = 100;
		//SpawnPlacements.register(EntityInit.FRANK1.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules);
	}

	public static AttributeSupplier.Builder prepareAttributes() {
		return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 110.0D).
				add(Attributes.MOVEMENT_SPEED, 0.23D).
				add(Attributes.FOLLOW_RANGE, 30.0D).
				add(Attributes.ARMOR, 12.0D).
				add(Attributes.ARMOR_TOUGHNESS, 30.0D).
				add(Attributes.KNOCKBACK_RESISTANCE, 0.85D).
				add(Attributes.ATTACK_DAMAGE, 24.0D);
	}

	protected <E extends GeoAnimatable> PlayState predicate(AnimationState<E> event) {
		int atk = this.entityData.get(STATE);
		if (atk == 1 || atk == 2 || atk == 3) {
			return PlayState.STOP;
		}

		if(this.isDeadOrDying()){
			event.setAndContinue(RawAnimation.begin().thenPlay("animation.brute.death"));
			return PlayState.CONTINUE;
		}

		if (event.isMoving()) {
			event.setAndContinue(RawAnimation.begin().thenPlay("animation.brute.walk"));
			return PlayState.CONTINUE;
		}


		event.setAndContinue(RawAnimation.begin().thenPlay("animation.brute.idle"));
		return PlayState.CONTINUE;
	}


	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar data) {
		AnimationController<?> attackController =
				new AnimationController<>(this, "controller1", 3, state -> PlayState.STOP)
						.triggerableAnim("slash", RawAnimation.begin().thenPlay("animation.brute.attack1"))
						.triggerableAnim("heavy", RawAnimation.begin().thenPlay("animation.brute.attack2"));
		data.add(attackController);
		data.add(new AnimationController<>(this, "controller", 8, this::predicate));
	}



	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {
		return this.factory;
	}

	public int getAttckingState() {
		return this.entityData.get(STATE);
	}


	/** Trigger one-shot attack animation via GeckoLib triggerAnim. */
	protected void startAttackAnim(int state) {
		if (state == 1) {
			this.triggerAnim("controller1", "slash");
		} else if (state == 2) {
			this.triggerAnim("controller1", "heavy");
		}
	}

	public void setAttackingState(int time) {
		int prev = this.entityData.get(STATE);
		this.entityData.set(STATE, time);
		if ((time == 1 || time == 2 || time == 3) && prev != time) {
			this.startAttackAnim(time);
		}
	}

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(STATE, 0);
	}


}
