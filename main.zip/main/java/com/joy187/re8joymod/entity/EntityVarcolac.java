package com.joy187.re8joymod.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.util.Mth;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class EntityVarcolac extends EntityLycan implements GeoEntity {

	private AnimatableInstanceCache factory = GeckoLibUtil.createInstanceCache(this);

	// 冲撞技能变量
	private int attackTimer;
	private float chargeYaw;
	private final Set<UUID> chargeHit = new HashSet<>();

	// 🔥 硬直计时器
	private int recoverTimer = 0;

	// 🔥 狂暴系统变量
	private boolean isNightRage = false;
	private static final UUID NIGHT_SPEED_UUID = UUID.fromString("8f4a9d2b-1c3e-4d5f-6a7b-8c9d0e1f2a3b");
	private static final UUID NIGHT_DAMAGE_UUID = UUID.fromString("5a3d8b2c-6e1f-4a9b-3c7d-2e8f1a9b0c4d");

	public EntityVarcolac(EntityType<? extends Monster> type, Level worldIn) {
		super(type, worldIn);
		this.xpReward = 40;
	}

	public static AttributeSupplier.Builder prepareAttributes() {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, 100.0D)
				.add(Attributes.MOVEMENT_SPEED, 0.28D)
				.add(Attributes.ATTACK_DAMAGE, 8.5D)
				.add(Attributes.KNOCKBACK_RESISTANCE, 0.5D)
				.add(Attributes.FOLLOW_RANGE, 32.0D);
	}

	// ==========================================
	// 1. AI 目标注册
	// ==========================================
	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(4, new MeleeAttackGoal(this, 1.0D, true));
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D));

		this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false,
				(entity) -> {
					if (entity instanceof Monster) return false; // 不打同类怪物
					if (entity instanceof Player player && (player.isCreative() || player.isSpectator())) return false;
					return true;
				}));
	}

	@Override
	protected void updateControlFlags() {
		// 🔥 只有在冲撞(2)和硬直(3)期间，才锁死移动
		if (this.entityData.get(STATE) == 2 || this.entityData.get(STATE) == 3) {
			this.goalSelector.setControlFlag(Goal.Flag.MOVE, false);
			this.goalSelector.setControlFlag(Goal.Flag.JUMP, false);
			this.goalSelector.setControlFlag(Goal.Flag.LOOK, false);
			this.goalSelector.setControlFlag(Goal.Flag.TARGET, true);
			return;
		}
		super.updateControlFlags();
	}

	// ==========================================
	// 2. 核心 Tick 与 狂暴/粒子逻辑
	// ==========================================
	@Override
	public void tick() {
		super.tick();

		// 🔥 客户端：生成血红粒子 (解决同步问题)
		if (this.level().isClientSide) {
			if (this.level().isNight()) {
				if (this.tickCount % 2 == 0) {
					double x = this.getX() + (this.random.nextDouble() - 0.5D) * this.getBbWidth();
					double y = this.getY() + this.random.nextDouble() * this.getBbHeight();
					double z = this.getZ() + (this.random.nextDouble() - 0.5D) * this.getBbWidth();
					// 使用 DUST 粒子并赋予红色，看起来像血雾
					this.level().addParticle(ParticleTypes.CRIMSON_SPORE, x, y, z, 0.8D, 0.0D, 0.0D);
				}
			}
			return;
		}

		// 🔥 服务端：检查是否在夜晚
		this.checkNightRage();

		// 驱动冲撞逻辑
		this.tickChargeAttack();

		// 🔥 修复硬直倒计时重置逻辑
		if (this.recoverTimer > 0) {
			this.recoverTimer--;
			if (this.recoverTimer == 0) {
				this.setAttackingState(0);
				this.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
			}
		}
	}

	private void checkNightRage() {
		boolean isNight = this.level().isNight();
		if (isNight != this.isNightRage) {
			this.isNightRage = isNight;
			AttributeInstance speedAttr = this.getAttribute(Attributes.MOVEMENT_SPEED);
			AttributeInstance dmgAttr = this.getAttribute(Attributes.ATTACK_DAMAGE);

			if (speedAttr != null && dmgAttr != null) {
				speedAttr.removeModifier(NIGHT_SPEED_UUID);
				dmgAttr.removeModifier(NIGHT_DAMAGE_UUID);

				if (this.isNightRage) {
					speedAttr.addTransientModifier(new AttributeModifier(NIGHT_SPEED_UUID, "Night Speed Boost", 0.3D, AttributeModifier.Operation.MULTIPLY_TOTAL));
					dmgAttr.addTransientModifier(new AttributeModifier(NIGHT_DAMAGE_UUID, "Night Damage Boost", 0.5D, AttributeModifier.Operation.MULTIPLY_TOTAL));
				}
			}
		}
	}

	// ==========================================
	// 3. 普通攻击与硬直（🔥 已优化：平A不再锁死移动）
	// ==========================================
	public boolean doHurtTarget(Entity entityIn) {
		// 如果正在冲撞或硬直，不能平A
		if (this.entityData.get(STATE) != 0 || this.attackTimer > 0) {
			return false;
		}

		boolean flag = super.doHurtTarget(entityIn);
		if (!flag) {
			this.playAttackAnimation = false;
			return false; // 没打中，不触发任何后续动作
		} else {
			if (entityIn instanceof LivingEntity living) {
				float f = this.level().getCurrentDifficultyAt(this.blockPosition()).getEffectiveDifficulty();
				int harmDuration = this.isNightRage ? 200 : 100;
				int slowDuration = this.isNightRage ? 80 : 40;

				living.addEffect(new MobEffectInstance(MobEffects.HARM, harmDuration * (int) f, 0, true, true));
				living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, slowDuration, 2));
			}

			this.playAttackAnimation = true;

			if (this.random.nextBoolean()) {
				this.triggerAnim("controller1", "attack1");
			} else {
				this.triggerAnim("controller1", "attack2");
			}

			// 🔥 普通攻击不再进入严重的罚站硬直，而是流畅地继续咬！
			// 如果你想让它普通攻击有收招后摇，可以把下面两行注释取消
			// this.recoverTimer = 5;
			// this.setAttackingState(3);

			return true;
		}
	}

	// ==========================================
	// 4. 高速冲撞技能 (冲撞后依然有硬直)
	// ==========================================
	private void tickChargeAttack() {
		LivingEntity target = this.getTarget();
		if (this.entityData.get(STATE) != 2 && this.attackTimer <= 0) {
			if (this.attackTimer < 0) {
				if (target != null) ++this.attackTimer;
				return;
			}
			if (target == null || this.distanceToSqr(target) > 36.0D) {
				return;
			}
			int chargeChance = this.isNightRage ? 10 : 30;
			if (this.random.nextInt(chargeChance) == 0) {
				this.attackTimer = 1;
			} else {
				return;
			}
		}

		++this.attackTimer;
		if (this.attackTimer == 1) {
			if (target != null) {
				this.lookAt(target, 180.0F, 180.0F);
			}
			this.chargeYaw = this.getYRot();
			this.chargeHit.clear();
			this.getNavigation().stop();
			this.setAttackingState(2);
			this.triggerAnim("controller1", "charge");
		}

		if (this.entityData.get(STATE) == 2 && this.attackTimer >= 5 && this.attackTimer <= 15) {
			this.tickCharge();
		} else if (this.entityData.get(STATE) == 2) {
			this.holdChargePose();
		}

		if (this.attackTimer >= 30) {
			// 🔥 只有冲撞完毕后，才会进入较长的硬直惩罚（白天 1.2秒 / 夜晚 0.6秒）
			this.recoverTimer = this.isNightRage ? 12 : 24;
			this.setAttackingState(3);
			this.triggerAnim("controller1", "recover");
			this.attackTimer = -15;
			this.chargeHit.clear();
		}
	}

	private void holdChargePose() {
		this.getNavigation().stop();
		this.setSpeed(0.0F);
		Vec3 motion = this.getDeltaMovement();
		this.setDeltaMovement(0.0D, motion.y, 0.0D);
		this.setYRot(this.chargeYaw);
		this.setYBodyRot(this.chargeYaw);
		this.setYHeadRot(this.chargeYaw);
	}

	private void tickCharge() {
		this.getNavigation().stop();
		Vec3 before = this.position();
		float yaw = this.chargeYaw * ((float) Math.PI / 180F);

		double speed = this.isNightRage ? 0.55D : 0.42D;
		this.move(MoverType.SELF, new Vec3(-Mth.sin(yaw) * speed, 0.0D, Mth.cos(yaw) * speed));
		this.setYRot(this.chargeYaw);
		this.setYBodyRot(this.chargeYaw);
		this.setYHeadRot(this.chargeYaw);

		Vec3 delta = this.position().subtract(before);
		if (delta.lengthSqr() < 1.0E-6D) return;

		double myVolume = boxVolume(this.getBoundingBox());
		AABB box = this.getBoundingBox().inflate(0.35D);

		for (Entity entity : this.level().getEntities(this, box, candidate -> candidate.isAlive() && candidate.isPushable())) {
			if (boxVolume(entity.getBoundingBox()) >= myVolume) continue;

			entity.setPos(entity.getX() + delta.x, entity.getY() + delta.y, entity.getZ() + delta.z);
			entity.setDeltaMovement(delta.x, entity.getDeltaMovement().y, delta.z);
			entity.hurtMarked = true;

			if (entity instanceof LivingEntity living && this.chargeHit.add(living.getUUID())) {
				living.hurt(this.damageSources().mobAttack(this), (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE));
				living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 3));

				if (this.level() instanceof ServerLevel serverLevel) {
					serverLevel.sendParticles(ParticleTypes.DAMAGE_INDICATOR, living.getX(), living.getY() + 1.0D, living.getZ(), 10, 0.5D, 0.5D, 0.5D, 0.1D);
				}
			}
		}
	}

	private static double boxVolume(AABB box) {
		return box.getXsize() * box.getYsize() * box.getZsize();
	}

	public void setAttackingState(int time) {
		this.entityData.set(STATE, time);
	}

	// ==========================================
	// 5. 动画控制器
	// ==========================================
	private <E extends GeoAnimatable> PlayState predicate(AnimationState<E> event) {
		if (this.entityData.get(STATE) != 0) {
			return PlayState.STOP;
		}
		if (this.dead || this.getHealth() < 0.01 || this.isDeadOrDying()) {
			event.setAndContinue(RawAnimation.begin().thenPlay("animation.varcolac.death"));
			return PlayState.CONTINUE;
		}

		if (event.isMoving()) {
			event.setAndContinue(RawAnimation.begin().thenPlay("animation.varcolac.walk"));
			return PlayState.CONTINUE;
		}
		event.setAndContinue(RawAnimation.begin().thenPlay("animation.varcolac.idle"));
		return PlayState.CONTINUE;
	}

	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar data) {
		AnimationController<?> attackController =
				new AnimationController<>(this, "controller1", 3, state -> PlayState.STOP)
						.triggerableAnim("attack1", RawAnimation.begin().thenPlay("animation.varcolac.attack"))
						.triggerableAnim("attack2", RawAnimation.begin().thenPlay("animation.varcolac.attack2"))
						.triggerableAnim("charge", RawAnimation.begin().thenPlay("animation.varcolac.charge"))
						.triggerableAnim("recover", RawAnimation.begin().thenPlay("animation.varcolac.recover"));

		data.add(attackController);
		data.add(new AnimationController<>(this, "controller", 5, this::predicate));
	}

	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {
		return this.factory;
	}

	// ==========================================
	// 6. 安全清理逻辑
	// ==========================================
	@Override
	protected void customServerAiStep() {
		super.customServerAiStep();
		BlockPos blockpos = this.blockPosition();
		FluidState fluidstate = this.level().getFluidState(blockpos);
		if (fluidstate.is(FluidTags.WATER) && this.getHealth() >= 99.99F && this.getHealth() <= 100.0F) {
			this.discard();
		}
		if (fluidstate.is(FluidTags.LAVA) && this.getHealth() >= 99.99F && this.getHealth() <= 100.0F) {
			this.discard();
		}
	}
}