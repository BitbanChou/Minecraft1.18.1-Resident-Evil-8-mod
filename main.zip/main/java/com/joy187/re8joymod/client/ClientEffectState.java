package com.joy187.re8joymod.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class ClientEffectState {
    private ClientEffectState() {}

    public static int renderExecute = 0;

    public static void triggerExecute(int ticks) {
        renderExecute = ticks;
    }

}
