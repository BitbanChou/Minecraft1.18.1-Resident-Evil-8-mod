package com.joy187.re8joymod.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

@OnlyIn(Dist.CLIENT)
public final class KeyBindInit {
    public static final String KEYCAT = "key.re8.category";
    public static final String shootKey = "key.re8.shootKey";

    public static final KeyMapping KEY_FIRE = new KeyMapping(
            shootKey,
            KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_V,
            KEYCAT);

    private KeyBindInit() {
    }
}