package com.joy187.re8joymod.items;

import java.util.List;
import java.util.function.Predicate;

import com.joy187.re8joymod.entity.EntityObBoat;
import com.joy187.re8joymod.init.EntityInit;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class ItemObBoat extends Item {

    private static final Predicate<Entity> ENTITY_PREDICATE =
            EntitySelector.NO_SPECTATORS.and(Entity::isPickable);

    public ItemObBoat() {
        super(new Properties().stacksTo(1).fireResistant());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack itemstack = player.getItemInHand(hand);

        // 1. 从玩家视角做射线检测，包含流体（这样对着熔岩也能放船）
        HitResult hitresult = getPlayerPOVHitResult(level, player, ClipContext.Fluid.ANY);

        if (hitresult.getType() == HitResult.Type.MISS) {
            return InteractionResultHolder.pass(itemstack);
        }

        // 2. 防止穿过实体放置（原版逻辑）
        Vec3 viewVec = player.getViewVector(1.0F);
        List<Entity> list = level.getEntities(player,
                player.getBoundingBox().expandTowards(viewVec.scale(5.0D)).inflate(1.0D),
                ENTITY_PREDICATE);
        if (!list.isEmpty()) {
            Vec3 eye = player.getEyePosition();
            for (Entity entity : list) {
                AABB aabb = entity.getBoundingBox().inflate(entity.getPickRadius());
                if (aabb.contains(eye)) {
                    return InteractionResultHolder.pass(itemstack);
                }
            }
        }

        // 3. 命中方块/流体，尝试生成船
        if (hitresult.getType() == HitResult.Type.BLOCK) {
            EntityObBoat boat = new EntityObBoat(EntityInit.OBBOAT.get(), level);

            // 放到命中点
            boat.setPos(hitresult.getLocation().x,
                    hitresult.getLocation().y,
                    hitresult.getLocation().z);

            // 朝向玩家
            boat.setYRot(player.getYRot());

            // 4. 碰撞检测：位置放不下就失败
            if (!level.noCollision(boat, boat.getBoundingBox())) {
                return InteractionResultHolder.fail(itemstack);
            }

            // 5. 只在服务端真正添加实体
            if (!level.isClientSide) {
                level.addFreshEntity(boat);
                level.gameEvent(player, GameEvent.ENTITY_PLACE, hitresult.getLocation());

                // 放置音效（可选）
                level.playSound(null, boat.getX(), boat.getY(), boat.getZ(),
                        SoundEvents.WOOD_PLACE, SoundSource.BLOCKS,
                        1.0F, 0.8F + level.random.nextFloat() * 0.4F);

                if (!player.getAbilities().instabuild) {
                    itemstack.shrink(1);
                }
            }

            player.awardStat(Stats.ITEM_USED.get(this));
            return InteractionResultHolder.sidedSuccess(itemstack, level.isClientSide());
        }

        return InteractionResultHolder.pass(itemstack);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.obboat"));
        // 如果需要 Shift 展开提示，可以用：
        // if (Screen.hasShiftDown()) {
        //     tooltip.add(Component.translatable("tooltip.obboat.desc"));
        // } else {
        //     tooltip.add(Component.translatable("tooltip.obboat.hold_shift"));
        // }
    }
}