package com.joy187.re8joymod.items;

import com.joy187.re8joymod.entity.EntityAxeman;
import com.joy187.re8joymod.entity.EntityHeisen;
import com.joy187.re8joymod.entity.EntityMoreau;
import com.joy187.re8joymod.entity.EntityUriass;
import com.joy187.re8joymod.init.BlockInit;
import com.joy187.re8joymod.init.EntityInit;
import com.joy187.re8joymod.init.ParticleInit;
import com.joy187.re8joymod.util.CommonFunctions;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class ItemRiser2 extends PickaxeItem {

    public ItemRiser2(Tier toolMaterial, int attackDamage, float attackSpeed, Properties itemProperties) {
        super(toolMaterial, attackDamage, attackSpeed, itemProperties);
    }

    @Override
    public boolean canAttackBlock(BlockState blockstate, Level level, BlockPos blockpos, Player playerIn) {
        ItemStack itemstack = playerIn.getMainHandItem();

        if (blockstate.is(BlockInit.MUCUS_BLOCK.get())) {
            // 粒子表现：客户端侧
            if (level.isClientSide) {
                for (float i = 1; i <= 3; i += 0.5f)
                    CommonFunctions.spawnHexAround(ParticleTypes.ITEM_SLIME, level, blockpos, i);
                level.addParticle(ParticleTypes.AMBIENT_ENTITY_EFFECT,
                        playerIn.getX() + 5 * (level.random.nextDouble() - 0.5D) * playerIn.getBbWidth(),
                        playerIn.getY() + 0.1D,
                        playerIn.getZ() + 4 * (level.random.nextDouble() - 0.5D) * playerIn.getBbWidth(),
                        playerIn.position().x * -0.2D, 0.1D, playerIn.position().z * -0.2D);
            }

            // 决策 + 实体生成 + 扣物品：服务端
            if (!level.isClientSide) {
                if (level.random.nextInt(2) == 1) {
                    EntityMoreau e = new EntityMoreau(EntityInit.MOREAU.get(), playerIn.level());
                    e.moveTo(blockpos.getX(), blockpos.getY(), blockpos.getZ(),
                            playerIn.getYRot(), playerIn.getXRot());
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 5, false, false));
                    e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 5, false, false));
                    playerIn.level().addFreshEntity(e);
                    CommonFunctions.spawnFireFlame(e, ParticleInit.FLAME_PARTICLE.get());

                    level.playSound(null, playerIn.getX(), playerIn.getY(), playerIn.getZ(),
                            SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.4F,
                            1.4F / (playerIn.getRandom().nextFloat() * 0.4F + 1.2F) + 0.5F);
                } else {
                    playerIn.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 1000));
                }

                // 原逻辑：无论成败都扣。若只想成功时扣，移进上面的 if 分支。
                if (!playerIn.isCreative()) itemstack.shrink(1);
            }
        } else if (blockstate.is(BlockInit.FACTW_BLOCK.get())) {
            if (level.isClientSide) {
                for (float i = 1; i <= 3; i += 0.5f)
                    CommonFunctions.spawnHexAround(ParticleTypes.FLAME, level, blockpos, i);
                level.addParticle(ParticleTypes.LARGE_SMOKE,
                        playerIn.getX(), playerIn.getY(), playerIn.getZ(),
                        playerIn.position().x, playerIn.position().y, playerIn.position().z);
            }

            if (!level.isClientSide) {
                if (level.random.nextInt(2) == 1) {
                    EntityHeisen e = new EntityHeisen(EntityInit.HEISEN.get(), playerIn.level());
                    e.moveTo(blockpos.getX(), blockpos.getY(), blockpos.getZ(),
                            playerIn.getYRot(), playerIn.getXRot());
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 5, false, false));
                    e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 5, false, false));
                    playerIn.level().addFreshEntity(e);
                    CommonFunctions.spawnFireFlame(e, ParticleInit.FLAME_PARTICLE.get());

                    level.playSound(null, playerIn.getX(), playerIn.getY(), playerIn.getZ(),
                            SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.4F,
                            1.4F / (playerIn.getRandom().nextFloat() * 0.4F + 1.2F) + 0.5F);
                } else {
                    // 注意：ExplosionInteraction.NONE 不破坏方块、不伤实体，只是视觉爆炸。
                    // 若想要伤害，改成 MOB/BLOCK 并注意别炸死玩家；若只要特效，建议换粒子。
                    // 坐标用的是玩家位置（原逻辑如此）；若想炸方块位置，把参数改成 blockpos 的 x/y/z。
                    level.explode(null, playerIn.getX(), playerIn.getY(), playerIn.getZ(),
                            1.0F, Level.ExplosionInteraction.NONE);
                }

                if (!playerIn.isCreative()) itemstack.shrink(1);
            }
        } else if (blockstate.is(BlockInit.DEYE_BLOCK.get())) {
            if (level.isClientSide) {
                for (float i = 1; i <= 3; i += 0.5f)
                    CommonFunctions.spawnHexAround(ParticleTypes.CAMPFIRE_COSY_SMOKE, level, blockpos, i);
            }

            if (!level.isClientSide) {
                EntityUriass e = new EntityUriass(EntityInit.URIASS.get(), playerIn.level());
                e.moveTo(blockpos.getX(), blockpos.getY(), blockpos.getZ(),
                        playerIn.getYRot(), playerIn.getXRot());
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 5, false, false));
                e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 5, false, false));
                playerIn.level().addFreshEntity(e);
                CommonFunctions.spawnFireFlame(e, ParticleInit.FLAME_PARTICLE.get());

                level.playSound(null, playerIn.getX(), playerIn.getY(), playerIn.getZ(),
                        SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.4F,
                        1.4F / (playerIn.getRandom().nextFloat() * 0.4F + 1.2F) + 0.5F);

                if (!playerIn.isCreative()) itemstack.shrink(1);
            }
        } else if (blockstate.is(BlockInit.DUNGEON_BLOCK.get())) {
            if (level.isClientSide) {
                for (float i = 1; i <= 3; i += 0.5f)
                    CommonFunctions.spawnHexAround(ParticleTypes.LANDING_LAVA, level, blockpos, i);
            }

            if (!level.isClientSide) {
                EntityAxeman e = new EntityAxeman(EntityInit.AXEMAN.get(), playerIn.level());
                e.moveTo(blockpos.getX(), blockpos.getY(), blockpos.getZ(),
                        playerIn.getYRot(), playerIn.getXRot());
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 5, false, false));
                e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 5, false, false));
                playerIn.level().addFreshEntity(e);
                CommonFunctions.spawnFireFlame(e, ParticleInit.FLAME_PARTICLE.get());

                level.playSound(null, playerIn.getX(), playerIn.getY(), playerIn.getZ(),
                        SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.4F,
                        1.4F / (playerIn.getRandom().nextFloat() * 0.4F + 1.2F) + 0.5F);

                if (!playerIn.isCreative()) itemstack.shrink(1);
            }
        }

        return true;
    }
}