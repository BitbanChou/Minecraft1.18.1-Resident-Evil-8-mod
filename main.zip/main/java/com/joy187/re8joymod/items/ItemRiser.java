package com.joy187.re8joymod.items;

import com.joy187.re8joymod.entity.EntityBei;
import com.joy187.re8joymod.entity.EntityRe8Dimi;
import com.joy187.re8joymod.entity.EntityUrias;
import com.joy187.re8joymod.init.BlockInit;
import com.joy187.re8joymod.init.EntityInit;
import com.joy187.re8joymod.init.ParticleInit;
import com.joy187.re8joymod.util.CommonFunctions;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class ItemRiser extends PickaxeItem {

    public ItemRiser(Tier toolMaterial, int attackDamage, float attackSpeed, Properties itemProperties) {
        super(toolMaterial, attackDamage, attackSpeed, itemProperties);
    }

    @Override
    public boolean canAttackBlock(BlockState blockstate, Level level, BlockPos blockpos, Player playerIn) {
        ItemStack itemstack = playerIn.getMainHandItem();

        if (blockstate.is(BlockInit.PALEW_BLOCK.get())) {
            if (level.isClientSide) {
                for (float i = 1; i <= 3; i += 0.5f)
                    CommonFunctions.spawnHexAround(ParticleTypes.ENTITY_EFFECT, level, blockpos, i);
                level.addParticle(ParticleTypes.AMBIENT_ENTITY_EFFECT,
                        playerIn.getX() + 5 * (level.random.nextDouble() - 0.5D) * playerIn.getBbWidth(),
                        playerIn.getY() + 0.1D,
                        playerIn.getZ() + 4 * (level.random.nextDouble() - 0.5D) * playerIn.getBbWidth(),
                        playerIn.position().x * -0.2D, 0.1D, playerIn.position().z * -0.2D);
            }

            if (!level.isClientSide) {
                EntityRe8Dimi e = new EntityRe8Dimi(EntityInit.RE8DIMI.get(), playerIn.level());
                summon(level, blockpos, playerIn, e, itemstack);
            }
        } else if (blockstate.is(BlockInit.DUNGEON_BLOCK.get())) {
            if (level.isClientSide) {
                for (float i = 1; i <= 3; i += 0.5f)
                    CommonFunctions.spawnHexAround(ParticleTypes.LARGE_SMOKE, level, blockpos, i);
            }

            if (!level.isClientSide) {
                EntityBei e = new EntityBei(EntityInit.BEI.get(), playerIn.level());
                summon(level, blockpos, playerIn, e, itemstack);
            }
        } else if (blockstate.is(BlockInit.DEYE_BLOCK.get())) {
            if (level.isClientSide) {
                for (float i = 1; i <= 3; i += 0.5f)
                    CommonFunctions.spawnHexAround(ParticleTypes.CAMPFIRE_COSY_SMOKE, level, blockpos, i);
            }

            if (!level.isClientSide) {
                EntityUrias e = new EntityUrias(EntityInit.URIAS.get(), playerIn.level());
                summon(level, blockpos, playerIn, e, itemstack);
            }
        }

        return true;
    }

    /**
     * 只在服务端调用：定位、加缓速/抗性、生成实体、粒子、音效、扣物品。
     */
    private void summon(Level level, BlockPos blockpos, Player playerIn, LivingEntity e, ItemStack itemstack) {
        e.moveTo(blockpos.getX(), blockpos.getY(), blockpos.getZ(),
                playerIn.getYRot(), playerIn.getXRot());
        e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 5, false, false));
        e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 5, false, false));
        level.addFreshEntity(e);
        CommonFunctions.spawnFireFlame(e, ParticleInit.FLAME_PARTICLE.get());
        level.playSound(null, playerIn.getX(), playerIn.getY(), playerIn.getZ(),
                SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.4F,
                1.4F / (playerIn.getRandom().nextFloat() * 0.4F + 1.2F) + 0.5F);

        if (!playerIn.isCreative()) itemstack.shrink(1);
    }
}