package com.joy187.re8joymod.items;

import com.joy187.re8joymod.entity.EntityMiranda1;
import com.joy187.re8joymod.entity.EntityMoreau4;
import com.joy187.re8joymod.init.BlockInit;
import com.joy187.re8joymod.init.EntityInit;
import com.joy187.re8joymod.util.CommonFunctions;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class ItemRiser3 extends PickaxeItem {

    public ItemRiser3(Tier toolMaterial, int attackDamage, float attackSpeed, Properties itemProperties) {
        super(toolMaterial, attackDamage, attackSpeed, itemProperties);
    }

    @Override
    public boolean canAttackBlock(BlockState blockstate, Level level, BlockPos blockpos, Player playerIn) {
        ItemStack itemstack = playerIn.getMainHandItem();

        if (blockstate.is(BlockInit.MUCUS_BLOCK.get())) {
            // 粒子表现：客户端侧执行（addParticle 是客户端专用 API）
            if (level.isClientSide) {
                for (float i = 1; i <= 3; i += 0.5f)
                    CommonFunctions.spawnHexAround(ParticleTypes.ITEM_SLIME, level, blockpos, i);
                level.addParticle(ParticleTypes.AMBIENT_ENTITY_EFFECT,
                        playerIn.getX() + 5 * (level.random.nextDouble() - 0.5D) * playerIn.getBbWidth(),
                        playerIn.getY() + 0.1D,
                        playerIn.getZ() + 4 * (level.random.nextDouble() - 0.5D) * playerIn.getBbWidth(),
                        playerIn.position().x * -0.2D, 0.1D, playerIn.position().z * -0.2D);
            }

            // 决策 + 实体生成 + 扣物品：只在服务端执行
            if (!level.isClientSide) {
                if (level.random.nextInt(2) == 1) {
                    EntityMoreau4 e = new EntityMoreau4(EntityInit.MOREAU4.get(), playerIn.level());
                    e.moveTo(blockpos.getX(), blockpos.getY(), blockpos.getZ(),
                            playerIn.getYRot(), playerIn.getXRot());
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20 * 3, 5, false, false));
                    e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 3, 5, false, false));
                    playerIn.level().addFreshEntity(e);
                    CommonFunctions.spawnFireFlame(e, com.joy187.re8joymod.init.ParticleInit.FLAME_PARTICLE.get());

                    level.playSound(null, playerIn.getX(), playerIn.getY(), playerIn.getZ(),
                            SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.4F,
                            1.4F / (playerIn.getRandom().nextFloat() * 0.4F + 1.2F) + 0.5F);
                } else {
                    playerIn.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100));
                }

                // 原逻辑：无论是否召唤成功都扣物品。若只想在召唤成功时扣，
                // 把这一行移进上面的 if (level.random.nextInt(2) == 1) 分支内。
                if (!playerIn.isCreative()) itemstack.shrink(1);
            }
        } else if (blockstate.is(BlockInit.FANTOM_BLOCK.get())) {
            // 粒子表现：客户端侧执行
            if (level.isClientSide) {
                for (float i = 1; i <= 3; i += 0.5f)
                    CommonFunctions.spawnHexAround(ParticleTypes.CRIMSON_SPORE, level, blockpos, i);
                level.addParticle(ParticleTypes.LARGE_SMOKE,
                        playerIn.getX(), playerIn.getY(), playerIn.getZ(),
                        playerIn.position().x, playerIn.position().y, playerIn.position().z);
            }

            // 实体生成 + 扣物品：只在服务端执行
            if (!level.isClientSide) {
                EntityMiranda1 e = new EntityMiranda1(EntityInit.MIRANDA1.get(), playerIn.level());
                e.moveTo(blockpos.getX(), blockpos.getY(), blockpos.getZ(),
                        playerIn.getYRot(), playerIn.getXRot());
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20 * 3, 5, false, false));
                e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 3, 5, false, false));
                playerIn.level().addFreshEntity(e);
                CommonFunctions.spawnFireFlame(e, com.joy187.re8joymod.init.ParticleInit.FLAME_PARTICLE.get());

                level.playSound(null, playerIn.getX(), playerIn.getY(), playerIn.getZ(),
                        SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.4F,
                        1.4F / (playerIn.getRandom().nextFloat() * 0.4F + 1.2F) + 0.5F);

                if (!playerIn.isCreative()) itemstack.shrink(1);
            }
        }
        // 注释掉的 DEYE_BLOCK 分支已删除；如需恢复，记得同样包 !level.isClientSide 并加创造模式判断。

        return true;
    }
}